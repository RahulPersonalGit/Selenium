package RI_newCADSL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class SettingDefault {
    CommonFunctions commonFunctionsForGL =new CommonFunctions();
    CSVReader csvReader=new CSVReader();
    String dropdown[]=csvReader.readCSV("dropdown", "CADSL_new.csv");
    String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","CADSL_new.csv");
    String asSavedSearch[]=csvReader.readCSV("asSavedSearch","CADSL_new.csv");

    public void setAsDefault(WebDriver driver,String nameToBeSavedAsDefault) throws IOException, InterruptedException {
        driver.findElement(By.id(dropdown[2])).click();
        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(nameToBeSavedAsDefault)){
                div.click();
                break;
            }
        }
        driver.findElement(By.id(dropdown[2])).click();
        Thread.sleep(1000);
        System.out.println(asMoreActionsOptions[3]);
        commonFunctionsForGL.findDisplayedElement(driver,asMoreActionsOptions[3]).click();
        driver.switchTo().defaultContent();
        commonFunctionsForGL.openPage(driver,"CADSL");
        try{driver.switchTo().frame("panel3");}catch (Exception e){driver.switchTo().frame("panel0");}
        Thread.sleep(2000);
        commonFunctionsForGL.checkComponents(driver,csvReader.readCSV("initialASComponents","TimeZone.csv"));
        commonFunctionsForGL.testCloseTabs(driver,new int[]{3});
        driver.switchTo().frame("panel2");
    }
}
