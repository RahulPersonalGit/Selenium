package RI_newCADSL;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static junit.framework.Assert.assertTrue;


/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/6/13
 * Time: 8:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CADSLAS_new {
    CommonFunctions commonFunctions=new CommonFunctions();
    CSVReader csvReader=new CSVReader();
    String CADSL[]=csvReader.readCSV("CADSL","CADSL_new.csv");
    String selectOptionsAs[]=csvReader.readCSV("selectOptionsAs","CADSL_new.csv");
    String dropdown[]=csvReader.readCSV("dropdown","CADSL_new.csv");
    String textBoxIdsAs[]=csvReader.readCSV("textBoxIdsAs","CADSL_new.csv");
    String inputValues[]=csvReader.readCSV("inputValue","InputData_new.csv");
    String closeImages[]=csvReader.readCSV("closeImages","CADSL_new.csv");
    String searchLinks[]=csvReader.readCSV("searchLinks","CADSL_new.csv");
    String dblHyperLink[]=csvReader.readCSV("dblHyperLink","CADSL_new.csv");
    String buttonsAs[]=csvReader.readCSV("buttonsAs","CADSL_new.csv");
    String commonDropDownAs[]=csvReader.readCSV("commonDropDownAs","CADSL_new.csv");
    String selectOptionsAsBetween[]=csvReader.readCSV("selectOptionsAsBetween","CADSL_new.csv");
    String betweenFromTextBox[]=csvReader.readCSV("betweenFromTextBox","CADSL_new.csv");
    String betweenToTextBox[]=csvReader.readCSV("betweenToTextBox","CADSL_new.csv");
    String betweenFrom[]=csvReader.readCSV("betweenFrom","InputData_new.csv");
    String betweenTo[]=csvReader.readCSV("betweenTo","InputData_new.csv");
    String updateIds[]=csvReader.readCSV("updateIds","CADSL_new.csv");
    String tableId[]=csvReader.readCSV("tableId","CADSL_new.csv");
    String tableHeaders[]=csvReader.readCSV("tableHeaders","CADSL_new.csv");
    String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","CADSL_new.csv");
    String newSearchName[]=csvReader.readCSV("newSearchName","InputData_new.csv");

    public void advancedSearch(WebDriver driver) throws InterruptedException, IOException {
        driver.switchTo().defaultContent();
        driver.switchTo().frame(CADSL[1]);
        driver.findElement(By.id(searchLinks[1])).sendKeys(Keys.ENTER);
        sort3ColumnOptionAllCases(driver);
         equalsForAs(driver,selectOptionsAs,buttonsAs[1],closeImages);
         betweenForAs(driver,selectOptionsAsBetween,buttonsAs[1]);

        String dataLabel[]=csvReader.readCSV("dataLabel","CADSL_new.csv");
        String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","CADSL_new.csv");
        String newSearchName[]=csvReader.readCSV("newSearchName","InputData_new.csv");
        String inputValues[]=csvReader.readCSV("inputValueForAs","InputData_new.csv");

        for(int i=1;i<7;i++){
            commonFunctions.doubleClickForSelectOptions(driver, selectOptionsAs[1], selectOptionsAs[i+1], new String[]{"", dataLabel[1],  textBoxIdsAs[i], dblHyperLink[1]});
            Thread.sleep(100);

        }
        saveAndDeleteSearch(driver);
    }
    public void saveAndDeleteSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element,option;
        Thread.sleep(2000);
        element=driver.findElement(By.id("moreActions"));
        Assert.assertTrue("Save Search combo  is not found ", element.isDisplayed());
        element.click();
        Thread.sleep(1000);
        driver.findElement(By.id("Saveasnew")).click();
        element=driver.findElement(By.id("newSaveName"));
        element.click();
        element.sendKeys("try89");
        element=driver.findElement(By.id("ok"));
        element.click();
    }
    public void createNewSearch(WebDriver driver,String id,String value,String newName,boolean checkPublic) throws InterruptedException {
        String saveAsNewElements[]=csvReader.readCSV("saveAsNewElements","CADSL_new.csv");
        String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","CADSL_new.csv");
        driver.findElement(By.id(id)).click();
        commonFunctions.checkComponents(driver,asMoreActionsOptions);
        driver.findElement(By.id(value)).click();
        commonFunctions.checkComponents(driver, saveAsNewElements);

        WebElement element=isElementDisplayed(driver, saveAsNewElements[2]);
        element.click();
        commonFunctions.closeAlert(driver);
        driver.findElement(By.id(saveAsNewElements[1])).clear();
        driver.findElement(By.id(saveAsNewElements[1])).sendKeys(newName);
        if(checkPublic)driver.findElement(By.id(saveAsNewElements[3])).click();
        element.click();
    }
    public void sort3ColumnOptionAllCases(WebDriver driver) throws InterruptedException,IOException{
        sort3ColumnOptionCase(driver);
        sort3ColumnOptionCase1(driver);
        sort3ColumnOptionCase2(driver);
        sort3ColumnOptionCase3(driver);
        sort3ColumnOptionCase4(driver);
    }
    public void sort3ColumnOptionCase(WebDriver driver) throws InterruptedException,IOException{
        WebElement element,div;
        Thread.sleep(2000);
        element=driver.findElement(By.id("sortingOption"));
        System.out.println("id:"+element);
        element.click();
        Thread.sleep(5000);
        div=driver.findElement(By.className("bancs-dialog"));
        element=div.findElement(By.id("sortingOptionContainer"));
        sortSpecific(driver,"sortField1","wca_loginId");
        sortSpecific(driver,"sortField2","wca_loginId");
        sortSpecific(driver,"sortField3","wca_loginId");
        CommonFunctions obj= new CommonFunctions();
        obj.closeAlert(driver);
        element=driver.findElement(By.className("bancs-btn"));
        element.click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id("Search")).click();

    }
    public void sort3ColumnOptionCase1(WebDriver driver) throws InterruptedException,IOException{
        WebElement element,div;
        Thread.sleep(2000);
        element=driver.findElement(By.id("sortingOption"));
        System.out.println("id:"+element);
        element.click();
        Thread.sleep(5000);
        div=driver.findElement(By.className("bancs-dialog"));
        element=div.findElement(By.id("sortingOptionContainer"));
        sortSpecific(driver,"sortField1","wca_loginId");
        sortSpecific(driver,"sortField2","wca_firstName");
        sortSpecific(driver,"sortField3","wca_businessPartner");
        element=driver.findElement(By.className("bancs-btn"));
        element.click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id("Search")).click();
        String[] output={"4","4","4"};
        CommonFunctions cmn=new CommonFunctions();
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Login Id",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","First Name",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Business Partner",output,1);
    }
    public void sort3ColumnOptionCase2(WebDriver driver) throws InterruptedException,IOException{
        WebElement element,div;
        Thread.sleep(2000);
        element=driver.findElement(By.id("sortingOption"));
        System.out.println("id:"+element);
        element.click();
        Thread.sleep(5000);
        div=driver.findElement(By.className("bancs-dialog"));
        element=div.findElement(By.id("sortingOptionContainer"));
        sortSpecific(driver,"sortField1","wca_loginId");
        driver.findElement(By.id("sortRadio1")).click();
        sortSpecific(driver,"sortField2","wca_firstName");
        driver.findElement(By.id("sortRadio2")).click();
        sortSpecific(driver, "sortField3", "wca_businessPartner");
        driver.findElement(By.id("sortRadio3")).click();
        element=driver.findElement(By.className("bancs-btn"));
        element.click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id("Search")).click();
        String[] output={"","sdfds","23324"};
        CommonFunctions cmn=new CommonFunctions();
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Login Id",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","First Name",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Business Partner",output,1);
    }
    public void sort3ColumnOptionCase3(WebDriver driver) throws InterruptedException,IOException{
        WebElement element,div;
        Thread.sleep(2000);
        element=driver.findElement(By.id("sortingOption"));
        System.out.println("id:"+element);
        element.click();
        Thread.sleep(5000);
        div=driver.findElement(By.className("bancs-dialog"));
        element=div.findElement(By.id("sortingOptionContainer"));
        sortSpecific(driver,"sortField1","wca_userEffectiveDate");
        sortSpecific(driver,"sortField2","Last Logged in Time ");
        driver.findElement(By.id("sortRadio2")).click();
        sortSpecific(driver,"sortField3","wca_userStatus");
        element=driver.findElement(By.className("bancs-btn"));
        element.click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id("Search")).click();
        String[] output={"19/01/2012","00:00:01","Entered"};
        CommonFunctions cmn=new CommonFunctions();
        cmn.tableData(driver,"bui_w_userListCADSL_Table","User Effective Date ",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Last Logged in Time ",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","User Status",output,1);
    }
    public void sort3ColumnOptionCase4(WebDriver driver) throws InterruptedException,IOException{
        WebElement element,div;
        Thread.sleep(2000);
        element=driver.findElement(By.id("sortingOption"));
        System.out.println("id:"+element);
        element.click();
        Thread.sleep(5000);
        div=driver.findElement(By.className("bancs-dialog"));
        element=div.findElement(By.id("sortingOptionContainer"));
        sortSpecific(driver,"sortField1","wca_employeeReference");
        driver.findElement(By.id("sortRadio1")).click();
        sortSpecific(driver,"sortField2","wca_balanceCurrency");
        driver.findElement(By.id("sortRadio2")).click();
        sortSpecific(driver,"sortField3","wca_processingCenter");
        element=driver.findElement(By.className("bancs-btn"));
        element.click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id("Search")).click();
        String[] output={"244262442","","LCenterLCenter"};
        CommonFunctions cmn=new CommonFunctions();
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Employee Reference",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Balance Currency",output,1);
        cmn.tableData(driver,"bui_w_userListCADSL_Table","Processing Center",output,1);
    }

    public  void sortSpecific(WebDriver driver,String field,String input) throws InterruptedException,IOException {
        WebElement element,div;
        element=driver.findElement(By.id(field));
        element.click();
        final Select selectBox = new Select(driver.findElement(By.id(field)));
        selectBox.selectByValue(input);
      /*  List<WebElement> optionList = element.findElements(By.tagName("option"));
        for(WebElement obj:optionList){
            System.out.println("Option "+obj.getText());
            System.out.println("input "+input);
            if(obj.getText().equals(input)){
                obj.click();
               // optionList = element.findElements(By.tagName("option"));
                break;
            }
        }*/
    }
    public void equalsForAs(WebDriver driver,String selectOptionsAs[],String searchButton,String closeImages[])   throws InterruptedException,IOException
    {
        WebElement element;
        String inputValues[]=csvReader.readCSV("inputForAs","InputData_new.csv");
        String updateAs[]=csvReader.readCSV("updateAs","InputData_new.csv");
        for(int j=2;j<selectOptionsAs.length;j++){
            String a=selectOptionsAs[j];
            element=driver.findElement(By.id(selectOptionsAs[1]));
            List<WebElement> allOptions=element.findElements(By.tagName("option"));
            for(WebElement option:allOptions){
                if(option.getAttribute("value").equals(a)){
                    System.out.println("equals" + a);
                    commonFunctions.doubleClick(driver,option);
                    allOptions = element.findElements(By.tagName("option"));
                    break;
                }
            }
            if(selectOptionsAs[j].equals("User Status")){
                String csv="userStatus";
                assertCombo(driver,csv,j,searchButton);
                continue;
            }
            if(selectOptionsAs[j].equals("Balance Currency")){
                String csv="currency";
                assertCombo(driver,csv,j,searchButton);
                continue;
            }
            if(selectOptionsAs[j].equals("Nationality")){
                String csv="Nationality";
                assertCombo(driver,csv,j,searchButton);
                continue;
            }
            if(selectOptionsAs[j].equals("Country")){
                String csv="Country";
                assertCombo(driver,csv,j,searchButton);
                continue;
            }
            System.out.println("text box id="+textBoxIdsAs[j-1]);
            if(selectOptionsAs[j].equals("User Effective Date")){
                element=commonFunctions.findDisplayedElement(driver,textBoxIdsAs[j-1]);
                element.sendKeys(Keys.chord(Keys.CONTROL,"a"));
                element.sendKeys(Keys.DELETE);
            }
            else if(selectOptionsAs[j].equals("User Validity End Date")){
                element=commonFunctions.findDisplayedElement(driver,textBoxIdsAs[j-1]);
                element.sendKeys(Keys.chord(Keys.CONTROL,"a"));
                element.sendKeys(Keys.DELETE);
            }
            else if(selectOptionsAs[j].equals("Employee Reference")){

                openQBE(driver,"bui_ct_GL_qbeAllControlsSearchList_Table","MCB_SearchWC_wca_employeeReference_button");
                commonFunctions.findDisplayedElement(driver, searchButton).click();
                Thread.sleep(2000);
                continue;
            }
            else if(selectOptionsAs[j].equals("Business Partner")){

                openQBE(driver,"bui_w_TestRangeQBE_Table","MCB_SearchWC_wca_businessPartner_button");
                commonFunctions.findDisplayedElement(driver, searchButton).click();
                Thread.sleep(2000);
                continue;
            }
            element=commonFunctions.findDisplayedElement(driver,textBoxIdsAs[j - 1]);
            System.out.println("Date field check here :-" + element.getTagName());
            element.click();
            System.out.println("Input"+inputValues[j-1]);
            element.sendKeys(inputValues[j - 1]);
            driver.findElement(By.id(dblHyperLink[1])).click();
            commonFunctions.closeAlert(driver);
            commonFunctions.findDisplayedElement(driver, searchButton).click();
            Thread.sleep(2000);
            WebElement li=commonFunctions.findDisplayedElement(driver, "moreActions");
            element=li.findElement(By.tagName("a"));
            System.out.println("more actions"+element.getText() + " "+element.getTagName());
            element.click();
            Thread.sleep(1000);
            driver.findElement(By.id(asMoreActionsOptions[1])).click();
        }
    }
    public void openQBE(WebDriver driver,String tableId,String qbeId)  throws IOException, InterruptedException{
        WebElement element;
        element=driver.findElement(By.id(qbeId));
        element.click();
        Thread.sleep(2000);
        driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe"));
        driver.switchTo().frame(driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe")));
        element=driver.findElement(By.id("Search"));
        element.click();
        WebElement elementTable=driver.findElement(By.id(tableId));
        Assert.assertTrue("qbe  table is not found ", elementTable.isDisplayed());
        ArrayList<WebElement> tableRow= (ArrayList<WebElement>) elementTable.findElements(By.tagName("tr"));
        for (WebElement row : tableRow) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                continue;
            }
            for (WebElement cell : tableData) {
                System.out.println("C2 "+ cell.getText());
                ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", cell);
                Thread.sleep(2000);
                break;
            }
            break;
        }
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
    }
    public void assertCombo(WebDriver driver,String csv,int j,String searchButton) throws  IOException,InterruptedException{
        String userStatus[]=csvReader.readCSV(csv,"CADSL.csv");
        commonFunctions.findDisplayedElement(driver,textBoxIdsAs[j-1]).click();
        clickSelectedStatus(driver,userStatus);
        commonFunctions.findDisplayedElement(driver, dblHyperLink[1]).click();
        commonFunctions.findDisplayedElement(driver, searchButton).click();
        Thread.sleep(2000);
        commonFunctions.tableData(driver,tableId[1],tableHeaders[tableHeaders.length-1],userStatus,0);
        commonFunctions.findDisplayedElement(driver, closeImages[j - 1]).click();
    }
    public WebElement findInputTag(WebDriver driver,String[] selectOptionsAs,int j)
    {
        WebElement div=commonFunctions.findDisplayedElement(driver,textBoxIdsAs[j-1]);
        WebElement element=div.findElement(By.tagName("input"));
        return element;
    }
    public void clickSelectedStatus(WebDriver driver,String userStatus[]){
        WebElement element=driver.findElement(By.id(userStatus[1]));
        List<WebElement> allLis=element.findElements(By.tagName("li"));
        for(WebElement li:allLis){
            if(li.getText().equalsIgnoreCase(userStatus[2])){
                li.click();
                break;
            }
        }
    }
    public void initiateComboBox(WebDriver driver, String[] ListDataFromCSV) throws InterruptedException {
        Thread.sleep(3000);
        WebElement element;
        element = driver.findElement(By.id(ListDataFromCSV[3]));
        assertTrue(ListDataFromCSV[3] + " is not there", element.isDisplayed());
        driver.findElement(By.id(ListDataFromCSV[3])).click();
        Thread.sleep(1000);
        final Select selectBox = new Select(driver.findElement(By.id(ListDataFromCSV[3])));
        selectBox.selectByValue(ListDataFromCSV[4]);
    }

    public void betweenForAs(WebDriver driver,String selectOptionsAsBetween[],String searchButton)throws InterruptedException,IOException{
        WebElement element;
        String closeImagesBetween[]=csvReader.readCSV("closeImagesBetween","CADSL_new.csv");
        String tableHeaders[]=csvReader.readCSV("tableHeadersBetween","CADSL_new.csv");
        for(int j=2;j<selectOptionsAsBetween.length;j++){
            String a=selectOptionsAsBetween[j];
            element=driver.findElement(By.id(selectOptionsAsBetween[1]));
            List<WebElement> allOptions=element.findElements(By.tagName("option"));
            for(WebElement option:allOptions){
                if(option.getAttribute("value").equals(a)){
                     System.out.println("a" + a);
                    commonFunctions.doubleClick(driver,option);
                    element=driver.findElement(By.id("searchBarOperator"));
                    element.click();
                    final Select selectBox = new Select(driver.findElement(By.id("operatorType")));
                   element.sendKeys(Keys.DOWN);
                    Thread.sleep(2000);
                   // selectBox.selectByValue("between");
                    element=driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_From)"));
                    element.click();
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_From)")).sendKeys(Keys.chord(Keys.CONTROL,"a"));
                    Thread.sleep(1000);
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_From)")).sendKeys(Keys.DELETE);
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_From)")).sendKeys("14/12/2012");
                    element=driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_To)"));
                    element.click();
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_To)")).sendKeys(Keys.chord(Keys.CONTROL,"a"));
                    Thread.sleep(1000);
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_To)")).sendKeys(Keys.DELETE);
                    driver.findElement(By.id("propertyMap(MCB_SearchWC_wca_userEffectiveDate_To)")).sendKeys("05/02/2013");
                    driver.findElement(By.id("Search")).click();
                    CommonFunctions cmObj=new CommonFunctions();
                    cmObj.closeAlert(driver);
                  /*  if(a.equals("User Effective Date")) {
                    advanceBetweenSearch(driver,"propertyMap(MCB_SearchWC_wca_userEffectiveDate_From","propertyMap(MCB_SearchWC_wca_userEffectiveDate_To","14/12/2012","05/02/2013");
                    }
                    if(a.equals("Business Partner")){
                     advanceBetweenSearch(driver,"propertyMap(MCB_SearchWC_wca_userEffectiveDate_From","propertyMap(MCB_SearchWC_wca_userEffectiveDate_To","14/12/2012","05/02/2013");
                    }*/
                    break;

                }
            }
        }
    }
    public void advanceBetweenSearch(WebDriver driver,String fromId,String toId,String fromInputs,String toInputs) throws IOException,InterruptedException{
        WebElement element;
        element=driver.findElement(By.id(fromId));
        element.click();
        driver.findElement(By.id(fromId)).sendKeys(Keys.chord(Keys.CONTROL,"a"));
        Thread.sleep(1000);
        driver.findElement(By.id(fromId)).sendKeys(Keys.DELETE);
        driver.findElement(By.id(fromId)).sendKeys(fromInputs);
        element=driver.findElement(By.id(toId));
        element.click();
        driver.findElement(By.id(toId)).sendKeys(Keys.chord(Keys.CONTROL,"a"));
        Thread.sleep(1000);
        driver.findElement(By.id(toId)).sendKeys(Keys.DELETE);
        driver.findElement(By.id(toId)).sendKeys(toInputs);
        driver.findElement(By.id("Search")).click();
        CommonFunctions cmObj=new CommonFunctions();
        cmObj.closeAlert(driver);

    }
    public void nonEmptyASTest(WebDriver driver,String id,String value,String ancherId,String insideQueryContainer,String[] tableIds,int level) throws InterruptedException {
        equalsValue(driver,id,value,ancherId,insideQueryContainer,tableIds);
        Thread.sleep(100);
        commonFunctions.findDisplayedElement(driver, buttonsAs[1]).click();
        commonFunctions.tableData(driver,tableIds[0],tableIds[1],new String[]{value},level);
    }
    public void equalsValue(WebDriver driver,String id,String value,String ancherId,String insideQueryContainer,String[] tableIds) throws InterruptedException {
        driver.findElement(By.id(id)).sendKeys(Keys.chord(Keys.CONTROL, "a"));
        driver.findElement(By.id(id)).sendKeys(Keys.DELETE);
        driver.findElement(By.id(id)).sendKeys(value);
        driver.findElement(By.id(ancherId)).click();
        assertTrue("value inside query container not present ", commonFunctions.isElementPresent(driver, By.id(insideQueryContainer)));
        Thread.sleep(1000);
        commonFunctions.findDisplayedElement(driver,buttonsAs[1]).click();
        commonFunctions.tableData(driver,tableIds[0],tableIds[1],new String[]{value},0);
    }
    public WebElement isElementDisplayed(WebDriver driver,String id){
        List<WebElement> allId=driver.findElements(By.id(id));
        for(WebElement e:allId){
            if(e.isDisplayed()){
                return e;
            }
        }
        return null;
    }
    public void updateSaveDelete(WebDriver driver) throws InterruptedException, IOException {
        SettingDefault settingDefault=new SettingDefault();
        save(driver,newSearchName[3]);
        try{settingDefault.setAsDefault(driver, newSearchName[1]);}catch (Exception e){System.out.println("Setting Default Error");}
        for(int i=1;i<newSearchName.length;i++)
            deleteSavedSearch(driver,newSearchName[i]);
    }
    public void save(WebDriver driver,String name) throws InterruptedException {
        driver.findElement(By.id(dropdown[1])).click();
        clickSavedName(driver,name);
        for(int i=1;i<4;i++){
            driver.findElement(By.id(closeImages[i])).click();
            Thread.sleep(2000);
        }
        driver.findElement(By.id(dropdown[2])).click();
        driver.findElement(By.id(asMoreActionsOptions[4])).click();
        commonFunctions.findDisplayedElement(driver,buttonsAs[1]).click();
    }
    public void deleteSavedSearch(WebDriver driver,String name){
        String asSavedSearch[]=csvReader.readCSV("asSavedSearch","CADSL_new.csv");

        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        driver.findElement(By.id(dropdown[1])).click();
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(name) || div.getText().equals(name+" "+"*")){
                div.click();
                break;
            }
        }
        driver.findElement(By.id(dropdown[2])).click();
        driver.findElement(By.id(asMoreActionsOptions[6])).click();
        commonFunctions.closeAlert(driver);
    }
    public void clickSavedName(WebDriver driver,String name){
        String asSavedSearch[]=csvReader.readCSV("asSavedSearch","CADSL_new.csv");
        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(name)){
                div.click();
                break;
            }
        }
    }
}