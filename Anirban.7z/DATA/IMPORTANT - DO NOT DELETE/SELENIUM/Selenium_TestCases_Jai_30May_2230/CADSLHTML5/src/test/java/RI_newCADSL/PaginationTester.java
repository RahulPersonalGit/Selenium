package RI_newCADSL;

/**
 * Created with IntelliJ IDEA.
 * User: 547798
 * Date: 2/21/13
 * Time: 2:11 PM
 * To change this template use File | Settings | File Templates.
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class PaginationTester {

    public boolean testPagination(WebDriver driver,String tableId,String nextId,String prevId,String header) throws InterruptedException {
        List<String> data=getDataFromColumn(driver,tableId,header);
        do{
            driver.findElement(By.id(nextId)).click();

            data=testNextButton(driver, tableId, "wca_employeeReference", data);
            if(data==null)
            {
                System.out.println("Pagination for next page is not success");
                return false;
            }
            else
            {
                System.out.println("Pagination for next page is success");
            }
        }while(driver.findElement(By.id(nextId)).isEnabled());

        List<WebElement>lastPageRows=readTableContent(driver,tableId,"tr");
        int noOfRows=lastPageRows.size()-1;
        int endValue=data.size()-noOfRows;
        for(int k=data.size()-1;k>=endValue;k--)
        {
            data.remove(k);
        }
        do{
            driver.findElement(By.id(prevId)).click();
            List<WebElement> currentPageRows=readTableContent(driver,tableId,"tr");
            List<String> currentPageData=getDataFromColumn(driver,tableId,"wca_employeeReference");
            int endValue2=data.size()-currentPageRows.size()-1;
            for(int k=data.size()-1,a=currentPageData.size()-1;k>=endValue2&&a>=0;k--,a--)
            {
                if(!currentPageData.get(a).equals(data.get(k)))
                {
                    System.out.println("prev not working");
                    return false;
                }

                else{
                    data.remove(k);
                }

            }
        }while(driver.findElement(By.id(prevId)).isEnabled());

        System.out.println("pagination for prev sucess");

        return true;

    }
    public boolean testThreeColumnPagination(WebDriver driver,String tableId,String nextId,String prevId,String[] headers) throws InterruptedException {
        List<String>data=new ArrayList<String>();
        WebElement element;
        data=getCurrPageThreeColumnData(driver,tableId,headers);
        element=driver.findElement(By.id(nextId));
        assertTrue("nextButton not found",element.isDisplayed());
        do{
            driver.findElement(By.id(nextId)).click();
            data=checkThreeColumnNextPagination(driver,data,tableId,headers);
            if(data==null){
                System.out.println("pagination for next not success");
                return false;

            }
        }while (driver.findElement(By.id(nextId)).isEnabled());
        System.out.println("pagination for next is success");
        element=driver.findElement(By.id(prevId));
        assertTrue("prevButton not found",element.isDisplayed());
        List<WebElement>lastPageRows=readTableContent(driver,tableId,"tr");
        int noOfRows=lastPageRows.size()-1;
        int endValue=data.size()-noOfRows;
        for(int k=data.size()-1;k>=endValue;k--)
        {
            data.remove(k);
        }
        do{
            driver.findElement(By.id(prevId)).click();
            List<WebElement> currentPageRows=readTableContent(driver,tableId,"tr");
            List<String> currentPageData=getCurrPageThreeColumnData(driver,tableId,headers);
            int endValue2=data.size()-currentPageRows.size()-1;

            for(int k=data.size()-1,a=currentPageData.size()-1;k>=endValue2&&a>=0;k--,a--)
            {
                //System.out.println("currentPageData>>"+currentPageData.get(a)+"data>>"+data.get(k));
                if(!currentPageData.get(a).equals(data.get(k)))
                {
                    System.out.println("prev not working");
                    return false;
                }

                else{
                    data.remove(k);
                }

            }
        }while(driver.findElement(By.id(prevId)).isEnabled());

        System.out.println("pagination for prev sucess");

        return true;

    }
    public List<String> checkThreeColumnNextPagination(WebDriver driver,List<String> data,String tableId,String[] headers){
        String  column1,column2,column3,dataString;
        int positionHeader1,positionHeader2,positionHeader3;
        positionHeader1=getHeaderPosition(driver,tableId,headers[0]);
        positionHeader2=getHeaderPosition(driver,tableId,headers[1]);
        positionHeader3=getHeaderPosition(driver,tableId,headers[2]);
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int index=0;
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(positionHeader1);
            column1=element.getText();
            element=allTd.get(positionHeader2);
            column2=element.getText();
            element=allTd.get(positionHeader3);
            column3=element.getText();
            dataString=column1+column2+column3;
            if(data.contains(dataString))
                data= null;
            else
                data.add(dataString);
        }
        return data;
    }
    public List<String> getCurrPageThreeColumnData(WebDriver driver,String tableId,String[] headers) {

        List<String>data=new ArrayList<String>();
        String  column1,column2,column3,dataString;
        int positionHeader1,positionHeader2,positionHeader3;
        positionHeader1=getHeaderPosition(driver,tableId,headers[0]);
        positionHeader2=getHeaderPosition(driver,tableId,headers[1]);
        positionHeader3=getHeaderPosition(driver,tableId,headers[2]);
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int index=0;
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(positionHeader1);
            column1=element.getText();
            element=allTd.get(positionHeader2);
            column2=element.getText();
            element=allTd.get(positionHeader3);
            column3=element.getText();
            dataString=column1+column2+column3;
            data.add(dataString);
        }
        return data;
    }
    public int getHeaderPosition(WebDriver driver,String tableId,String header){
        int position=0;
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            // System.out.println("column label "+th.getAttribute("columnLabel")+" header="+header);
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        return position;
    }
    public List<WebElement> readTableContent(WebDriver driver,String tableId, String tagName) throws InterruptedException {
        WebElement table = driver.findElement(By.id(tableId));
        List<WebElement> allRows = table.findElements(By.tagName(tagName));
        return allRows;
    }
    public List<String> getDataFromColumn(WebDriver driver,String tableId,String header){
        List<String> data=new ArrayList<String>();
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0,index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        //  System.out.println("size="+allTh.size()+" tableid="+tableId);
        for(WebElement th:allTh){
            // System.out.println("column label "+th.getAttribute("columnLabel")+" header="+header);
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            data.add(element.getText());
        }
        return data;
    }
    public List<String> testNextButton(WebDriver driver,String tableId,String tableHeader,List<String> data){
        boolean flag=true;
        WebElement element;
        int position=0;
        int index=0;
        element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        position=getHeaderPosition(driver,tableId,tableHeader);
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            //  data=getDataFromColumn(driver,tableId,tableHeader);
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            if(data.contains(element.getText())){
                return null;
            }
            else
                data.add(element.getText());
        }
        return data;
    }
}
