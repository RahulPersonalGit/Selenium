package RI_newCADSL;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.List;
import java.util.Properties;

import static junit.framework.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 550229
 * Date: 2/5/13
 * Time: 12:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class CADSLQS_new {
    CommonFunctions commonFunctions = new CommonFunctions();
    CommonFunctionsForTable commonFunctionsForTable = new CommonFunctionsForTable();
    CSVReader csvReader = new CSVReader();
    String buttonsQs[] = csvReader.readCSV("buttonsQs", "CADSL_new.csv");
    String[] textBoxId = csvReader.readCSV("textBoxId", "CADSL_new.csv");
    String tableId[] = csvReader.readCSV("tableId", "CADSL_new.csv");
    String tableHeaders[] = csvReader.readCSV("tableHeaders", "CADSL_new.csv");
    String CADSL[] = csvReader.readCSV("CADSL", "CADSL_new.csv");
    String errorMsg[] = csvReader.readCSV("errorMsg", "CADSL_new.csv");
    String dropDownId[] = csvReader.readCSV("dropDownId", "CADSL_new.csv");

    public void quickSearch(WebDriver driver) throws Exception {
        testForInputs(driver, textBoxId);
        System.out.println("testForInputs() is over");
        testSearch(driver);
        System.out.println("*********testSearch() is over*******");
        /*  testPagination(driver); */
        testDoubleRightClickAndSorting(driver);
        System.out.println("testDoubleRightClickAndSorting() is over");
//        testSearchCrt(driver);
//        System.out.println("testSearchCrt() is over");
//        assertTrue("not displayed", driver.findElement(By.id(buttonsQs[2])).isDisplayed());
//        Thread.sleep(2000);
//        driver.findElement(By.id(buttonsQs[1])).click();
//        new CADSLMA_new().testTableMenuOptions(driver);
    }

    public void testSearch(WebDriver driver) {
        WebElement element = commonFunctions.findDisplayedElement(driver, buttonsQs[1]);
        System.out.println("Element" + element.getText());
        element.click();
    }

    public void testForInputs(WebDriver driver, String[] ids) {
        WebElement element;
        for (int i = 1; i < ids.length; i++) {
            element = commonFunctions.findDisplayedElement(driver, ids[i]);
            try {
                assertNotNull(ids[i] + " element is not there", element);
            } catch (AssertionError e) {
                System.out.println("testForInputs() -> Assertion Failure for element with id " + ids[i]);
            }
        }
    }

    public void testSearchCrt(WebDriver driver) throws InterruptedException, IOException {
        List<WebElement> elements;
        WebElement element;
        String[] inputValue = csvReader.readCSV("inputValue", "InputData_new.csv");
        String[] wrongInputValue = csvReader.readCSV("wrongInputValue", "InputData_new.csv");
        for (int i = 1; i < textBoxId.length; i++) {
            elements = driver.findElements(By.id(textBoxId[i]));
            element = commonFunctions.getElement(elements);
            commonFunctions.clearContent(driver, element);
            if (i == 8)
                continue;
            if (i == 9)
                testBusinessPartner(driver, tableHeaders[i]);
            else if (i == 5 || i == 6) {
                //commonFunctions.findDisplayedElement(driver,textBoxId[i]).clear();
                testDropDown(driver, textBoxId[i], inputValue[i], tableHeaders[i]);
            } else {
                element.sendKeys(inputValue[i]);
                Thread.sleep(200);
                testSearch(driver);
                if (i != 7)
                    commonFunctions.tableData(driver, tableId[1], tableHeaders[i], new String[]{inputValue[i]}, 0);
                Thread.sleep(200);
                commonFunctions.clearContent(driver, element);
                element.sendKeys(wrongInputValue[i]);
                Thread.sleep(1000);
                testSearch(driver);
                commonFunctions.closeAlert(driver);
                commonFunctions.closePopup(driver, errorMsg[1]);
                commonFunctions.tableData(driver, tableId[1], tableHeaders[i], new String[]{wrongInputValue[i]}, 0);
                commonFunctions.clearContent(driver, element);
            }
        }
    }

    public void testBusinessPartner(WebDriver driver, String tableHeaders) throws IOException, InterruptedException {
        String qbe[] = csvReader.readCSV("qbe", "CADSL_new.csv");
        String qbeData[] = csvReader.readCSV("qbeData", "InputData_new.csv");
        commonFunctions.findDisplayedElement(driver, qbe[1]).click();
        driver.switchTo().frame(qbe[2]);
        driver.switchTo().frame(qbe[3]);
        driver.findElement(By.id(qbe[4])).click();
        commonFunctions.doubleClickTable(driver, tableId[2], qbeData[1]);
        driver.switchTo().defaultContent();
        driver.switchTo().frame(CADSL[1]);
        testSearch(driver);
        commonFunctions.tableData(driver, tableId[1], tableHeaders, new String[]{qbeData[1]}, 0);
    }

    public void testDropDown(WebDriver driver, String textBoxId, String inputValue, String tableHeaders) throws InterruptedException {
        WebElement element;
        Thread.sleep(1000);
        element = commonFunctions.findDisplayedElement(driver, textBoxId);
        element.click();
        element = driver.findElement(By.id(dropDownId[1]));
        List<WebElement> allLis = element.findElements(By.tagName("li"));
        for (WebElement li : allLis) {
            if (li.getAttribute("value").equals(inputValue)) {
                li.click();
                break;
            }
        }
        testSearch(driver);
        commonFunctions.tableData(driver, tableId[1], tableHeaders, new String[]{inputValue}, 0);
    }

    public void rightClick(WebDriver driver, String value) throws IOException, InterruptedException {
        String rightClickOptions[] = csvReader.readCSV("rightClick", "CADSL_new.csv");
        for (int i = 1; i < rightClickOptions.length; i++) {
            commonFunctions.rightClickOnTable(driver, tableId[1], value);
            commonFunctions.checkComponents(driver, rightClickOptions);
            Thread.sleep(1000);
            commonFunctions.findDisplayedElement(driver, rightClickOptions[i]).click();
            if (commonFunctions.testTab(driver, 3, csvReader.readCSV("tabNames", "CADSL_new.csv")[i]))
                commonFunctions.testCloseTabs(driver, new int[]{3});
            commonFunctions.switchFrame(driver, CADSL[1]);
        }
    }

    public void clickOnTableHeader(WebDriver driver, String tableID, String header) {
        WebElement element = driver.findElement(By.id(tableID)).findElement(By.tagName("tbody"));
        List<WebElement> allTh = element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for (WebElement th : allTh) {
            if (th.getAttribute("columnLabel").equals(header)) {
                th.click();
                break;
            }
        }
    }

    public void testPagination(WebDriver driver) throws InterruptedException {
        WebElement element;
        PaginationTester obj = new PaginationTester();
        assertTrue("pagination failed", obj.testPagination(driver, "bui_w_userListCADSL_Table", "next", "prev", "wca_employeeReference"));
        Thread.sleep(2000);
    }

    public void testDoubleRightClickAndSorting(WebDriver driver) throws IOException, InterruptedException, ParseException, Exception {
        contextMenu(driver);
        System.out.println("contextMenu() is over");
//        rightClick(driver, "");
//        System.out.println("rightClick() is over");
        clickOnTableHeader(driver, tableId[1], tableHeaders[2]);
        System.out.println("clickOnTableHeader() is over");
        if (commonFunctionsForTable.sortingTableNew(driver, tableId[1], tableHeaders[2], 0, 2))     // 0->ascending  else descending
            System.out.println("Sorting Success");
        else
            System.out.println("Sorting failure");
        System.out.println("sortingTableNew() is over");
    }

    public void contextMenu(WebDriver driver) throws Exception {
        System.out.println("Inside contextMenu");
        rowRightClick(driver, "Create13");
        rowRightClick(driver, "Modify14");
        rowRightClick(driver, "View15");
        rowRightClick(driver, "Delete16");
        System.out.println("Exiting contextMenu");
    }

    public void rowRightClick(WebDriver driver, String contextId) throws Exception {
        WebElement element;
        List<WebElement> list, list2;
        element = driver.findElement(By.id("bui_w_userListCADSL_Table")).findElement(By.tagName("tbody"));
        list = element.findElements(By.tagName("tr"));
        list2 = list.get(3).findElements(By.tagName("td"));
        if (getBrowserName(driver).contains("internet")) {
            list2.get(4).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));

        } else {
            rightClick(driver, list2.get(4));
        }
        Thread.sleep(2000);
        driver.findElement(By.id(contextId)).click();
        if(contextId.equals("Create13")) contextId="Create";
        if(contextId.equals("Modify14")) contextId="Modify";
        if(contextId.equals("View15")) contextId="View";
        if(contextId.equals("Delete16")) contextId="Delete";

        closeChildWindow(driver,contextId);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
    }

    public String getBrowserName(WebDriver driver) throws IOException, InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName + " " + browserVersion);
        return browserName;
    }

    public void closeChildWindow(WebDriver driver,String tabName) {
        try {
            driver.switchTo().defaultContent();
            Properties tabs = new Properties();
            String tab[] = {"closeTab3"};
            InputStream in = getClass().getClassLoader().getResourceAsStream("Home.properties");
            tabs.load(in);
            for (String a : tab) {
                System.out.println(driver.findElement(By.id("stWidthChecker")).findElements(By.tagName("li")).size());
                List<WebElement>  liList= driver.findElement(By.id("stWidthChecker")).findElements(By.tagName("li"));
                for(WebElement x:liList){
                     if(x.findElement(By.tagName("a")).getText().contains(tabName) ){
                         x.findElement(By.className("bancs-tab-icon")).click();
                     }
                }
            }
        } catch (Exception e) {
            System.out.println("Error at closeChildWindow()");
            e.printStackTrace();
        }
    }

    public void rightClick(WebDriver driver, WebElement body) {
        System.out.println("inside the right click function");
        System.out.println(body.getText());
        Actions builder = new Actions(driver);
        Action rClick = builder.contextClick(body).build();
        rClick.perform();

    }
}
