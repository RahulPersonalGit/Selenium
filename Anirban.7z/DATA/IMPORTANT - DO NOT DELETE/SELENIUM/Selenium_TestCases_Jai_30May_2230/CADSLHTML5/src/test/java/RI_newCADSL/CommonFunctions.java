package RI_newCADSL;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

public class CommonFunctions {
    Constants constants=new Constants();
    CSVReader csvReader=new CSVReader();
    public void Login(WebDriver driver) throws Exception {
        try {
            WebElement element;

            element = driver.findElement(By.name("userId"));
            element.sendKeys("SYSADMIN");
            Thread.sleep(2000);
            element = driver.findElement(By.id("password"));
            element.sendKeys("abcd1234");
            element.click();
            element.sendKeys(Keys.TAB);
            Thread.sleep(2000);

            if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) {
                driver.findElement(By.id("Login")).sendKeys(Keys.ENTER);
            } else {
                driver.findElement(By.id("Login")).click();
            }

        } catch (Exception e) {
            System.out.println("Login failure" + e);
        }
    }
    public void openPage(WebDriver driver,String pageName) throws IOException, InterruptedException {
        WebElement element;
        Properties event=getProperty("Home");
        boolean flag=false;
        String after,before;
        Thread.sleep(5000);
        element=driver.findElement(By.id("menubar_container"));
        Thread.sleep(1000);
        for(int i=0;i<5;i++){
            testKeyBoardPress(driver, i);
            element.sendKeys(Keys.RIGHT);
            try{driver.findElement(By.linkText(event.getProperty(pageName))).isDisplayed();}catch(Exception e){continue;}
            before=after="";
            while(true){
                before=driver.findElement(By.className("bancs-menu_active")).getText();
                if(event.getProperty(pageName).equals(before)){
                    flag=true;
                    break;
                }
                element.sendKeys(Keys.DOWN);
                if(before.equals(after)){
                    element.sendKeys(Keys.RIGHT);
                    if(before.equals(driver.findElement(By.className("bancs-menu_active")).getText())) break;
                }
                after=before;
            }
            if(flag) break;
        }
        if(flag)element.sendKeys(Keys.RETURN);
    }
    public boolean isElementPresent(WebDriver driver,By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public Properties getProperty(String language) throws IOException {
        Properties home=new Properties();
        language+=".properties";
        InputStream in =getClass().getClassLoader().getResourceAsStream(language);
//        FileInputStream in=new FileInputStream(language);
        home.load(in);
        return home;
    }
    public void switchFrame(WebDriver driver,String panel) throws InterruptedException {
        driver.switchTo().frame(panel);
        Thread.sleep(constants.THOUSANDMILLISECONDS);
    }
    public void closeAlert(WebDriver driver){
        try{
            Alert alert = driver.switchTo().alert();
            alert.accept();
        }catch (Exception e){}
    }
    public void closePopup(WebDriver driver,String id){
        try{
        driver.findElement(By.id(id)).click();
        }catch(Exception e){}
    }
    public WebElement findDisplayedElement(WebDriver driver, String idToBeClicked){
        List<WebElement> elements;
        WebElement element;
        elements=driver.findElements(By.id(idToBeClicked));
        element=getElement(elements);
        return element;
    }
    public void testKeyEventUserMenu(WebDriver driver) throws IOException, InterruptedException {
        Properties menuBar=getProperty("Home");
        WebElement element;
        element=driver.findElement(By.id(menuBar.getProperty("userMenu")));
        assertTrue("userMenu not found",isElementPresent(driver, By.id(menuBar.getProperty("userMenu"))));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        Thread.sleep(constants.TENMILLISECONDS);
    }
    public void testKeyBoardPress(WebDriver driver,int i) throws IOException, InterruptedException {
        Properties menuItem=getProperty("Home");
        Thread.sleep(constants.THOUSANDMILLISECONDS);
        testKeyEventUserMenu(driver);
        WebElement element=driver.findElement(By.id(menuItem.getProperty("userMenu")));
        for(int j=0;j<i;j++)
            element.sendKeys(Keys.DOWN);
    }
    public void testPassDate(WebDriver driver,String fieldName,String dateValue){
        driver.findElement(By.id(fieldName)).clear();
        driver.findElement(By.id(fieldName)).sendKeys(dateValue);
    }
    public void previousDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextEnabled(WebDriver driver){
        assertTrue("Previous Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void configCollapsableAssert(WebDriver driver){
        assertTrue("Config View Size value changed",configViewSize(driver));
        assertTrue("Control Table Button is not displayed",driver.findElement(By.id("ctrlTblBtn")).isDisplayed());
        assertTrue("show table button expanded",!driver.findElement(By.id("Create19")).isDisplayed());
    }
    public void doubleClick(WebDriver driver, WebElement ele) throws  IOException,InterruptedException  {

        if(getBrowserName(driver).contains("internet")){
            ele.click();
            ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", ele);
        }
        else {
            doubleClickaction(driver,ele);
        }
    }
    public String getBrowserName(WebDriver driver) throws  IOException,InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName+" "+browserVersion);
        return  browserName;
    }
    public void doubleClickaction(WebDriver driver, WebElement body) {
        System.out.println("inside the double click function");
        Actions builder = new Actions(driver);
        Action doubleClick = builder.doubleClick(body)
                .build();
        doubleClick.perform();
    }
    public void checkComponents(WebDriver driver,String initialComponents[]){
        for(int i=1;i<initialComponents.length;i++)
            try{assertTrue(initialComponents[i]+" not found",isElementPresent(driver, By.id(initialComponents[i])));
            }catch(AssertionError e){
                System.out.println("Error in check components");
            }
    }
    public boolean testTab(WebDriver driver,int tab,String tabName) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        boolean flag=false;
        driver.switchTo().defaultContent();

        element = driver.findElement(By.id(tabs.getProperty("tab")));
        List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
        int i=1;
        for (WebElement li: allSpanElements) {
            if(i==tab){
                element=li.findElement(By.tagName("a"));
                if(element.getText().equals(tabName)){
                    flag=true;
                    break;
                }
            }
            i++;
        }

        return flag;
    }
    public boolean checkPage(WebDriver driver,String pageName){
        boolean flag=false;
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                flag=true;
                element.click();
                break;
            }
        }
        return flag;
    }
    public boolean configViewSize(WebDriver driver){
        String s=driver.findElement(By.id("confViewSizeSle")).getAttribute("value");
        if(s.equals("22"))
            return true;
        return false;
    }
    public void testCloseTabs(WebDriver driver,int[] tab) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        driver.switchTo().defaultContent();
        for(int a:tab){
            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==a){
                    List<WebElement> allLiElements=li.findElements(By.tagName("span"));
                    for(WebElement span:allLiElements)
                        element=span;
                    assertTrue(element + "not found", element.isDisplayed());
                    element.click();
                    break;
                }
                i++;
            }
        }
    }
    public WebElement searchInTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            table=null;
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    table=cell;
                    flag=true;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }



    public WebElement getElement(List<WebElement> elements){
        for(WebElement ele:elements){
            if(ele.isDisplayed())
                return ele;
        }
        return null;
    }
    public void doubleClickForSelectOptions(WebDriver driver,String id,String valueToBeClicked,String ids[])throws  IOException,InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allTh=element.findElements(By.tagName("option"));
        String s[]=new String[allTh.size()];
        int index=0;
        for(WebElement el:allTh)
            s[index++]=el.getText();
        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            if(option.getAttribute("value").equals(valueToBeClicked)){
                doubleClick(driver, option);
                checkComponents(driver, ids);
                element=driver.findElement(By.id("addLink"));
                element.click();
                CommonFunctions cmobj=new CommonFunctions();
                cmobj.closeAlert(driver);
                break;
            }
        }
    }
    public boolean tableData(WebDriver driver,String tableId,String header,String value[],int option){
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        if(index==1)
            System.out.println("No data found for "+value[value.length-1]);
        if(index==size)return true;
        return false;
    }
    public int compare(WebElement element,String value[],int option){
        int length=value.length;
        boolean flag=false;
        length-=1;
        switch (option){
            case 0:if(element.getText().equalsIgnoreCase(value[length]))
                return 1;
                break;
            case 1:if(!(element.getText().equalsIgnoreCase(value[length])))
                return 1;
                break;
            case 2:if(element.getText().contains(value[length].toLowerCase()) || element.getText().contains(value[length].toUpperCase()))
                return 1;
                break;
            case 3:if(element.getText().startsWith(value[length].toLowerCase()) || element.getText().startsWith(value[length].toUpperCase()))
                return 1;
                break;
            case 4:if(element.getText().endsWith(value[length].toLowerCase()) || element.getText().endsWith(value[length].toUpperCase()))
                return 1;
                break;
            case 5:for(int i=1;i<value.length;i++){
                if(element.getText().equalsIgnoreCase(value[i])){
                    flag=true;
                    break;
                }
            }
                if(flag)return 1;
                break;
            case 6:int i=1;
                for(i=1;i<value.length;i++){
                    if(!element.getText().equalsIgnoreCase(value[i])){
                        flag=true;
                    }
                }
                if(flag && i==value.length)return 1;
                break;
            case 7:int val=Integer.parseInt(value[length]);
                int toCompare=Integer.parseInt(element.getText());
                if(toCompare>val)
                    return 1;
                break;
            case 8:int val1=Integer.parseInt(value[length]);
                int toCompare1=Integer.parseInt(element.getText());
                if(toCompare1<val1)
                    return 1;
                break;
            case 9:int val2=Integer.parseInt(value[length]);
                int toCompare2=Integer.parseInt(element.getText());
                if(toCompare2>=val2)
                    return 1;
                break;
            case 10:int val3=Integer.parseInt(value[length]);
                int toCompare3=Integer.parseInt(element.getText());
                if(toCompare3<=val3)
                    return 1;
                break;
            case 11:String valueFromTable=element.getText();
                    if(value[0].compareTo(valueFromTable)<0 && value[1].compareTo(valueFromTable)>0)
                        return 1;
                    break;
        }
        return 0;
    }
    public void doubleClickTable(WebDriver driver ,String tableId,String valueToBeClicked) throws  IOException,InterruptedException {
        WebElement e=searchInTable(driver,tableId,valueToBeClicked);
        if(e!=null){
            doubleClick(driver,e);
        }

        testCloseTabs(driver,new int[]{3});
    }
    public void clearContent(WebDriver driver,WebElement element){
        if(element.getAttribute("id").equals(csvReader.readCSV("textBoxId","CADSL_new.csv")[5])){
            element.sendKeys("1");
        }else{
            element.sendKeys(Keys.chord(Keys.CONTROL,"a"));
            element.sendKeys(Keys.DELETE);
        }
    }
    public void rightClickOnTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement element=searchInTable(driver,id,valueToBeSearched);
        if(element!=null){
            element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        }
    }
    public List<String> getDataFromColumn(WebDriver driver,String tableId,String header){
        List<String> data=new ArrayList<String>();
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0,index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            data.add(element.getText());
        }
        return data;
    }
}