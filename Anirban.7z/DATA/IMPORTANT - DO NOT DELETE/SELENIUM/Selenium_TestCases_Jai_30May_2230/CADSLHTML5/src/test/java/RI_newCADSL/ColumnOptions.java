package RI_newCADSL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class ColumnOptions {
    CSVReader csvReader=new CSVReader();
    CommonFunctions commonFunctions =new CommonFunctions();
    String columnOptions[]=csvReader.readCSV("columnOptions","CADSL_new.csv");
    String showColumns[]=csvReader.readCSV("showColumns","CADSL_new.csv");
    String ctrlButtons[]=csvReader.readCSV("ctrlButtons", "CADSL_new.csv");

    public void columnOptions(WebDriver driver,String moreActions[]){
        driver.findElement(By.id(ctrlButtons[3])).click();
        driver.findElement(By.id(moreActions[6])).click();
        driver.findElement(By.id(columnOptions[4])).click();
        driver.findElement(By.id(columnOptions[3])).click();
        driver.findElement(By.id(columnOptions[7])).click();
        commonFunctions.closeAlert(driver);
        for(int i=1;i<2;i++){
            driver.findElement(By.id(columnOptions[i])).click();
            commonFunctions.closeAlert(driver);
        }
        driver.findElement(By.id(columnOptions[8])).click();
        selectOption(driver, columnOptions[columnOptions.length-1], showColumns[1]);
        driver.findElement(By.id(columnOptions[3])).click();
        selectOption(driver, columnOptions[columnOptions.length - 1], showColumns[3]);
        for(int i=5;i<8;i++){
            commonFunctions.closeAlert(driver);
            if(i==7)driver.findElement(By.id(columnOptions[i])).click();
            else for(int num=0;num<4;num++){
                driver.findElement(By.id(columnOptions[i])).click();
                commonFunctions.closeAlert(driver);
            }
        }
    }
    public void selectOption(WebDriver driver,String id,String value){
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            if(option.getAttribute("value").equals(value)){
                option.click();
                break;
            }
        }
    }
}
