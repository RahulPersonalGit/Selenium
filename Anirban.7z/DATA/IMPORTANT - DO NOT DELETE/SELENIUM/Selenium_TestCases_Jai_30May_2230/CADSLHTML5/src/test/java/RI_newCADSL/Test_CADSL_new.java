package RI_newCADSL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

/**
 * Created with IntelliJ IDEA.
 * User: 550229
 * Date: 1/29/13
 * Time: 6:44 PM
 * To change this template use File | Settings | File Templates.
 */
public class Test_CADSL_new extends BrowserConfig {
    private WebDriver driver;
    private String chromeDriverPath;
    CommonFunctions commonFunctions=new CommonFunctions();
    CSVReader csvReader=new CSVReader();

    CADSLQS_new CADSLQSNew =new CADSLQS_new();
    Constants constants=new Constants();

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void quitDriver() {
        driver.quit();
        System.out.println("over");
    }
    @Test
    public void testDemo() {
        System.out.println("inside testDemo");
        if (SeleniumGrid.equals("Y")) {
            for (DesiredCapabilities browser : browsers) {
                driver = null;
                try {
                    driver = new RemoteWebDriver(new URL(URL), browser);
                    ExecuteTest(driver,browser.getBrowserName());
                } catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                } finally {
                    if (driver != null) {
                        driver.quit();
                    }
                }
            }
        } else {
            driver = null;
            System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
            driver = new InternetExplorerDriver();
            try {
                ExecuteTest(driver,null);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
//                driver.quit();
            }
        }
    }

    public void ExecuteTest(WebDriver driver, String browserName) {
        try{
        driver.get(baseUrl);
        String[] loginPageData=csvReader.readCSV("loginPageData","CADSL_new.csv");
        commonFunctions.Login(driver);
        Thread.sleep(constants.THOUSANDMILLISECONDS);
        commonFunctions.openPage(driver, "CADSL");
        Thread.sleep(2000);
        driver.switchTo().frame(csvReader.readCSV("CADSL", "CADSL_new.csv")[1]);
        Thread.sleep(2000);
        System.out.println("CADSL QS starting");
        CADSLQSNew.quickSearch(driver);
//        System.out.println("CADSL AS starting");
//        new CADSLAS_new().advancedSearch(driver);
        }catch(Exception e){
            System.out.println("Failure in Test Execution--------------");
            e.printStackTrace();
        }
    }

}
