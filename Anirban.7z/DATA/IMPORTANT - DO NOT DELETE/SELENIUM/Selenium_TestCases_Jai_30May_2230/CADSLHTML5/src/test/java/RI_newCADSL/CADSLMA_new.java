package RI_newCADSL;

import org.openqa.selenium.*;

import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 550229
 * Date: 2/5/13
 * Time: 12:38 PM
 * To change this template use File | Settings | File Templates.
 */
public class CADSLMA_new {
    CommonFunctions commonFunctions=new CommonFunctions();
    CSVReader csvReader=new CSVReader();
    ExportingPages exportingPages=new ExportingPages();
    String CADSL[]=csvReader.readCSV("CADSL","CADSL_new.csv");

    public void testTableMenuOptions(WebDriver driver) throws IOException, InterruptedException {
        String ctrlButtons[]=csvReader.readCSV("ctrlButtons","CADSL_new.csv");
        String ctrlMoreActions[]=csvReader.readCSV("ctrlMoreActions","CADSL_new.csv");
        String downloadLinks[]=csvReader.readCSV("downloadLinks","CADSL_new.csv");
        driver.findElement(By.id(csvReader.readCSV("buttonsQs","CADSL_new.csv")[2])).sendKeys(Keys.ENTER);

        Thread.sleep(1000);
        for(int i=1;i<ctrlButtons.length-1;i++){
            driver.findElement(By.id(ctrlButtons[i])).click();
            commonFunctions.testCloseTabs(driver, new int[]{3});
            commonFunctions.switchFrame(driver,CADSL[1]);
        }
        driver.findElement(By.id(ctrlButtons[ctrlButtons.length-1])).click();
        Thread.sleep(2000);
        for(int i=1;i<4;i++){
            driver.findElement(By.id(ctrlMoreActions[i])).click();
            commonFunctions.testCloseTabs(driver, new int[]{3});
            commonFunctions.switchFrame(driver,CADSL[1]);
            driver.findElement(By.id(ctrlButtons[ctrlButtons.length-1])).click();
        }
        driver.findElement(By.id(ctrlButtons[ctrlButtons.length-1])).click();
        exportingPages.exportPage(driver,new String[] {ctrlButtons[3],ctrlMoreActions[4]},downloadLinks[1]);
        exportingPages.exportPage(driver,new String[] {ctrlButtons[3],ctrlMoreActions[5]},downloadLinks[2]);
        new ColumnOptions().columnOptions(driver,ctrlMoreActions);
    }
    public WebElement searchInTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched)){
                    flag=true;
                    table=cell;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public void doubleClickTable(WebDriver driver ){
        WebElement e=searchInTable(driver,"bui_w_userListCADSL_Table","fd");
        if(e!=null){
            e.click();
            ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
        }
    }
}
