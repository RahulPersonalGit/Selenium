package RI_newCADSL;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/15/13
 * Time: 1:55 PM
 * To change this template use File | Settings | File Templates.
 */

public class StringToDate {
    public static void main(String[] args) {
        try {  String str_date="11/12/2007";
            DateFormat formatter ;
            Date date ;
            formatter = new SimpleDateFormat("dd/MM/yyyy");
            date = (Date)formatter.parse(str_date);
            System.out.println("Today is " +date );
        } catch (ParseException e)
        {System.out.println("Exception :"+e);  }

    }
}
