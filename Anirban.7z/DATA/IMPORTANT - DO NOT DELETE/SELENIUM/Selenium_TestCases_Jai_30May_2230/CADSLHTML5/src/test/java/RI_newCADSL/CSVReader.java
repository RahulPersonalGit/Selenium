package RI_newCADSL;

import java.io.*;

public class CSVReader {
    private int panelNo=1,lineNumber = 0, tokenNumber = 0, i = 0;

    public String[] readCSV(String firstWord,String fileName) {
        try {
            System.out.println(firstWord+"  "+fileName);
           InputStream inputStream = getClass().getClassLoader().getResourceAsStream(fileName);
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream ));
                      
            String line = "";


            //read comma separated file line by line
            while ((line = br.readLine()) != null) {
                lineNumber++;
                String as1[]=line.split(",");
                if(as1[0].equals(firstWord)){
                    return as1;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*public static void main(String args[]){
        String[] riArray=new CSVReader().readCSV("vani","CADSL_new.csv");
        for(String a:riArray)System.out.println(a);
    }*/

    /*private void TestCaseExecutionSteps(WebDriver driver, String[] ListDataFromCSV) throws InterruptedException {


    }
*/

}
