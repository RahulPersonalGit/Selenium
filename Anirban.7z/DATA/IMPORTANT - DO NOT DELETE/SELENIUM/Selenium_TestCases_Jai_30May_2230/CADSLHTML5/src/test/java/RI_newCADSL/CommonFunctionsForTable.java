package RI_newCADSL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/26/13
 * Time: 12:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommonFunctionsForTable {
    public boolean sortingTable(WebDriver driver,String id,String header,int order,int type) throws ParseException {
        WebElement element=driver.findElement(By.id(id)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        if(type==0)
            index+=sortInteger(order,allTr,position);
        else if(type==1)
            index+=sortString(order,allTr,position);
        else
            index+=sortDate(order,allTr,position);
        if(size==index)
            return true;
        return false;
    }
    public boolean sortingTableNew(WebDriver driver,String id,String header,int order,int type) throws ParseException {
        WebElement element=driver.findElement(By.id(id));//.findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("thead")).findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        int size=allTr.size();
        if(type==0)
            index+=sortIntegerNew(order,allTr,position);
        else if(type==1)
            index+=sortStringNew(order,allTr,position);
        else
            index+=sortDateNew(order,allTr,position);
        if(size==index)
            return true;
        return false;
    }
    public int sortString(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        String previous="",next="";
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            next=element.getText();
            if(index==1)
                previous=next;
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=element.getText();
                    index++;
                }else break;
            }
            else{
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=element.getText();
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public int sortStringNew(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        String previous="",next="";
        for(WebElement tr:allTr){
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            next=element.getText();
            if(index==1)
                previous=next;
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=element.getText();
                    index++;
                }else break;
            }
            else{
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=element.getText();
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public int sortInteger(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        int previous=0;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            int next=Integer.parseInt(element.getText());
            if(index==1)
                previous=next;
            if(order==0){
                if(previous<=next){  // ascending order
                    previous=next;
                    index++;
                }else break;
            }
            else{
                if(previous>=next){ //descending  order
                    previous=next;
                    index++;
                }
                else break;
            }
        }
        return  index;
    }
    public int sortIntegerNew(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        int previous=0;
        for(WebElement tr:allTr){

            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            int next=Integer.parseInt(element.getText());
            if(index==1)
                previous=next;
            if(order==0){
                if(previous<=next){  // ascending order
                    previous=next;
                    index++;
                }else break;
            }
            else{
                if(previous>=next){ //descending  order
                    previous=next;
                    index++;
                }
                else break;
            }
        }
        return  index;
    }
    public int sortTime(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0,previousHours=0,previousMinutes=0,previousSeconds=0;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            String time[]=element.getText().split(":");
            int hours=Integer.parseInt(time[0]);
            int minutes=Integer.parseInt(time[1]);
            int seconds=Integer.parseInt(time[2]);
            if(index==1){
                previousHours=hours;
                previousMinutes=minutes;
                previousSeconds=seconds;
            }
            if(order==0){
                if(previousHours<=hours){            // ascending order
                    if(previousMinutes<=minutes){
                        if(previousSeconds<=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes<=minutes){
                    if(previousSeconds<=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds<=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
            else{
                if(previousHours>=hours){  // descending order
                    if(previousMinutes>=minutes){
                        if(previousSeconds>=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes>=minutes){
                    if(previousSeconds>=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds>=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public int sortTimeNew(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0,previousHours=0,previousMinutes=0,previousSeconds=0;
        for(WebElement tr:allTr){

            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            String time[]=element.getText().split(":");
            int hours=Integer.parseInt(time[0]);
            int minutes=Integer.parseInt(time[1]);
            int seconds=Integer.parseInt(time[2]);
            if(index==1){
                previousHours=hours;
                previousMinutes=minutes;
                previousSeconds=seconds;
            }
            if(order==0){
                if(previousHours<=hours){            // ascending order
                    if(previousMinutes<=minutes){
                        if(previousSeconds<=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes<=minutes){
                    if(previousSeconds<=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds<=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
            else{
                if(previousHours>=hours){  // descending order
                    if(previousMinutes>=minutes){
                        if(previousSeconds>=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes>=minutes){
                    if(previousSeconds>=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds>=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public int sortDate(int order,List<WebElement> allTr,int position) throws ParseException {
        WebElement element;
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        int index=0;
        Date previous=null;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            System.out.println("inside sorting = "+element.getText());
            Date next;
            next=df.parse(element.getText());
            if(index==1)
                previous=next;
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=next;
                    index++;
                }else break;
            }
            else{
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=next;
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public int sortDateNew(int order,List<WebElement> allTr,int position) throws ParseException {
        WebElement element;
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        int index=0;
        Date previous=null;
        for(WebElement tr:allTr){

            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            System.out.println("inside sorting = "+element.getText());
            Date next;
            next=df.parse(element.getText());
            if(index==0)
                previous=next;
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=next;
                    index++;
                }else break;
            }
            else{
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=next;
                    index++;
                }else break;
            }
        }
        return  index;
    }
}
