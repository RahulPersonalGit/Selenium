package mouse;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 12/31/12
 * Time: 1:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class Arrays {
    String appHeaderArray[]         ={"clientLogo","businessDate","userInfo"};
    String favoritesArray[]         ={"userTab","roleTab","userGroupTab","maskProfileTab","jobSetupTab","jobMonitorTab","ruleSetTab",
                                      "queueDepthTab","modifyTab"};
    String organizeFavoritesArray[] ={"selectNone","roleFavourite","selectAll"};
    String closeSMCreateArray[]     ={"user","roles","userGroup","maskProfile","dacQueryTemplate","dacAccessGrpList","userDacAccess",
                                      "dacSetup","nlsProfile","functionSetup","maintainAba","securityParameter","timeZoneDetails",
                                      "passwordSetup","actionGroupSetup","roleBasedErrorOverride","functionLevelSetup","userLevelSetup",
                                      "MCPs"};
    String closeRIArray[]           ={"tabForm","treeForm","CADSL","ADSL"};
    String closeSMListArray[]       ={"userList","roleList","userGroupList","actionGroupSetupList","smArchival","NLSProfileManagement",
                                      "MCPsList","auditDetails","timeZone","securityParameterList","reKey","maskProfileList",
                                      "archivalRetentionPeriod"};
    String closeSMMaintainArray[]   ={"functionAuditSetup"};
    String closeJSMArray[]          ={"quartzJobMonitor","jobSetup","jobMonitor","backgroundJobList","failedRecords","archivalMonitoring",
                                      "entityCodeGroupSetup"};
    String closeANCreateArray[]     ={"maintainNotificationAttribute","messageTemplate","maintainNotificationGroup"};
    String closeANListArray[]       ={"notificationLogs","eventLogs","notificationGroups","showNotificationRecepients",
                                      "notificationRecipients"};
    String closeQMCreateArray[]     ={"ruleSet","queueDepth"};
    String closeQMListArray[]       ={"SLAsList","ruleSets","managerWorkItem"};
    String closeQMMaintainArray[]   ={"SLAs"};
    String closeRMCreateArray[]     ={"maintainDocuments","documentGroup","documentConfigurationParameters","toolsTemplates",
                                      "reportAssocTemplate"};
    String closeRMDCPArray[]        ={"modify","view"};
    String closeRMListArray[]       ={"documents","documentGroups","requestedReports","generatedReports","regenerateReportSetup",
                                      "toolsTemplatesList","reportAssociatedTemplateList"};
    String maintainArray[]          ={"securityManagement","jobSetupAndMonitoring","alertsAndNotifications","queueManager",
                                      "reportsManagement"};
    String menuArray[]              ={"menuList","userMenu","favorites","help","messages","archival","wizard","preferences","logout"};
    String riArray[]                ={"tabForm","treeForm"};
    String smArray[]                ={"user","roles","userGroupList","maskProfileList"};
    String jsmArray[]               ={"jobSetup","jobMonitor"};
    String qmArray[]                ={"ruleSet","queueDepth"};
    String rmArray[]                ={"modify","view"};
    String[] accordionTabsArray     ={"themeSelection","tableViewSize","messageFadeOut","changePassword","myWindows","applicationKeyMap",
                                      "widgetGallery"};
    String[] messageFadeOutArray    ={"msgFadeOut","msgFadeOutYes","msgFadeOutNo"};
    String[][] changePasswordsArray ={{"abcd1234","1234abcd","12345abcd"},{"abcd124","1234abcd","12345abcd"},
                                      {"abcd1234","1234abcde","1234abcde"},{"abcd1234","abcd1234","abcd1234"}};
    String[] colors                 ={"orange","blue"};
    String[] styles                 ={"italic","normal"};
    String[] buttons                ={"fontButton","colorButton"};
    String[] lists                  ={"fontList","colorList"};
    String tabs[]                   ={"home","event"};
    String tilingButton[]           ={"horizontal","vertical"};
    String[] widgetGalleryArray     ={"widgetGallery","workFlow","stpQueue"};
    String tabsNameArray[]          ={"securityManagement","jobSetupAndMonitoring","queueManager","reportsManagement"};
    String helpOptionsArray[]       ={"contentHelp","aboutBancs"};
    int tabNumbers[]                ={2,2,5,7};
    String tabsArray[][]            ={smArray,jsmArray,qmArray,rmArray};
    String closeSMArray[][]         ={closeSMCreateArray,closeSMListArray,closeSMMaintainArray};
    String closeJSAndMArray[][]     ={closeJSMArray};
    String closeANArray[][]         ={closeANCreateArray,closeANListArray};
    String closeQMArray[][]         ={closeQMCreateArray,closeQMMaintainArray,closeQMListArray};
    String closeRMArray[][]         ={closeRMCreateArray,closeRMDCPArray,closeRMListArray};
    String closeAllArray[][][]      ={closeSMArray,closeJSAndMArray,closeANArray,closeQMArray,closeRMArray};
}