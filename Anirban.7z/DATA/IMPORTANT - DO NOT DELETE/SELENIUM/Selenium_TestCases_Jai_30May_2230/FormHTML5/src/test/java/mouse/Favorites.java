package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 4:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class Favorites extends Arrays{
    public void testFavourites(WebDriver driver) throws InterruptedException, IOException {
        Properties favorites=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        for(String a:favoritesArray) {
            assertTrue("image not found", driver.findElement(By.linkText(favorites.getProperty(a))).isDisplayed());
            driver.findElement(By.linkText(favorites.getProperty(a))).click();
            driver.manage().timeouts().implicitlyWait(new Constants().TENMILLISECONDS, TimeUnit.MILLISECONDS);
            assertTrue("favorites not found", driver.findElement(By.id(favorites.getProperty("favorites"))).isDisplayed());
            driver.findElement(By.id(favorites.getProperty("favorites"))).click();
            Thread.sleep(new Constants().THOUSANDMILLISECONDS);
            driver.findElement(By.id(favorites.getProperty("favorites"))).click();
            assertTrue("add to favorites not found", driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).isDisplayed());
            driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
        }
        assertTrue("add to favorites not found", driver.findElement(By.linkText(favorites.getProperty("favoritesOk"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("favoritesOk"))).click();
    }
    public void testAddMore(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Properties favorites=new MenuBar().getProperty();
        for(int i=8;i<=9;i++){
            element = driver.findElement(By.id(favorites.getProperty("tab")));
            assertTrue("tab not found ", element.isDisplayed());
            List<WebElement> allLiElements = element.findElements(By.tagName("li"));
            int j=1;
            for (WebElement li : allLiElements) {
                if(j==i){
                    li.click();
                    break;
                }
                j++;
            }
            driver.manage().timeouts().implicitlyWait(new Constants().TENMILLISECONDS, TimeUnit.MILLISECONDS);
           // assertTrue("favorites not found", GUIMODappTest.isElementPresent(By.id(favorites.getProperty("favorites"))));
            driver.findElement(By.id(favorites.getProperty("favorites"))).click();
            Thread.sleep(new Constants().HUNDREDMILLISECONDS);
            driver.findElement(By.id(favorites.getProperty("favorites"))).click();
           // assertTrue("add to favorites not found", GUIMODappTest.isElementPresent(By.id(favorites.getProperty("addToFavourites"))));
            driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
        }
    }
    public void testOrganizeFavourites(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        for(int i=0;i<3;i++){
            Thread.sleep(new Constants().HUNDREDMILLISECONDS);
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
            //assertTrue("favorites not found", GUIMODappTest.isElementPresent(By.id(favorites.getProperty("favorites"))));
            driver.findElement(By.id(favorites.getProperty("favorites"))).click();
            //assertTrue("Organise favorites not found", GUIMODappTest.isElementPresent(By.id(favorites.getProperty("organizeFavourites"))));
            driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();
            //assertTrue(organizeFavoritesArray[i] + " not found", GUIMODappTest.isElementPresent(By.id(favorites.getProperty(organizeFavoritesArray[i]))));
            driver.findElement(By.id(favorites.getProperty(organizeFavoritesArray[i]))).click();
            if(i==0){
                //assertTrue("Cancel  not found",GUIMODappTest.isElementPresent(By.id(favorites.getProperty("cancel"))));
                driver.findElement(By.linkText(favorites.getProperty("cancel"))).click();
            }
            else{
                //assertTrue("remove  not found",GUIMODappTest.isElementPresent(By.id(favorites.getProperty("remove"))));
                driver.findElement(By.linkText(favorites.getProperty("remove"))).click();
            }
        }
    }
    public void testRemoveAllFavorites(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Thread.sleep(new Constants().THOUSANDMILLISECONDS);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
        //assertTrue("favorites not found",driver.findElement(By.id(favorites.getProperty("favorites"))).isDisplayed());
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        Thread.sleep(100);
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        //assertTrue("Organise favorites not found",driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();
        if(driver.findElement(By.id(favorites.getProperty("selectAll"))).isDisplayed()){
            //assertTrue("selectAll not found",driver.findElement(By.id(favorites.getProperty("selectAll"))).isDisplayed());
            driver.findElement(By.id(favorites.getProperty("selectAll"))).click();
            //assertTrue("remove not found", driver.findElement(By.linkText(favorites.getProperty("remove"))).isDisplayed());
            driver.findElement(By.linkText(favorites.getProperty("remove"))).click();
        }else{
            //assertTrue("OK not found",driver.findElement(By.linkText(favorites.getProperty("favoritesOk"))).isDisplayed());
            driver.findElement(By.linkText(favorites.getProperty("favoritesOk"))).click();
        }
    }
    public void testOpenAdded(WebDriver driver) throws IOException {
        Properties favorites=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
        //assertTrue("favorites not found",driver.findElement(By.id(favorites.getProperty("favorites"))).isDisplayed());
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        //assertTrue("jobSetup not found",driver.findElement(By.linkText(favorites.getProperty("jobSetup"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("jobSetup"))).click();
    }
    public void testAddHelpAndHome(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
        //assertTrue("favorites not found",driver.findElement(By.id(favorites.getProperty("favorites"))).isDisplayed());
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        //assertTrue("Add to favorites  not found",driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
        //assertTrue("Home not found",driver.findElement(By.linkText(favorites.getProperty("home"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("home"))).click();
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
        driver.findElement(By.id(favorites.getProperty("favorites"))).click();
        driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
        //assertTrue("OK not found",driver.findElement(By.linkText(favorites.getProperty("ok"))).isDisplayed());
        driver.findElement(By.linkText(favorites.getProperty("favoritesOk"))).click();
    }
}