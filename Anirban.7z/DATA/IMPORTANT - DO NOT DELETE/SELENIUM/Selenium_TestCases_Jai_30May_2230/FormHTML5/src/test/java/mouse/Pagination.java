package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/14/13
 * Time: 6:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class Pagination {
    public PaginationProperties pagination(WebDriver driver,String tableId,String tableHeader,List<String> data){
        boolean flag=true;
        WebElement element;
        PaginationProperties paginationProperties=new PaginationProperties();
        int position=0;
        int index=0;
        element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(tableHeader))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            if(data.contains(element.getText())){
                flag=false;
                break;
            }
            else
                data.add(element.getText());
        }
        //  System.out.println("flag=" + flag);
        paginationProperties.setFlag(flag);
        paginationProperties.setData(data);
        return paginationProperties;
    }
}
