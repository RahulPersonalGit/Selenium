package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;
import java.util.Properties;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;



/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 3:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class BirdsEyeView {
    public void testBirdsEyeView(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        MenuBar menuBar=new MenuBar();
        Properties birdsEyeView=menuBar.getProperty();
        boolean flag=false;
        assertFalse("Bird eye View not found", !driver.findElement(By.className(birdsEyeView.getProperty("birdsEyeView"))).isDisplayed());
        driver.findElement(By.className(birdsEyeView.getProperty("birdsEyeView"))).click();
        element = driver.findElement(By.id(birdsEyeView.getProperty("birdImage")));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li : allLiElements) {
            List<WebElement> allSpanElements = li.findElements(By.tagName("span"));
            for (WebElement span : allSpanElements) {
                if(span.getText().equals(birdsEyeView.getProperty("ruleSet"))){
                    flag=true;
                    break; }
            }
            if(flag){
                List<WebElement> allSpansElements = li.findElements(By.tagName("img"));
                for (WebElement img : allSpansElements) {
                    assertFalse("image not found", !img.isDisplayed());
                    img.click();
                    flag=true;
                    break;
                }
            }
            if(flag)break;
        }
    }
}