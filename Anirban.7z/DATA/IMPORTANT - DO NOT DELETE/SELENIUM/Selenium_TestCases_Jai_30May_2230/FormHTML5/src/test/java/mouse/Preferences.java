package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class Preferences extends  Arrays{
    public void testPreferences(WebDriver driver) throws Exception{
        Properties preferences=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        driver.findElement(By.id(preferences.getProperty("preferences"))).click();
        testAccordionTabs(driver);
        testThemeSelection(driver);
        testTblViewSize(driver);
        testMsgFadeOut(driver);
        testApplKeyMap(driver);
        testWidgetGallery(driver);  //*[@id="extraInfoHdr"]/a/span[1]

        //assertTrue("save not found",GUIMODappTest.isElementPresent(By.linkText(preferences.getProperty("save"))));
        driver.findElement(By.linkText(preferences.getProperty("save"))).click();
        //assertTrue("Close Preferences not found",GUIMODappTest.isElementPresent(By.className(preferences.getProperty("closePreferences"))));
        driver.findElement(By.className(preferences.getProperty("closePreferences"))).click();
    }
    public void testAccordionTabs(WebDriver driver) throws IOException {
        MenuBar menuBar=new MenuBar();
        //Properties accordionTabs=menuBar.getProperty();
        //for(String a:accordionTabsArray)
            //assertTrue(a+" is not there",new GUIMODappTest().isElementPresent(By.id(accordionTabs.getProperty(a))));
    }
    public void testTblViewSize(WebDriver driver) throws Exception{
        WebElement element;
        MenuBar menuBar=new MenuBar();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Properties tableViewSize=menuBar.getProperty();
        int count[]={3,6};

        //assertTrue("Table View Size not found",GUIMODappTest.isElementPresent(By.id(tableViewSize.getProperty("tableViewSize"))));
        driver.findElement(By.id(tableViewSize.getProperty("tableViewSize"))).click();
        element=driver.findElement(By.id(tableViewSize.getProperty("firstButton")));
        //assertTrue("first Button not found",element.isDisplayed());
        for(int c:count){
            for(int increment=0;increment<c;increment++)
                element.click();
        }
        //assertTrue("Second Button not found", GUIMODappTest.isElementPresent(By.id(tableViewSize.getProperty("secondButton"))));
        driver.findElement(By.id(tableViewSize.getProperty("secondButton"))).click();
        element=driver.findElement(By.id(tableViewSize.getProperty("tableViewSpinner")));
        //assertTrue("Table View Spinner not found",element.isDisplayed());
        for(int i=1;i<3;i++){
            element.clear();
            element.sendKeys(tableViewSize.getProperty("value"+i));
        }
        driver.findElement(By.id(tableViewSize.getProperty("firstButton"))).click();
        element.clear();
        element.sendKeys(tableViewSize.getProperty("value3"));
    }
    public void testMsgFadeOut(WebDriver driver) throws InterruptedException {
        for(String a:messageFadeOutArray){
            //assertTrue(a+" not found",new GUIMODappTest().isElementPresent(By.id(a)));
            driver.findElement(By.id(a)).click();
        }
    }
    public void testApplKeyMap(WebDriver driver) throws InterruptedException, IOException {
        Properties applicationKeys=new MenuBar().getProperty();
        //assertTrue("applicationKeyMap not found",new GUIMODappTest().isElementPresent(By.id(applicationKeys.getProperty("applicationKeyMap"))));
        driver.findElement(By.id(applicationKeys.getProperty("applicationKeyMap"))).click();
    }
    public void testThemeSelection(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        MenuBar menuBar=new MenuBar();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Properties themeSelection=menuBar.getProperty();
        //assertTrue("themeSelection not found", GUIMODappTest.isElementPresent(By.id(themeSelection.getProperty("themeSelection"))));
        driver.findElement(By.id(themeSelection.getProperty("themeSelection"))).click();
        for(int i=0;i<2;i++){
            //assertTrue(buttons[0]+" not found", GUIMODappTest.isElementPresent(By.id(themeSelection.getProperty(buttons[0]))));
            driver.findElement(By.id(themeSelection.getProperty(buttons[0]))).click();
            element = driver.findElement(By.id(themeSelection.getProperty(lists[0])));
            List<WebElement> allLiElements = element.findElements(By.tagName("li"));
            for (WebElement li : allLiElements) {
                if(li.getText().equals(themeSelection.getProperty(styles[i]))){
                    //assertTrue(styles[i]+" not found",li.isDisplayed());
                    li.click();
                    break;
                }
            }
            //assertTrue(buttons[1]+" not found", GUIMODappTest.isElementPresent(By.id(themeSelection.getProperty(buttons[1]))));
            driver.findElement(By.id(themeSelection.getProperty(buttons[1]))).click();
            element = driver.findElement(By.id(themeSelection.getProperty(lists[1])));
            allLiElements = element.findElements(By.tagName("li"));
            for (WebElement li : allLiElements) {
                Thread.sleep(new Constants().HUNDREDMILLISECONDS);
                if(li.getText().equals(themeSelection.getProperty(colors[i]))){
                    //assertTrue(colors[i]+" not found",li.isDisplayed());
                    li.click();
                    break;
                }
            }
        }
    }
    public void testWidgetGallery(WebDriver driver) throws InterruptedException, IOException {
        MenuBar menuBar=new MenuBar();
        Properties widgetGallery=menuBar.getProperty();
        for(String a :widgetGalleryArray){
            //assertTrue(a+" not found",new GUIMODappTest().isElementPresent(By.id(widgetGallery.getProperty(a))));
            driver.findElement(By.id(widgetGallery.getProperty(a))).click();
        }
    }
}