package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MenuBar extends Arrays {
    public void testMenuBar(WebDriver driver) throws InterruptedException, IOException {
//        testMenu(driver);
        Properties tabs = getProperty();
        //testRI(driver);
        for (int i = 0; i < tabsArray.length; i++) {
            for (String b : tabsArray[i]) {
                Thread.sleep(new Constants().THOUSANDMILLISECONDS);
                testMouseMove(driver, tabsNameArray[i]);
                Thread.sleep(2000);
                driver.findElement(By.linkText(tabs.getProperty(b))).click();
//                assertTrue(b+" not found",new GUIMODappTest().isElementPresent(By.linkText(tabs.getProperty(b))));
                Thread.sleep(2000);
            }
        }
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }

    public void openClose(WebDriver driver) throws InterruptedException, IOException {
        //openCloseRI(driver);
        Properties openCloseAll = getProperty();
        for (int i = 0; i < closeAllArray.length; i++) {
            for (String[] b : closeAllArray[i]) {
                for (String c : b) {
                    testMouseMove(driver, maintainArray[i]);

                    assertTrue(c + " not found", new GUIMODappTest().isElementPresent(By.linkText(openCloseAll.getProperty(c))));
                    driver.findElement(By.linkText(openCloseAll.getProperty(c))).click();
                    Thread.sleep(new Constants().HUNDREDMILLISECONDS);
                    closeTab(driver);
                }
            }
        }
    }

    public Properties getProperty() throws IOException {
        Properties home = new Properties();
        FileInputStream in = new FileInputStream("Home.properties");
        home.load(in);
        return home;
    }

    public void openCloseRI(WebDriver driver) throws InterruptedException, IOException {
        Properties referenceImplementation = getProperty();
        for (int i = 0; i < 3; i++) {
            testMouseMove(driver, "referenceImplementation");
            assertTrue(closeRIArray[i] + " not found", new GUIMODappTest().isElementPresent(By.linkText(referenceImplementation.getProperty(closeRIArray[i]))));
            driver.findElement(By.linkText(referenceImplementation.getProperty(closeRIArray[i]))).click();
            Thread.sleep(new Constants().HUNDREDMILLISECONDS);
            closeTab(driver);
        }
    }

    public void closeTab(WebDriver driver) throws InterruptedException, IOException {
        TabBar tabBar = new TabBar();
        tabBar.testCloseTabs(driver, new int[]{8});
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
    }

    public void testMenu(WebDriver driver) throws IOException {
        WebElement element;
        Properties menuBar = getProperty();
        for (String a : menuArray) {
            System.out.println(menuBar.getProperty(a));
//            assertTrue(menuBar.getProperty(a) + " absent", new GUIMODappTest().isElementPresent(By.id(menuBar.getProperty(a))));
        }
    }

    public void testMouseMoveToUserMenu(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        Actions builder;
        Properties menuBar = getProperty();
        driver.manage().timeouts().implicitlyWait(new Constants().TENMILLISECONDS, TimeUnit.MILLISECONDS);
        element = driver.findElement(By.id(menuBar.getProperty("userMenu")));
        assertTrue("userMenu not found", element.isDisplayed());
        builder = new Actions(driver);
        builder.moveToElement(element).build().perform();
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
    }

    public void testRI(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs = getProperty();
        for (String a : riArray) {
            Thread.sleep(new Constants().HUNDREDMILLISECONDS);
            testMouseMove(driver, "referenceImplementation");
            //assertTrue(a+" not found", new GUIMODappTest().isElementPresent(By.linkText(tabs.getProperty(a))));
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
    }

    public void testMouseMove(WebDriver driver, String elementName) throws IOException, InterruptedException {
        WebElement element;
        Actions builder;
        Properties menuItem = getProperty();
        testMouseMoveToUserMenu(driver);
        element = driver.findElement(By.linkText(menuItem.getProperty(elementName)));
        //assertTrue(elementName+" not found", element.isDisplayed());
        builder = new Actions(driver);
        builder.moveToElement(element).build().perform();
        Thread.sleep(new Constants().THOUSANDMILLISECONDS);
    }

    public void testExtraRM(WebDriver driver) throws IOException, InterruptedException {
        Properties tabs = getProperty();
        GUIMODappTest GUIMODappTest = new GUIMODappTest();
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
        testMouseMove(driver, "reportsManagement");
        //assertTrue("view not found", GUIMODappTest.isElementPresent(By.linkText(tabs.getProperty("view"))));
        driver.findElement(By.linkText(tabs.getProperty("view"))).click();
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
        testMouseMove(driver, "alertsAndNotifications");
//        assertTrue("Message Template not found", GUIMODappTest.isElementPresent(By.linkText(tabs.getProperty("messageTemplate"))));
        driver.findElement(By.linkText(tabs.getProperty("messageTemplate"))).click();
        Thread.sleep(new Constants().HUNDREDMILLISECONDS);
        testMouseMove(driver, "alertsAndNotifications");
        //      assertTrue("Event not found", GUIMODappTest.isElementPresent(By.linkText(tabs.getProperty("event"))));
        driver.findElement(By.linkText(tabs.getProperty("event"))).click();
        try {
            Alert alert = driver.switchTo().alert();
            alert.accept();
        } catch (Exception e) {
        }
    }
}