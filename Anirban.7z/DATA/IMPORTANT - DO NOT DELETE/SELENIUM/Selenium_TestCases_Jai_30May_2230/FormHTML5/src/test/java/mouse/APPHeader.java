package mouse;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;


/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 3:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class APPHeader extends Arrays{
    public void testAppHeader(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;

        Properties appHeader=new MenuBar().getProperty();
/*      for(String a:appHeaderArray){
            assertTrue(appHeader.getProperty(a) + " is not there",new GUIMODappTest().isElementPresent(By.id(appHeader.getProperty(a))));
        }*/
        for(int i=0;i<2;i++){
            testExtraInfo(driver);
            Thread.sleep(new Constants().THOUSANDMILLISECONDS);
        }
    }
    public void testExtraInfo(WebDriver driver) throws IOException {
        WebElement element;
        Properties extraInfo=new MenuBar().getProperty();
        element=driver.findElement(By.id(extraInfo.getProperty("extraInfo")));
        List<WebElement> allSpanElements = element.findElements(By.tagName("a"));
        for (WebElement li: allSpanElements) {
            List<WebElement> allLiElements=li.findElements(By.tagName("span"));
            for(WebElement span:allLiElements)
                element=span;
            assertTrue(element+" is not there",element.isDisplayed());
            element.click();
        }
    }
}