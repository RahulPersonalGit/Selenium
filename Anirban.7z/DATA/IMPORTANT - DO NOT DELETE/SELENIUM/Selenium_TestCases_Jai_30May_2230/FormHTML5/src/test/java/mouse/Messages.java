package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Properties;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 11:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class Messages{
    public void testMessages(WebDriver driver) throws IOException, InterruptedException {
        MenuBar menuBar =new MenuBar();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Properties messages=menuBar.getProperty();
        //assertTrue("Messages not found",GUIMODappTest.isElementPresent(By.id(messages.getProperty("messages"))));
        driver.findElement(By.id(messages.getProperty("messages"))).click();
        //assertTrue("Cancel not found",GUIMODappTest.isElementPresent(By.linkText(messages.getProperty("cancel"))));
        driver.findElement(By.linkText(messages.getProperty("cancel"))).click();
    }
}
