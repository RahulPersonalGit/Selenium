package mouse;

import SeleniumGrid.CommonFunctionsForQBE;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 560216
 * Date: 2/26/13
 * Time: 11:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class FormTypeTesterNewTemplate {
    public void FormTypeTest(WebDriver driver) throws InterruptedException, IOException {

        int testKey[] = {1, 5};
        String testData[] = {"SBI Bank", "75542", "INR", "343450", "75,542.00", "343,450.00", "565"};
        openWindow(driver);
        System.out.println("openWindow() operation complete---------");
        Thread.sleep(2000);
        try {
            openFormWindow(driver, testKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("OpenFormWindow() operation over---------");
        Thread.sleep(2000);
        try {
            testformViewMode(driver, testKey);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("testFormViewMode() complete-------------");
        Thread.sleep(2000);
        try {
            testFormModifyMode(driver, testKey, testData);
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("testFormModifyMode() complete-----------");
        Thread.sleep(3000);
    }

    public Properties getProperty() throws IOException {
        Properties Form = new Properties();
        FileInputStream in = new FileInputStream("FormNew.properties");
        Form.load(in);
        return Form;
    }

    public void openWindow(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        CommonFunctionsForQBE comm = new CommonFunctionsForQBE();
        comm.openPage(driver, "ADSL_LIST");
    }

    public void openFormWindow(WebDriver driver, int[] testKey) throws Exception {
        WebElement element;
        List<WebElement> list, list2;
        Properties form = getProperty();
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(2000);
        element = driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list = element.findElements(By.tagName("tr"));
        list2 = list.get(testKey[0]).findElements(By.tagName("td"));
        System.out.println("Browser name:" + getBrowserName(driver));
        System.out.println("Element clicked:" + list2.get(testKey[1]).getText());

        if (getBrowserName(driver).contains("internet")) {
            System.out.println("right click in IE = " + testKey[1] + "  " + list2.get(testKey[1]));
            list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        } else {
            list2.get(testKey[1]).click();
            rightClick(driver, list2.get(testKey[1]));
        }
        Thread.sleep(2000);

//        if (getBrowserName(driver).contains("internet")) {
//            System.out.println("C1");
//            driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).sendKeys(Keys.ENTER);
//        } else {
        System.out.println("C2" + form.getProperty("VIEW_ACCOUNT"));
        driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).click();
//        }
        driver.switchTo().defaultContent();

    }

    public void testformViewMode(WebDriver driver, int[] testKey) throws InterruptedException, IOException {
        WebElement element;
        List<WebElement> list;
        Properties form = getProperty();
        Thread.sleep(2000);
        String key = Integer.toString(testKey[0]);
        driver.switchTo().frame("panel3");
        element = driver.findElement(By.id(form.getProperty("EMPLOYEE_REF")));
        assertTrue("Employee Reference does not exist", element.isDisplayed());
        assertTrue("Employee Reference does not match", element.getAttribute("value").equals(key));
        list = driver.findElement(By.id(form.getProperty("GROUPBOX_0"))).findElements(By.tagName("input"));
        driver.findElement(By.id("Close5")).click();
    }

    public void testFormModifyMode(WebDriver driver, int[] testKey, String[] testData) throws Exception {
        List<WebElement> list, list2;
        WebElement element;
        Properties form = getProperty();
        driver.switchTo().defaultContent();
        String key = Integer.toString(testKey[0]);
        Thread.sleep(3000);
        driver.switchTo().frame("panel2");
        Thread.sleep(3000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(3000);
        element = driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list = element.findElements(By.tagName("tr"));
        list2 = list.get(testKey[0]).findElements(By.tagName("td"));
        if (getBrowserName(driver).contains("internet")) {
            list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        } else {
            rightClick(driver, list2.get(testKey[1]));
        }
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("MODIFY_ACCOUNT"))).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel4");
        element = driver.findElement(By.id(form.getProperty("EMPLOYEE_REF")));
        try {
            assertTrue("Employee Reference does not exist", element.isDisplayed());
            assertTrue("Employee Reference does not match", element.getAttribute("value").equals(key));
        } catch (AssertionError e) {
            System.out.println("Assertion Error :-Employee Reference error");
        }

        element = driver.findElement(By.id(form.getProperty("BANK_NAME")));
        try {
            assertTrue("Bank Name field  does not exist", element.isDisplayed());
        } catch (AssertionError e) {
            System.out.println("Bank Name field  does not exist");
        }
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(testData[0]);

        List<WebElement> salary = driver.findElements(By.id(form.getProperty("SALARY")));
        for (WebElement x : salary) {
            if (x.getTagName().equals("input")) {
                x.sendKeys(Keys.CONTROL + "a");
                x.sendKeys(testData[1]);
            }
        }

        //setValueAssertForSelect(driver,form.getProperty("CURR_COMBO"),testData[2]);
        //selectOption(driver,form.getProperty("CURR_COMBO"),testData[2]);
        String[] dropDownDetails = {"groupBox1_bui_wca_balanceCurrency-button", "groupBox1_bui_wca_balanceCurrency-div", testData[2]};
        System.out.println("Combo-Box initiated");
        initiateDecoratedComboBox(driver, dropDownDetails, "li");

        List<WebElement> balance = driver.findElements(By.id(form.getProperty("BALANCE")));
        for (WebElement x : balance) {
            if (x.getTagName().equals("input")) {
                x.sendKeys(Keys.CONTROL + "a");
                x.sendKeys(testData[3]);
            }
        }

        System.out.println("Going inside QBE");
        formQBEtester(driver, testKey, testData[6]);

        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame("panel4");


        driver.findElement(By.id("Save4")).click();
        Thread.sleep(2000);
        try {
            System.out.println("Closing alert NOW");
            driver.switchTo().alert().accept();
        } catch (Exception e) {
            System.out.println("No alerts present");
        }
        Thread.sleep(2000);
        driver.findElement(By.id("Close5")).click();
        driver.switchTo().defaultContent();

        Thread.sleep(1000);
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(3000);
        element = driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list = element.findElements(By.tagName("tr"));
        list2 = list.get(testKey[0]).findElements(By.tagName("td"));
//        if (getBrowserName(driver).contains("internet")) {
//            list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
//            driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).sendKeys(Keys.ENTER);
//        } else {
            rightClick(driver, list2.get(testKey[1]));
            driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).click();
//        }
        /*driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).click();*/
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel5");

        Thread.sleep(2000);

        element = driver.findElement(By.id(form.getProperty("BANK_NAME")));
        try {
            assertTrue("Modification failed : Bank Name not saved in database", element.getAttribute("value").equalsIgnoreCase(testData[0]));
        } catch (AssertionError e) {
            e.printStackTrace();
        }

        /* List<WebElement> salary1 = driver.findElements(By.id(form.getProperty("SALARY")));
        for (WebElement x : salary1) {
            if(x.getTagName().equals("input")){
                System.out.println("Value :"+x.getAttribute("value"));
                System.out.println("Test Data :"+testData[4]);
                assertTrue("Modification failed : Salary not saved in database", x.getAttribute("value").equals(testData[4]));
            }
        }*/
        element = driver.findElement(By.id(form.getProperty("SALARY")));
        try {
            assertTrue("Modification failed : Salary not saved in database", element.getAttribute("value").equalsIgnoreCase(testData[4]));
        } catch (AssertionError e) {
            e.printStackTrace();
        }

        /*element=driver.findElement(By.id(form.getProperty("CURRENCY")));
        assertTrue("Modification failed :Currency not saved in database",element.getAttribute("value").equalsIgnoreCase(testData[2]));*/

        element = driver.findElement(By.id(form.getProperty("BALANCE")));
        try {
            assertTrue("Modification failed : Balance not saved in database", element.getAttribute("value").equalsIgnoreCase(testData[5]));
        } catch (AssertionError e) {
            e.printStackTrace();
        }


    }

    public void formQBEtester(WebDriver driver, int testKey[], String testData) throws InterruptedException, IOException {

        switchToPanel(driver);
        WebElement element;
        Properties form = getProperty();
        Thread.sleep(4000);
        String key = Integer.toString(testKey[0]);
        //String value = Integer.toString(testKey[1]);

        element = driver.findElement(By.id(form.getProperty("EMPREF_QBE")));
        assertTrue("Employee Reference in the QBE window is not available", element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(key);

        driver.findElement(By.id("Search")).click();

        WebElement e = doubleClickTable(driver, form.getProperty("QBE_TABLE"), testData);
        System.out.println("e:" + e);
        if (e != null) {
            doubleClick(driver, e);
        } else {
            assertTrue("No data found after clicking the QBE Search", e == null);
        }
    }

    public WebElement doubleClickTable(WebDriver driver, String id, String valueToBeSearched) {
        WebElement table = driver.findElement(By.id(id));
        boolean flag = false;
        int index = 0;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        System.out.println("allRows:" + allRows.size());
        for (WebElement row : allRows) {
            //table=null;
//            if(index==0){index++; continue;}
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            System.out.println("tableData:" + tableData.size());
            for (WebElement cell : tableData) {
                System.out.println("Cell Data:" + cell.getText());
                if (cell.getText().equals(valueToBeSearched) || valueToBeSearched.equals("")) {
                    flag = true;
                    table = cell;
                    break;
                }
            }
            if (flag) break;
        }
        System.out.println("Element to be clicked:" + table.getText());
        return table;

    }

    public void doubleClick(WebDriver driver, WebElement e) {

        System.out.println("inside double click function" + e.getAttribute("svrVal"));
        try {
            if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) {
                e.click();
                ((JavascriptExecutor) driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
            } else {

                ((JavascriptExecutor) driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                        "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                        "arguments[0].dispatchEvent(evt);", e);
            }
        } catch (Exception ex) {
        }
    }


    public void switchToPanel(WebDriver driver) throws InterruptedException, IOException {
        Thread.sleep(1000);
        Properties form = getProperty();
        driver.findElement(By.id(form.getProperty("FORM_QBE"))).click();

        driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe"));
        driver.switchTo().frame(driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe")));
        System.out.println("Within iframe");
//        driver.switchTo().frame("mywindowframe");
    }

    public void setValueAssertForSelect(WebDriver driver, String id, String value) {
        WebElement element;
        List<WebElement> list;
        element = driver.findElement(By.id(id));
        assertTrue(id + " does not exist", element.isDisplayed());
        element.click();
        element = driver.findElement(By.id("styleDropDown"));
        assertTrue("No drop box found", element.isDisplayed());
        list = element.findElements(By.tagName("li"));
        assertTrue("No data found in drop box", !list.isEmpty());
        for (WebElement obj : list) {
            if (obj.getText().equals(value)) {
                obj.click();
                break;
            }
        }
    }

    public void selectOption(WebDriver driver, String id, String value) {
        WebElement element = driver.findElement(By.id(id));
        List<WebElement> allOptions = element.findElements(By.tagName("option"));
        for (WebElement option : allOptions) {
            if (option.getText().equals(value)) {
                option.click();
                break;
            }
        }
    }

    public void initiateDecoratedComboBox(WebDriver driver, String[] ListDataFromCSV, String elementType) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        Thread.sleep(3000);
        //need to remove the button click functionality
        ButtonClick(driver, ListDataFromCSV[0]);
        element = driver.findElement(By.id(ListDataFromCSV[1]));
        List<WebElement> allLiElements = element.findElements(By.tagName(elementType));
        for (WebElement li : allLiElements) {
            if (li.getText().equals(ListDataFromCSV[2]) && li.findElements(By.tagName("a")).size() == 0) {
                builder.moveToElement(li).click().build().perform();
                break;
            }
            if (li.getText().equals(ListDataFromCSV[2]) && li.findElements(By.tagName("a")).size() != 0) {
                builder.moveToElement(li.findElement(By.tagName("a"))).click().build().perform();
                break;
            }
        }
        Thread.sleep(2000);
    }

    public void ButtonClick(WebDriver driver, String buttonID) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By.id(buttonID)).click();
    }

    public String getBrowserName(WebDriver driver) throws IOException, InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName + " " + browserVersion);
        return browserName;
    }

    public void rightClick(WebDriver driver, WebElement body) {
        System.out.println("inside the right click function");
        System.out.println(body.getText());
        Actions builder = new Actions(driver);
        Action rClick = builder.contextClick(body).build();
        rClick.perform();

    }
}
