package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 1/8/13
 * Time: 12:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class I18N {
    public void changeLanguage(WebDriver driver) throws IOException, InterruptedException {
        Properties preferences=new MenuBar().getProperty();
        WebElement element;
        driver.findElement(By.id(preferences.getProperty("preferences"))).click();
        driver.findElement(By.id(preferences.getProperty("language"))).click();
        driver.findElement(By.id(preferences.getProperty("languageButton"))).click();
        element=driver.findElement(By.id(preferences.getProperty("languageList")));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li : allLiElements) {
            if(li.getText().equals("French")){
                li.click();
                break;
            }
        }
        driver.findElement(By.linkText("Enregistrer")).click();
        try{
            driver.findElement(By.className(preferences.getProperty("closePreferences"))).click();  //*[@id="Preferences"]/span/p
        }   catch (Exception e){}
        testLogout(driver);
        driver.quit();
    }
    public void testLogout(WebDriver driver) throws InterruptedException, IOException {
        MenuBar menuBar=new MenuBar();
        Properties logout=menuBar.getProperty();
        driver.findElement(By.id(logout.getProperty("logout"))).click();
        driver.findElement(By.linkText(logout.getProperty("cancel"))).click();
        driver.findElement(By.id(logout.getProperty("logout"))).click();
        driver.findElement(By.xpath("html/body/div[7]/div[2]/span/a")).click();
    }
}