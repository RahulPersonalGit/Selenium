package mouse;

import org.openqa.selenium.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.StringTokenizer;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 547798
 * Date: 1/29/13
 * Time: 7:20 PM
 * To change this template use File | Settings | File Templates.
 */
public class TabFormTest {

    public void TabFormTest(WebDriver driver) throws InterruptedException, IOException {

        openWindow(driver);
        driver.switchTo().frame("panel2");
       validationTest1(driver);
       mandatoryFiledTest(driver);
       CreateUserSuccessTest1(driver);
       testViewMode(driver);
       testModifyMode(driver);
    }
    String testCaseParameteres[] = new String[13];
    private int lineNumber = 1, tokenNumber = 0;

    public String[] readCSV(String CSVFileName,int testCase2BeRead) {
        try {

            String csvFile = "D:\\Selenium_TestCases_Arwa\\src\\main\\resources\\"+CSVFileName;
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            String line = "";
            StringTokenizer st = null;

            while ((line = br.readLine()) != null) {
                st = new StringTokenizer(line, ",");
                while (st.hasMoreTokens()) {
                    testCaseParameteres[tokenNumber] = st.nextToken();
                    tokenNumber++;
                }
                tokenNumber = 0;
                if (Integer.parseInt(testCaseParameteres[0])==testCase2BeRead) {

                    lineNumber = 1;
                    return testCaseParameteres;
                }

                lineNumber++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new String[0];
    }

    public void CreateUserSuccessTest1(WebDriver driver) throws InterruptedException, IOException {
        //driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        List<WebElement> list;
        WebElement element;
       /* Properties attributes = getProperty();*/
        String[] x=new String[6];
        System.out.println("X[3]"+readCSV("TabFormTestData.csv",3)[3]);
        for(int i=1;i<20;i++){
            x=readCSV("TabFormTestData.csv",i);
            switch(Integer.parseInt(x[3]) ){
                case 1:insertValueAndAssertForTextBox2(driver,x[1],x[2]);
                    break;
                case 2:insertValueAndAssertForTextBox(driver,x[1],x[2]);
                    break;
                case 3:setValueAssertForSelect(driver,x[1],x[2]);
                    break;
                case 4:setValueAndAssertCalender(driver,x[1],x[2],x[4]);
                    break;
                case 5:
                        formQBEtester(driver,x);
                        driver.switchTo().defaultContent();
                        driver.switchTo().frame("panel2");
                    break;
            }
        }
       /* insertValueAndAssertForTextBox2(driver,attributes.getProperty("BPID"),"1234");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_employeeReference","12423");
        insertValueAndAssertForTextBox2(driver,"bui_ct_userDetailsInner_bui_wca_processingCenter","LCenter");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_firstName","Ane");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_middleName","");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_lastName","Remore");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_email","Ane@gmail.com");
        insertValueAndAssertForTextBox(driver,"bui_ct_userDetailsInner_bui_wca_phoneNo","9434234567");
        insertValueAndAssertForTextBox2(driver,"bui_ct_userDetailsInner_bui_wca_salary","20000");
        setValueAssertForSelect(driver,"selectCombo_bui_ct_userDetailsInner_bui_wca_nationality","AFGHANISTAN");
        setValueAssertForSelect(driver,"selectCombo_bui_ct_userDetailsInner_bui_wca_balanceCurrency","ADP");
        insertValueAndAssertForTextBox2(driver,"bui_ct_userDetailsInner_bui_wca_balanceAmount","234343");
        insertValueAndAssertForTextBox(driver,"bui_ct_userAccessControl_bui_wca_login","AneRemore");
        insertValueAndAssertForTextBox(driver,"bui_ct_userAccessControl_bui_wca_password","abcd1234");
        insertValueAndAssertForTextBox(driver,"bui_ct_userAccessControl_bui_wca_confirmPassword","abcd1234");
        setValueAssertForSelect(driver,"selectCombo_bui_ct_userAccessControl_bui_wca_userStatus","Entered");*/
        x=readCSV("TabFormTestData.csv",33);
        element=driver.findElement(By.id(x[1]));
        assertTrue("userAdmin does not exist", element.isDisplayed());
        element.click();

      /*  setValueAndAssertCalender(driver,"bui_ct_userAccessControl_bui_wca_passwordExpiryDate_button","panel2","but12");
        setValueAndAssertCalender(driver,"bui_ct_userValidity_bui_wca_userEffectiveDate_button","panel2","but17");
        setValueAndAssertCalender(driver,"bui_ct_userValidity_bui_wca_userValidityEndDate_button","panel2","but20");*/
        x=readCSV("TabFormTestData.csv",34);
        element=driver.findElement(By.id(x[1]));
        assertTrue("save button does not exist",element.isDisplayed());
        element.click();
        WebElement recordExist=null;
        try{
        x=readCSV("TabFormTestData.csv",35);
        recordExist=driver.findElement(By.id(x[1]));
        assertTrue("error not there", recordExist.isDisplayed());}catch (Exception e){System.out.print("in side catch");}
        if(recordExist!=null)
        {
            x=readCSV("TabFormTestData.csv",36);
            driver.findElement(By.id(x[1])).click();
        }
        else
        {
            Thread.sleep(2000);
            x=readCSV("TabFormTestData.csv",37);
            element=driver.findElement(By.id(x[1]));
            assertTrue(x[1]+" does not exist",element.isDisplayed());
            element.click();
            for(int i=20;i<30;i++){
                x=readCSV("TabFormTestData.csv",i);
                switch(Integer.parseInt(x[3]) ){
                    case 1:insertValueAndAssertForTextBox2(driver,x[1],x[2]);
                        break;
                    case 2:insertValueAndAssertForTextBox(driver,x[1],x[2]);
                        break;
                    case 3:setValueAssertForSelect(driver,x[1],x[2]);
                        break;
                    case 4:setValueAndAssertCalender(driver,x[1],x[2],x[4]);
                        break;
                }
            }
           /* insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_houseNo","452");
            insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_district","Bhopal");
            insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_street","HB colony");
            insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_city","Bhopal");
            insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_pinCode","234343");
            setValueAssertForSelect(driver,"selectCombo_bui_ct_addressDetails_bui_wca_country","INDIA");
            insertValueAndAssertForTextBox(driver,"bui_ct_addressDetails_bui_wca_state","MP");
            setValueAndAssertCalender(driver,"bui_ct_addressDetails_bui_wca_addressValidFrom_button","panel2","but20");
            setValueAndAssertCalender(driver,"bui_ct_addressDetails_bui_wca_addressValidTill_button","panel2","but36");
            setValueAssertForSelect(driver,"selectCombo_bui_ct_addressDetails_bui_wca_addressType","Permanent");*/
            x=readCSV("TabFormTestData.csv",34);
            element=driver.findElement(By.id(x[1]));
            assertTrue("save button does not exist",element.isDisplayed());
            element.click();
            driver.switchTo().alert().accept();

            x=readCSV("TabFormTestData.csv",38);
            element=driver.findElement(By.id(x[1]));
            assertTrue(x[1]+" does not exist",element.isDisplayed());
            element.click();
            for(int i=30;i<=32;i++){
                x=readCSV("TabFormTestData.csv",i);
                switch(Integer.parseInt(x[3]) ){
                    case 1:insertValueAndAssertForTextBox2(driver,x[1],x[2]);
                        break;
                    case 2:insertValueAndAssertForTextBox(driver,x[1],x[2]);
                        break;
                    case 3:setValueAssertForSelect(driver,x[1],x[2]);
                        break;
                }
            }
           /* insertValueAndAssertForTextBox(driver,"bui_ct_accountDetails_bui_wca_accountNo","234343");
            setValueAndAssertCalender(driver,"bui_ct_accountDetails_bui_wca_accountStartDate_button","panel2","but20");
            setValueAssertForSelect(driver,"selectCombo_bui_ct_accountDetails_bui_wca_accountType","Saving");
*/
            driver.findElement(By.id("Save19")).click();

        }
    }

    public void insertValueAndAssertForTextBox(WebDriver driver,String id,String value){
        WebElement element;
        element=driver.findElement(By.id(id));
        assertTrue(id+" does not exist", element.isDisplayed());
        element.sendKeys(value);
    }
    public void insertValueAndAssertForTextBox2(WebDriver driver,String id,String value){
        List<WebElement>list;
        list= driver.findElements(By.id(id));
        assertTrue(id+" does not exist", !list.isEmpty());
        for (WebElement x : list) {
            if(x.getTagName().equals("input")){
                x.sendKeys(value);
            }
        }
    }
    public void setValueAndAssertCalender(WebDriver driver, String id,String panelId,String dateId){
        WebElement element;
        List<WebElement> list;
        element=driver.findElement(By.id(id));
        assertTrue(id+" does not exist", element.isDisplayed());
        element.click();
        driver.switchTo().frame("date");

        list=driver.findElements(By.tagName("input"));
        assertTrue("no data in calender does not exist",!list.isEmpty());
        for(WebElement obj:list)
        {
            if(obj.getAttribute("name").equals(dateId)){
                obj.click();
                break;
            }
        }

        driver.switchTo().defaultContent();
        driver.switchTo().frame(panelId);
    }

     public void setValueAssertForSelect(WebDriver driver,String id, String value){
         WebElement element;
         List<WebElement>list;
         element=driver.findElement(By.id(id));
         assertTrue(id+" does not exist", element.isDisplayed());
         element.click();
         element=driver.findElement(By.id("styleDropDown"));
         assertTrue("No drop box found", element.isDisplayed());
         list=element.findElements(By.tagName("li"));
         assertTrue("No data found in drop box",!list.isEmpty());
         for(WebElement obj:list){
             if(obj.getText().equals(value)){
                 obj.click();
                 break;
             }
         }
     }


    public void validationTest1(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        Thread.sleep(2000);
        String[] csvReader=new String[8];
        csvReader=readCSV("TabFormTestData.csv",37);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("address tab  is enabled",element.getAttribute("disabled").equals("true"));
        csvReader=readCSV("TabFormTestData.csv",38);
        element=driver.findElement(By.id(csvReader[1]));

        csvReader=readCSV("TabFormTestData.csv",1);
        /*formQBEtester(driver,csvReader);*/
        List<WebElement> bussinessPartner = driver.findElements(By.id(csvReader[1]));
        //driver.findElements(By.className("udctrl"));//bui_ct_userDetailsInner_bui_wca_businessPartner
        for (WebElement x : bussinessPartner) {
            if(x.getTagName().equals("input")){
                x.sendKeys("abcdrytyutyu6565");
                Thread.sleep(2000);
                x.sendKeys(Keys.TAB);
            }
        }
        driver.switchTo().alert().accept();


        csvReader=readCSV("TabFormTestData.csv",2);
        element=driver.findElement(By.id(csvReader[1])) ;
        element.sendKeys("efg4655467ghh");
        Thread.sleep(2000);
        element.sendKeys(Keys.TAB);
        driver.switchTo().alert().accept();
    }
    public void validationTest2(WebDriver driver)throws InterruptedException{
       WebElement element;
        String[] csvReader=new String[4];
        Thread.sleep(2000);
        csvReader=readCSV("TabFormTestData.csv",24);
        element=driver.findElement(By.id(csvReader[1]));
        element.sendKeys("assad");
        Thread.sleep(2000);
        element.sendKeys(Keys.TAB);
        driver.switchTo().alert().accept();
    }

    public void mandatoryFiledTest(WebDriver driver) throws InterruptedException {
        Thread.sleep(2000);
        String[] csvReader=new String[4];

        for(int i=2;i<20;i++){
            csvReader=readCSV("TabFormTestData.csv",i);
            switch(Integer.parseInt(csvReader[3]) ){
                case 1:insertValueAndAssertForTextBox2(driver,csvReader[1],csvReader[2]);
                    break;
                case 2:insertValueAndAssertForTextBox(driver,csvReader[1],csvReader[2]);
                    break;
                case 3:setValueAssertForSelect(driver,csvReader[1],csvReader[2]);
                    break;
                case 4:setValueAndAssertCalender(driver,csvReader[1],csvReader[2],csvReader[4]);
                    break;
                case 5:insertValueAndAssertForTextBox2(driver,csvReader[1],csvReader[2]);
                    break;
            }
        }
       /* String[] csvReader=new String[4];
        csvReader=readCSV("TabFormTestData.csv",2);
        driver.findElement(By.id(csvReader[1])).sendKeys("24426");
        csvReader=readCSV("TabFormTestData.csv",3);
        List<WebElement> processingCenter = driver.findElements(By.id(csvReader[1]));
        for (WebElement x : processingCenter) {
            if(x.getTagName().equals("input")){
                x.sendKeys("LCenter");
            }
        }

        driver.findElement(By.id("bui_ct_userDetailsInner_bui_wca_firstName")).sendKeys("Ane");

        driver.findElement(By.id("bui_ct_userDetailsInner_bui_wca_middleName")).sendKeys("");
        driver.findElement(By.id("bui_ct_userDetailsInner_bui_wca_lastName")).sendKeys("Remore");
        driver.findElement(By.id("bui_ct_userDetailsInner_bui_wca_email")).sendKeys("Ane@gmail.com");
        driver.findElement(By.id("bui_ct_userDetailsInner_bui_wca_phoneNo")).sendKeys("9434234567");
        List<WebElement> salary = driver.findElements(By.id("bui_ct_userDetailsInner_bui_wca_salary"));
        for (WebElement x : salary) {
            if(x.getTagName().equals("input")){
                x.sendKeys("20000");
            }
        }
        driver.findElement(By.id("bui_ct_userAccessControl_bui_wca_login")).sendKeys("AneRemore");
        driver.findElement(By.id("bui_ct_userAccessControl_bui_wca_password")).sendKeys("abcd1234");
        driver.findElement(By.id("bui_ct_userAccessControl_bui_wca_confirmPassword")).sendKeys("abcd1234");*/
        driver.findElement(By.id("Save19")).click();
        driver.switchTo().alert().accept();

    }

    public void testViewMode(WebDriver driver) throws InterruptedException {
        List<WebElement> list, list2;
        WebElement element;
        openListWindow(driver);
        String[] csvReader=new String[8];
        csvReader=readCSV("TabFormTestData.csv",39);
        driver.switchTo().frame(csvReader[1]);
        Thread.sleep(3000);
        driver.findElement(By.id(csvReader[2])).click();
        Thread.sleep(3000);
        element=driver.findElement(By.id(csvReader[3])).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
      //  System.out.println("size>>"+list.size());
       //list.get(8).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        list2=list.get(Integer.parseInt(csvReader[4])).findElements(By.tagName("td"));
        list2.get(Integer.parseInt(csvReader[5])).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        Thread.sleep(2000);
        driver.findElement(By.id(csvReader[6])).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame(csvReader[7]);
        csvReader=readCSV("TabFormTestData.csv",40);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("Employee Reference does not exist", element.isDisplayed());
        csvReader=readCSV("TabFormTestData.csv",40);
        list=driver.findElements(By.className(csvReader[1]));
        for(WebElement obj:list)
        {
            assertFalse("mandatory element not found in the view result", obj.getAttribute("value").isEmpty());
        }
        csvReader=readCSV("TabFormTestData.csv",42);
        element=driver.findElement(By.id(csvReader[1]));
        element.click();
        list=driver.findElement(By.id(csvReader[2])).findElements(By.tagName("input"));
        for(WebElement obj:list)
        {
            assertTrue("element not disabled", (obj.getAttribute("class").equals(csvReader[3]) || obj.getAttribute("class").equals(csvReader[4])||obj.getAttribute("class").equals(csvReader[5])||obj.getAttribute("class").equals(csvReader[6])));
        }
        csvReader=readCSV("TabFormTestData.csv",43);
        list=driver.findElement(By.id(csvReader[1])).findElements(By.tagName("input"));
        for(WebElement obj:list)
        {
            assertTrue("element not disabled", (obj.getAttribute("class").equals(csvReader[2]) || obj.getAttribute("class").equals(csvReader[3])||obj.getAttribute("class").equals(csvReader[4])||obj.getAttribute("class").equals(csvReader[5])));
        }
        element=driver.findElement(By.id(csvReader[1])).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        assertTrue("wrong no. of records for emp.ref 8 in the editable table",list.size()==Integer.parseInt(csvReader[6]));
        csvReader=readCSV("TabFormTestData.csv",44);
        element=driver.findElement(By.id(csvReader[1]));
        element.click();
        list=driver.findElement(By.id(csvReader[2])).findElements(By.tagName("input"));
        for(WebElement obj:list)
        {
            assertTrue("element not disabled", (obj.getAttribute("class").equals(csvReader[3]) || obj.getAttribute("class").equals(csvReader[4])||obj.getAttribute("class").equals(csvReader[5])||obj.getAttribute("class").equals(csvReader[6])));
        }
    }
    public void testModifyMode(WebDriver driver) throws InterruptedException {
        List<WebElement> list, list2;
        WebElement element;
        int headerPosition=0;
        String[] csvReader=new String[8];
        csvReader=readCSV("TabFormTestData.csv",45);
        openListWindow(driver);
        driver.switchTo().frame(csvReader[1]);
        Thread.sleep(3000);
        driver.findElement(By.id(csvReader[2])).click();
        Thread.sleep(3000);
        element=driver.findElement(By.id(csvReader[3])).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        //list.get(8).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        list2=list.get(Integer.parseInt(csvReader[4])).findElements(By.tagName("td"));
        list2.get(Integer.parseInt(csvReader[5])).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        Thread.sleep(2000);
        driver.findElement(By.id(csvReader[6])).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame(csvReader[7]);
        csvReader=readCSV("TabFormTestData.csv",40);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("Employee Reference does not exist", element.isDisplayed());
        assertTrue("Employee Reference does not match", element.getAttribute("value").equals(csvReader[2]));
        list=driver.findElements(By.className("mandattrdtlsdisbld"));
        for(WebElement obj:list)
        {
            assertFalse("mandatory element not found in the view result for modify", obj.getAttribute("value").isEmpty());
        }
        csvReader=readCSV("TabFormTestData.csv",38);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("address tab  is enabled",element.getAttribute("disabled").equals("true"));

        csvReader=readCSV("TabFormTestData.csv",46);
        List<WebElement> processingCenter = driver.findElements(By.id(csvReader[1]));
        for (WebElement x : processingCenter) {
            if(x.getTagName().equals("input")){

                x.sendKeys(Keys.CONTROL + "a");
                x.sendKeys(csvReader[2]);

            }
        }
        csvReader=readCSV("TabFormTestData.csv",34);
        driver.findElement(By.id(csvReader[1])).click();
        driver.switchTo().alert().accept();
        Thread.sleep(1000);
        csvReader=readCSV("TabFormTestData.csv",37);
        element=driver.findElement(By.id(csvReader[1]));
       // assertFalse("address tab  is disabled",element.getAttribute("disabled").equals("true"));
        element.click();
        csvReader=readCSV("TabFormTestData.csv",48);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("bui_ct_addressDetails_bui_wca_city does not exist",element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(csvReader[2]);
        csvReader=readCSV("TabFormTestData.csv",49);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("bui_ct_AddressDetailsTable_wca_city does not exist",element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(csvReader[2]);
        csvReader=readCSV("TabFormTestData.csv",34);
        driver.findElement(By.id(csvReader[1])).click();
        driver.switchTo().alert().accept();
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        Thread.sleep(2000);
        csvReader=readCSV("TabFormTestData.csv",38);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("but_bui_ct_accountDetails does not exist",element.isDisplayed());
        element.click();
        csvReader=readCSV("TabFormTestData.csv",50);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("bui_ct_accountDetails_bui_wca_accountNo does not exist",element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(csvReader[2]);
        csvReader=readCSV("TabFormTestData.csv",34);

       driver.findElement(By.id(csvReader[1])).click();
        driver.switchTo().alert().accept();

        csvReader=readCSV("TabFormTestData.csv",51);
        driver.switchTo().defaultContent();
        driver.findElement(By.className(csvReader[1])).findElement(By.tagName("span")).click();
        openListWindow(driver);
        driver.switchTo().frame(csvReader[2]);
        Thread.sleep(3000);
        driver.findElement(By.id(csvReader[3])).click();
        Thread.sleep(3000);
        element=driver.findElement(By.id(csvReader[4])).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(csvReader[5]))
                break;
            headerPosition++;
        }
        list2=list.get(Integer.parseInt(csvReader[6])).findElements(By.tagName("td"));
        assertTrue("Data not saved in database",list2.get(headerPosition).getText().equals(csvReader[7]));

        list2.get(Integer.parseInt(csvReader[8])).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        driver.findElement(By.id(csvReader[9])).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame(csvReader[10]);
    //    driver.findElement(By.id("Save19")).click();
      //  driver.switchTo().alert().accept();
        csvReader=readCSV("TabFormTestData.csv",37);

        element=driver.findElement(By.id(csvReader[1]));
        element.click();

        csvReader=readCSV("TabFormTestData.csv",48);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("value not saved in data base",element.getAttribute("value").equals(csvReader[2]));

        csvReader=readCSV("TabFormTestData.csv",49);
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("value not saved in data base",element.getAttribute("value").equals(csvReader[2]));

        csvReader=readCSV("TabFormTestData.csv",50);
        element=driver.findElement(By.id("but_bui_ct_accountDetails"));
        element.click();
        element=driver.findElement(By.id(csvReader[1]));
        assertTrue("value not saved in data base",element.getAttribute("value").equals(csvReader[2]));
    }


    public void openWindow(WebDriver driver) {
        WebElement element;
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
    }
    public void openListWindow(WebDriver driver) throws InterruptedException {
        WebElement element;
        List<WebElement> list,list2;
        driver.switchTo().defaultContent();
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.RETURN);
        Thread.sleep(3000);
    }
/*    public Properties getProperty() throws IOException {
        Properties home = new Properties();
        FileInputStream in = new FileInputStream("TabForm.properties");
        home.load(in);
        return home;
    }*/
    public void formQBEtester(WebDriver driver,String[] csvReader) throws InterruptedException, IOException {

        switchToPanel(driver,csvReader[4]);
        WebElement element;
        Thread.sleep(2000);
         System.out.println("Processing Center QBE");
        driver.findElement(By.id(csvReader[5])).click();

        WebElement e = doubleClickTable(driver,csvReader[6],csvReader[2]);
        System.out.println("BPId is:"+csvReader[2]);
        if(e!=null){
            doubleClick(driver,e);
        }
        else
        {
            assertTrue("No data found after clicking the QBE Search",e.equals(null));
        }
    }
    public WebElement doubleClickTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));

        for (WebElement row : allRows) {
            table=null;
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public void doubleClick(WebDriver driver, WebElement e) {

        try{
            //For IE
            e.click();
            ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);

            // For FireFox and Chrome
            /*((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                    "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                    "arguments[0].dispatchEvent(evt);", e);*/
        }catch (Exception ex){}
    }


    public void switchToPanel(WebDriver  driver,String QBEID) throws InterruptedException, IOException {
        Thread.sleep(1000);
        /*Properties form = getProperty();*/
        driver.findElement(By.id(QBEID)).click();
        driver.switchTo().frame("CWpanel1");
        driver.switchTo().frame("mywindowframe");
    }


}
