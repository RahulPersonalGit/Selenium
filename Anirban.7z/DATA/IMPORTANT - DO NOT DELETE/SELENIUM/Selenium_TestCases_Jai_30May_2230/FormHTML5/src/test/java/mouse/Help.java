package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Properties;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 11:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class Help extends Arrays{
    public void testHelp(WebDriver driver) throws IOException, InterruptedException {
        Properties help=new MenuBar().getProperty();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        for(String a:helpOptionsArray){
        	//assertTrue("help not found",GUIMODappTest.isElementPresent(By.id(help.getProperty("help"))));
            driver.findElement(By.id(help.getProperty("help"))).click();
            //assertTrue(a+" not found",GUIMODappTest.isElementPresent(By.linkText(help.getProperty(a))));
            driver.findElement(By.linkText(help.getProperty(a))).click();
        }
        //assertTrue("close About Bancs not found",GUIMODappTest.isElementPresent(By.id(help.getProperty("closeAboutBancs"))));
        driver.findElement(By.id(help.getProperty("closeAboutBancs"))).click();
    }
}