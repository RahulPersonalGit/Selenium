package keyBoard;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 12/4/12
 * Time: 11:49 AM
 * To change this template use File | Settings | File Templates.
 */
public class Testing {
    public static  void  main(String args[]) throws InterruptedException {
        WebDriver driver=new FirefoxDriver() ;
        driver.get("http://www.google.com");
        Thread.sleep(2000L);
        driver.quit();
    }
}
