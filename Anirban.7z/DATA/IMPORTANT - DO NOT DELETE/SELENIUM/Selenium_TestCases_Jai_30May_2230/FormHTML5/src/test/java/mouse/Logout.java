package mouse;

import SeleniumGrid.GUIMODappTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Properties;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 12:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class Logout {
    public void testLogout(WebDriver driver) throws InterruptedException, IOException {
        MenuBar menuBar=new MenuBar();
        GUIMODappTest GUIMODappTest =new GUIMODappTest();
        Properties logout=menuBar.getProperty();
       // assertTrue("logout not found",GUIMODappTest.isElementPresent(By.id(logout.getProperty("logout"))));
        driver.findElement(By.id(logout.getProperty("logout"))).click();
       // assertTrue("cancel not found",GUIMODappTest.isElementPresent(By.linkText(logout.getProperty("cancel"))));
        driver.findElement(By.linkText(logout.getProperty("cancel"))).click();
        driver.findElement(By.id(logout.getProperty("logout"))).click();
        driver.findElement(By.xpath("html/body/div[7]/div[2]/span/a")).click();
    }
}
