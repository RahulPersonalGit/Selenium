package SeleniumGrid;


import mouse.TstCaseStarter;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

import static org.junit.Assert.fail;

public class GUIMODappTest extends BrowserConfig {
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    static CsvReader csvReader = new CsvReader();
    static CommonFunctions commonFunctions = new CommonFunctions();

    public void ExecuteTest(WebDriver driver, String browserName) throws Exception {
          driver.get(baseUrl);
          TstCaseStarter TstCaseStarter =new TstCaseStarter();
          TstCaseStarter.testUi(driver);
    }

    @Before
    public void setUp() throws Exception {
    }
    @Test
    public void testDemo() {
        if (SeleniumGrid.equals("Y")) {
            for (DesiredCapabilities browser : browsers) {
                driver = null;
                try {
                    System.out.println("original URL");
                    driver = new RemoteWebDriver(new URL(URL), browser);
                    ExecuteTest(driver,browser.getBrowserName());
                } catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                } finally {
                    if (driver != null) {
                        driver.quit();
                    }
                }
            }
        } else {
            driver = null;
            System.setProperty("webdriver.chrome.driver","D:\\selenium\\chromedriver.exe");
//            driver = new ChromeDriver();
             driver = new InternetExplorerDriver();
            /*driver = new FirefoxDriver(); */
            try {
                System.out.println("original URL from file.properties");
                ExecuteTest(driver, null);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
                driver.quit();
            }
        }
    }

    @After
    public void quitDriver() {
        System.out.println("over");
    }
    public void tearDown() throws Exception {
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }
    public boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}