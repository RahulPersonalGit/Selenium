package keyBoard;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/30/12
 * Time: 5:29 PM
 * To change this template use File | Settings | File Templates.
 */
public class MenuKeys {
    public void pressKeys(WebDriver driver){
//        testRi(driver);
        testSM(driver);
    }
    public void testRi(WebDriver driver){
        WebElement element;

        System.out.println("Menu Bar");
        element=driver.findElement(By.id("menubar_container"));

        System.out.println("After looping");
        for(int count=0;count<4;count++){
            testReachRi(driver);
            for(int innerCount=0;innerCount<count;innerCount++)
                element.sendKeys(Keys.DOWN);
            element.sendKeys(Keys.ENTER);
        }
    }
    public void testReachRi(WebDriver driver){
        WebElement element;
        element=driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.RETURN);
    }
    public void testSM(WebDriver driver){
    //    testSMCreate(driver);
        testSMList(driver);
    }
    public void testSMCreate(WebDriver driver){
        WebElement element;

        System.out.println("Menu Bar");
        element=driver.findElement(By.id("menubar_container"));

        System.out.println("After looping");
        for(int count=0;count<20;count++){
            testReachSMCreate(driver);
            for(int innerCount=0;innerCount<count;innerCount++)
                element.sendKeys(Keys.DOWN);
            element.sendKeys(Keys.ENTER);
        }
    }
    public void testReachSMCreate(WebDriver driver){
        WebElement element;
        element=driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
    }
    public void testSMList(WebDriver driver){
        WebElement element;

        System.out.println("Menu Bar");
        element=driver.findElement(By.id("menubar_container"));

        System.out.println("After looping");
        for(int count=0;count<12;count++){
            testReachSMList(driver);
            for(int innerCount=0;innerCount<count;innerCount++)
                element.sendKeys(Keys.DOWN);
            element.sendKeys(Keys.ENTER);
        }
    }
    public void testReachSMList(WebDriver driver){
        WebElement element;
        element=driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.RIGHT);
    }

}