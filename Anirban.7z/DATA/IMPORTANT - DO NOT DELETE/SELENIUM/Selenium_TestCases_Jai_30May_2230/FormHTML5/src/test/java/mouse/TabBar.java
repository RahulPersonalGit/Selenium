package mouse;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 5:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class TabBar{
    public void testCloseTabs(WebDriver driver,int[] tab) throws IOException {
        WebElement element;
        MenuBar menuBar=new MenuBar();
        Properties tabs=menuBar.getProperty();
        for(int a:tab){
            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==a){
                    List<WebElement> allLiElements=li.findElements(By.tagName("span"));
                    for(WebElement span:allLiElements)
                        element=span;
                    //assertTrue(element+"not found",element.isDisplayed());
                    element.click();
                    break;
                }
                i++;
            }
        }
    }
}