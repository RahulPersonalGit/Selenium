package mouse;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.io.IOException;
import java.util.Properties;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 2:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class Tiling extends  Arrays{
    public void testTiling(WebDriver driver) throws InterruptedException, IOException {
        MenuBar menuBar=new MenuBar();
        //GUIMODappTest guimodAppTest=new GUIMODappTest();
        Properties tiling=menuBar.getProperty();
        for(int i=0;i<2;i++){
            //assertTrue("Tiling not found ",uimodAppTest.isElementPresent(By.className(tiling.getProperty("tiling"))));
            driver.findElement(By.className(tiling.getProperty("tiling"))).click();
            Thread.sleep(new Constants().HUNDREDMILLISECONDS);
            //assertTrue(tabs[0]+" not found",uimodAppTest.isElementPresent(By.id(tiling.getProperty(tabs[0]))));
            driver.findElement(By.id(tiling.getProperty(tabs[0]))).click();
            //assertTrue(tabs[i]+" not found",uimodAppTest.isElementPresent(By.id(tiling.getProperty(tabs[i]))));
            if(i==1)
              driver.findElement(By.id(tiling.getProperty(tabs[i]))).click();
            driver.findElement(By.linkText(tiling.getProperty(tilingButton[i]))).click();
            try{
                Alert alert = driver.switchTo().alert();
                alert.accept();
            }catch (Exception e){continue;}
        }
    }
}