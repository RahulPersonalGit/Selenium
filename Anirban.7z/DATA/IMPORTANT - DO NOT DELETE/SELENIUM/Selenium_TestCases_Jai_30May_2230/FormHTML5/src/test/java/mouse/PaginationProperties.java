package mouse;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/14/13
 * Time: 6:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class PaginationProperties {
    private boolean flag;
    private List<String> data;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
