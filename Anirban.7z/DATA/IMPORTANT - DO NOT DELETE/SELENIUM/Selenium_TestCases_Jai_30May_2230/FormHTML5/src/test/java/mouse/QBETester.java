package mouse;

/**
 * Created with IntelliJ IDEA.
 * User: 547798
 * Date: 2/11/13
 * Time: 6:44 PM
 * To change this template use File | Settings | File Templates.
 */
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import sun.awt.Symbol;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class QBETester {
    public void QBESearchListTest1(WebDriver driver) throws InterruptedException {
        OpenQBE(driver);
        List<WebElement> list;
        WebElement element;
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        //  setValueAndAssert(driver,"MCB_SearchWC_wca_employeeReference","Employee Reference","1","srchBut_2","bui_w_SearchListQBE_Table");        setValueAndAssert1(driver,"MCB_SearchWC_wca_loginId","Login Id","awse","srchBut_2","bui_w_SearchListQBE_Table");
        setValueAndAssert1(driver, "MCB_SearchWC_wca_firstName", "User Name", "arwa", "srchBut_2", "bui_w_SearchListQBE_Table");
        setValueAndAssert2(driver,"MCB_SearchWC_wca_businessPartner","Business Partner","4","srchBut_2","bui_w_SearchListQBE_Table");
        setValueAndAssertSelect(driver,"selectCombo_MCB_SearchWC_wca_userStatus_Text","User Status","Entered","srchBut_2","bui_w_SearchListQBE_Table");
        driver.findElement(By.id("selectCombo_MCB_SearchWC_wca_userStatus_Text")).click();
        Thread.sleep(2000);
        element=driver.findElement(By.id("styleDropDown"));
        list=element.findElements(By.tagName("li"));
        for(WebElement obj:list){
            if(obj.getText().equals("")){
                obj.click();
                break;
            }
        }
        setValueAndAssertCalender(driver,"MCB_SearchWC_wca_userEffectiveDate_button","User Effective Date","04/12/2012","srchBut_2","bui_w_SearchListQBE_Table","panel2","but9") ;

    }
    public void testGLQBE(WebDriver driver) throws InterruptedException {
        PaginationTester paginationTester=new PaginationTester();
        WebElement element,element1;
        CommonFunctions commonFunctions=new CommonFunctions();
        List<WebElement> list,list2;
        driver.switchTo().defaultContent();
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
        Thread.sleep(3000);
        driver.switchTo().frame("panel2");
        String[] headers={"wca_loginId","wca_firstName","wca_businessPartner"};
       // testPreNext(driver,"SearchNow1","bui_ct_GL_qbeAllControlsSearchList_Table_next_but","bui_ct_GL_qbeAllControlsSearchList_Table_prev_but");
        //assertTrue("pagination failed",testPagination(driver,"bui_ct_GL_qbeAllControlsSearchList_Table","bui_ct_GL_qbeAllControlsSearchList_Table_next_but","bui_ct_GL_qbeAllControlsSearchList_Table_prev_but"));
        assertTrue("pagination using 3 column failed",paginationTester.testThreeColumnPagination(driver,"bui_ct_GL_qbeAllControlsSearchList_Table","bui_ct_GL_qbeAllControlsSearchList_Table_next_but","bui_ct_GL_qbeAllControlsSearchList_Table_prev_but",headers));
        setValueAndAssert1(driver, "bui_ct_GL_qbeAllControlsSearch_wca_employeeReference_Value", "Employee Reference", "1", "SearchNow1", "bui_ct_GL_qbeAllControlsSearchList_Table");
        setValueAndAssert1(driver,"bui_ct_GL_qbeAllControlsSearch_wca_loginId_Value","Login Id","awse","SearchNow1","bui_ct_GL_qbeAllControlsSearchList_Table");
        setValueAndAssert1(driver,"bui_ct_GL_qbeAllControlsSearch_wca_lastLoginTime_Value","Last Logged in Time","111111","SearchNow1","bui_ct_GL_qbeAllControlsSearchList_Table");
        setValueAndAssertSelect(driver,"selectCombo_bui_ct_GL_qbeAllControlsSearch_wca_userStatus_Value_Text","User Status","Entered","SearchNow1","bui_ct_GL_qbeAllControlsSearchList_Table");
        setValueAndAssertCalender(driver,"bui_ct_GL_qbeAllControlsSearch_wca_userEffectiveDate_img","User Effective Date","04/12/2012","SearchNow1","bui_ct_GL_qbeAllControlsSearchList_Table","panel2","but9") ;
        // assertTrue("pagination failed",testPagination(driver,"bui_ct_GL_qbeAllControlsSearchList_Table","bui_ct_GL_qbeAllControlsSearchList_Table_next_but","bui_ct_GL_qbeAllControlsSearchList_Table_prev_but"));
        driver.findElement(By.id("selectCombo_bui_ct_GL_qbeAllControlsSearch_wca_userStatus_Value_Text")).click();
        //  Thread.sleep(1000);
        element=driver.findElement(By.id("styleDropDown"));
        list=element.findElements(By.tagName("li"));
        for(WebElement obj:list){
            if(obj.getText().equals("")){
                obj.click();
                break;
            }
        }


    }
    public void testRangeQBE(WebDriver driver) throws InterruptedException {
        WebElement element;
        CommonFunctions commonFunctions=new CommonFunctions();
        List<WebElement> list,list2;
        driver.switchTo().defaultContent();
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
        Thread.sleep(3000);
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);

        String[] valueL={"awse","a","f"};
        String[] valueB={"4","1","5"};
        String[] idLogin={"MCB_SearchWC_wca_loginID","MCB_SearchWC_wca_loginID_op","divcol_MCB_SearchWC_wca_loginID","MCB_SearchWC_wca_loginID_From","MCB_SearchWC_wca_loginID_To"};
        String[] idBP={"MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_businessPartner_op","divcol_MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_businessPartner_From","MCB_SearchWC_wca_businessPartner_To"};
       // testPreNext(driver,"srchBut_0","bui_w_TestRangeQBE_Table_next_but","bui_w_TestRangeQBE_Table_prev_but");
        rangeQBE(driver,idLogin,"Login Id",valueL,"srchBut_0","bui_w_TestRangeQBE_Table",0);
        rangeQBE(driver,idBP,"Buisness Partner",valueB,"srchBut_0","bui_w_TestRangeQBE_Table",5);


    }
    public void setValueAndAssert1(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId) throws InterruptedException   {
        WebElement element;
        CommonFunctions commonFunctions = new CommonFunctions();
        element=driver.findElement(By.id(id));
        element.sendKeys(value);
        driver.findElement(By.id(buttonID)).click();
        assertTrue("table data not match", verifySearchCondition(driver, columnName, tableId, value));
        commonFunctions.clearContent(driver, element);

    }
    public void setValueAndAssert2(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId) throws InterruptedException{
        WebElement element=null;
        CommonFunctions commonFunctions = new CommonFunctions();
        List<WebElement> processingCenter = driver.findElements(By.id(id));
        for (WebElement x : processingCenter) {
            if(x.getTagName().equals("input")){
                element=x;
                x.sendKeys(value);
            }
        }
        driver.findElement(By.id(buttonID)).click();
        assertTrue("table data not match",verifySearchCondition(driver,columnName,tableId,value));
        commonFunctions.clearContent(driver,element);
    }
    public void setValueAndAssertSelect(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId) throws InterruptedException{
        WebElement element;
        List<WebElement> list;
        driver.findElement(By.id(id)).click();
        Thread.sleep(1000);
        element=driver.findElement(By.id("styleDropDown"));
        assertTrue("No drop box found", element.isDisplayed());
        list=element.findElements(By.tagName("li"));
        assertTrue("No data found in drop box",!list.isEmpty());
        for(WebElement obj:list){
            if(obj.getText().equals("Entered")){
                obj.click();
                break;
            }
        }
        driver.findElement(By.id(buttonID)).click();
        assertTrue("table data not match", verifySearchCondition(driver,columnName,tableId,value));
    }
    public void setValueAndAssertCalender(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId,String panelId,String dateId) throws InterruptedException{
        WebElement element;
        List<WebElement> list;
        CommonFunctions commonFunctions = new CommonFunctions();
        element=driver.findElement(By.id(id));
        assertTrue("MCB_SearchWC_wca_userEffectiveDate_button does not exist",element.isDisplayed());
        element.click();
        driver.switchTo().frame("date");
        list=driver.findElements(By.tagName("input"));
        assertTrue("no data in calender",!list.isEmpty());
        for(WebElement obj:list)
        {
            if(obj.getAttribute("name").equals(dateId)){
                obj.click();
                break;
            }
        }
        driver.switchTo().defaultContent();
        driver.switchTo().frame(panelId);
        driver.findElement(By.id(buttonID)).click();
        assertTrue("table data not match",verifySearchCondition(driver,columnName,tableId,value));
    }
    public void OpenQBE(WebDriver driver) throws InterruptedException {
        WebElement element;
        List<WebElement> list,list2;
      //  driver.switchTo().defaultContent();
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
        Thread.sleep(3000);
    }
    public void  rangeQBE(WebDriver driver,String[] inputId,String columnID,String[] value,String buttonId,String tableId,int anchorvalue) throws InterruptedException {
        WebElement element;
        List<WebElement>list;
        CommonFunctions commonFunctions=new CommonFunctions();
        setValueAndAssert2(driver,inputId[0],columnID,value[0],buttonId,tableId);
        element=driver.findElement(By.id(inputId[1]));
        assertTrue(inputId[1]+" does not exist",element.isDisplayed());
        list=element.findElements(By.tagName("option"));
        for (WebElement x :list) {
            if(x.getAttribute("value").equals("Between")){
                x.click();
                break;
            }
        }
        Thread.sleep(2000);
        list=driver.findElements(By.tagName("a"));
        list.get(anchorvalue).click();
        Thread.sleep(5000);
        WebElement elementDiv=driver.findElement(By.id(inputId[2]));
        assertTrue("No box to enter",element.isDisplayed());
        Thread.sleep(2000);
        element=driver.findElement(By.id(inputId[3]));
        assertTrue(inputId[3]+" not exist",element.isDisplayed());
        element.sendKeys(value[1]);
        element=driver.findElement(By.id(inputId[4]));
        assertTrue(inputId[4]+" not exist",element.isDisplayed());
        element.sendKeys(value[2]);
        list=elementDiv.findElements(By.tagName("a"));
        list.get(0).click();
        element=driver.findElement(By.id("srchBut_0"));
        element.click(); //MCB_SearchWC_wca_loginID
        element=driver.findElement(By.id("MCB_SearchWC_wca_loginID"));
//        commonFunctions.clearContent(driver,element);
    }
    public boolean verifySearchCondition(WebDriver driver, String header,String tableId,String value) throws InterruptedException {

        int rqdHeadrIndex = 0, rqdDataIndex = 0;
        List<WebElement> allRows = readTableContent(driver, tableId, "tr");

        //DO NOT DELETE , REQUIRED TO READ TABLE HEADERS
        for (WebElement row : allRows) {
            List<WebElement> tableHeaders = row.findElements(By.tagName("th"));
            for (WebElement cell : tableHeaders) {
                if (cell.getText().equals(header)) {
                    break;
                }
                rqdHeadrIndex++;
            }
        }            // i points to position where "user name" exists
        //TO READ THE ROW DATA
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                continue;
            }
            rqdDataIndex = 0;
            for (WebElement cell : tableData) {

                if(rqdDataIndex == rqdHeadrIndex)
                {
                    if(cell.getText().equals(value))
                    {
                        rqdDataIndex++;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public List<WebElement> readTableContent(WebDriver driver,String tableId, String tagName) throws InterruptedException {
        WebElement table = driver.findElement(By.id(tableId));
        List<WebElement> allRows = table.findElements(By.tagName(tagName));
        return allRows;
    }
    public void testHiddenFieldPagination(WebDriver driver) throws InterruptedException {
        WebElement element;
        PaginationTester paginationTester=new PaginationTester();
        element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
        Thread.sleep(3000);
        driver.switchTo().frame("panel2");
        String[] headers={"wca_loginId","wca_businessPartner","wca_employeeReference"};
         driver.findElement(By.id("Search")).click();
        Thread.sleep(3000);
        assertTrue("pagination using 3 column failed",paginationTester.testThreeColumnPagination(driver,"bui_w_userListCADSL_Table","bui_w_userListCADSL_Table_next_but","bui_w_userListCADSL_Table_prev_but",headers));



       // testPreNext(driver,"Search","bui_w_UserListADSL_Table_next_but","bui_w_UserListADSL_Table_prev_but");
      //  assertTrue("pagination failed",testPagination(driver,"bui_w_UserListADSL_Table","bui_w_UserListADSL_Table_next_but","bui_w_UserListADSL_Table_prev_but"));
    }
}


