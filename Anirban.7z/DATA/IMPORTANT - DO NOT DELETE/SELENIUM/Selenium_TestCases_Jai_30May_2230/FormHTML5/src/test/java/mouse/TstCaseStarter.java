package mouse;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Properties;

@RunWith(BlockJUnit4ClassRunner.class)
public class TstCaseStarter extends Arrays {
    private WebDriver driver;
    private String chromeDriverPath;

    @Before
    public void createDriver() {
        getBrowser();
    }

    private void getChrome() throws IOException {
        Properties path = new MenuBar().getProperty();
        System.setProperty("webdriver.chrome.driver", path.getProperty("chromePath"));
        driver = new ChromeDriver();
    }

    private void getInternetExplorer() {
        driver = new InternetExplorerDriver();
    }

    private void getFirefox() {
        driver = new FirefoxDriver();
    }

    @After
    public void quitDriver() {
        System.out.println("over");
    }

    public void testUi(WebDriver driver) {
       try{
        testLogin(driver);
        Thread.sleep(new Constants().FIVETHOUSANDMILLISECONDS);
        FormTypeTesterNewTemplate formTesterNew = new FormTypeTesterNewTemplate();
        formTesterNew.FormTypeTest(driver);
       }catch(Exception e){
           System.out.println("Form Test Case Failure");
       }

    }

    public void testLogin(WebDriver driver) throws Exception {
        try {
            WebElement element;
            element = driver.findElement(By.name("userId"));
            element.sendKeys("aparna");
            Thread.sleep(2000);
            element = driver.findElement(By.id("password"));
            element.sendKeys("tcs1");
            element.click();
            element.sendKeys(Keys.TAB);
            Thread.sleep(2000);
            if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) {
                driver.findElement(By.id("Login")).sendKeys(Keys.ENTER);
            } else {
                driver.findElement(By.id("Login")).click();
            }
        } catch (Exception e) {
            System.out.println("Login failure" + e);
        }
    }

    private void getBrowser() {
        Properties browser = new Properties();
        try {
            FileInputStream in = new FileInputStream("Browser.properties");
            browser.load(in);
            String browser_Name = browser.getProperty("browser");
            chromeDriverPath = browser.getProperty("chromeDriver");
            Method method = TstCaseStarter.class.getDeclaredMethod("get" + browser_Name);
            method.invoke(this);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void operations2(WebDriver driver) throws Exception {
        new Help().testHelp(driver);
//        new Favorites().testAddHelpAndHome(driver);
//        new Messages().testMessages(driver);
        new Preferences().testPreferences(driver);
        new Tiling().testTiling(driver);
        new BirdsEyeView().testBirdsEyeView(driver);
//        new MenuBar().openClose(driver);
        new Logout().testLogout(driver);
    }

    public void operations1(WebDriver driver) throws IOException, InterruptedException {

        MenuBar menuBar = new MenuBar();
        Favorites favorites = new Favorites();
        TabBar tabBar = new TabBar();

        Thread.sleep(3000);
        new APPHeader().testAppHeader(driver);
        Thread.sleep(1000);
        menuBar.testMenuBar(driver);
        Thread.sleep(1000);
//        favorites.testRemoveAllFavorites(driver);
//        favorites.testFavourites(driver);
        System.out.println("C11");
        tabBar.testCloseTabs(driver, tabNumbers);
//        menuBar.testExtraRM(driver);
//        favorites.testAddMore(driver);
//        favorites.testOpenAdded(driver);
//        favorites.testOrganizeFavourites(driver);
//        tabBar.testCloseTabs(driver,tabNumbers);
    }

    public void initiateDecoratedComboBox(WebDriver driver, String[] ListDataFromCSV, String elementType) throws InterruptedException {
        WebElement element;
        Actions builder = new Actions(driver);
        Thread.sleep(3000);
        //need to remove the button click functionality
        ButtonClick(driver, ListDataFromCSV[0]);
        element = driver.findElement(By.id(ListDataFromCSV[1]));
        List<WebElement> allLiElements = element.findElements(By.tagName(elementType));
        for (WebElement li : allLiElements) {
            if (li.getText().equals(ListDataFromCSV[2]) && li.findElements(By.tagName("a")).size() == 0) {
                builder.moveToElement(li).click().build().perform();
                break;
            }
            if (li.getText().equals(ListDataFromCSV[2]) && li.findElements(By.tagName("a")).size() != 0) {
                builder.moveToElement(li.findElement(By.tagName("a"))).click().build().perform();
                break;
            }
        }
        Thread.sleep(2000);
    }

    public void ButtonClick(WebDriver driver, String buttonID) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By.id(buttonID)).click();
    }


}