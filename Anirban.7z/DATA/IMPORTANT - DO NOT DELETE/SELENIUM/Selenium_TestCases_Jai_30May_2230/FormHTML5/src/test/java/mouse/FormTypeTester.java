package mouse;

import SeleniumGrid.CommonFunctionsForQBE;
import org.openqa.selenium.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 560216
 * Date: 2/26/13
 * Time: 11:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class FormTypeTester {
    public void FormTypeTest(WebDriver driver) throws InterruptedException, IOException {

        int testKey[] = {3,4};
        String testData[]={"HDFC BANK","75542","INR","343450","75,542.00","343,450.00"};
        openWindow(driver);
        Thread.sleep(2000);
        openFormWindow(driver,testKey);
        testformViewMode(driver,testKey);
        Thread.sleep(2000);
        testFormModifyMode(driver,testKey,testData);
    }
    public Properties getProperty() throws IOException {
        Properties Form = new Properties();
        FileInputStream in = new FileInputStream("Form.properties");
        Form.load(in);
        return Form;
    }

    public void openWindow(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        CommonFunctionsForQBE comm = new CommonFunctionsForQBE();
        comm.openPage(driver, "ADSL_LIST");
        /*element = driver.findElement(By.id(form.getProperty("MENU")));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.RETURN);*/
    }
    public void openFormWindow(WebDriver driver, int[] testKey) throws InterruptedException, IOException {
        WebElement element;
        List<WebElement> list, list2;
        Properties form = getProperty();
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(2000);
        element=driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        list2=list.get(testKey[1]).findElements(By.tagName("td"));
        list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).click();
        driver.switchTo().defaultContent();

    }
   /* public void Asserttrue(String msg,WebElement element)
    {
        Selenium selenium;
        if(!element.())
        {
            System.out.println("Element not displayed");
        }
    }*/
    public void testformViewMode(WebDriver driver, int[] testKey) throws InterruptedException, IOException {
        WebElement element;
        List<WebElement> list;
        Properties form = getProperty();
        Thread.sleep(2000);
        String key = Integer.toString(testKey[0]);
        driver.switchTo().frame("panel3");
        element=driver.findElement(By.id(form.getProperty("EMPLOYEE_REF")));
        /*Asserttrue("abqa",element);*/
        assertTrue("Employee Reference does not exist", element.isDisplayed());
        assertTrue("Employee Reference does not match", element.getAttribute("value").equals(key));
        list=driver.findElement(By.id(form.getProperty("GROUPBOX_0"))).findElements(By.tagName("input"));
        for(WebElement obj:list)
        {
            assertTrue("element not disabled", (obj.getAttribute("class").equals("leftalign attrdtlsdisbld") || obj.getAttribute("class").equals("leftalign mandattrdtlsdisbld")||obj.getAttribute("class").equals("txtDiv_disabled")||obj.getAttribute("class").equals("img_ButtonwithRedSquare_disable")));
        }

        list=driver.findElement(By.id(form.getProperty("GROUPBOX_1"))).findElements(By.tagName("input"));
        for(WebElement obj:list)
        {
            assertTrue("element not disabled", (obj.getAttribute("class").equals("rightalign attrdtlsdisbld") ||obj.getAttribute("class").equals("leftalign attrdtlsdisbld") || obj.getAttribute("class").equals("icon_mini_search_disable")||obj.getAttribute("class").equals("txtDiv_disabled")||obj.getAttribute("class").equals("img_ButtonwithRedSquare_disable")||obj.getAttribute("class").equals("spattrdtls")));
        }

        element=driver.findElement(By.id("Save&Close3"));
        assertTrue("Save&Close button should be disabled in View mode",element.getAttribute("disabled").equals("true"));

        element=driver.findElement(By.id("Save4"));
        assertTrue("Save button should be disabled in View mode",element.getAttribute("disabled").equals("true"));

        driver.findElement(By.id("Close5")).click();
    }
    public void testFormModifyMode(WebDriver driver, int[] testKey, String[] testData) throws InterruptedException, IOException {
        List<WebElement> list, list2;
        WebElement element;
        Properties form = getProperty();
        driver.switchTo().defaultContent();
        String key = Integer.toString(testKey[0]);
        Thread.sleep(3000);
        driver.switchTo().frame("panel2");
        Thread.sleep(3000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(3000);
        element=driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        list2=list.get(testKey[1]).findElements(By.tagName("td"));
        list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("MODIFY_ACCOUNT"))).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel4");
        element=driver.findElement(By.id(form.getProperty("EMPLOYEE_REF")));
        assertTrue("Employee Reference does not exist", element.isDisplayed());
        assertTrue("Employee Reference does not match", element.getAttribute("value").equals(key));


        element=driver.findElement(By.id(form.getProperty("ACCOUNT_NO")));
        assertTrue("Account No is not Read-only",element.getAttribute("readOnly").equals("true"));

        element=driver.findElement(By.id(form.getProperty("EMPLOYEE_REF")));
        assertTrue("Employee Reference is not Read-only",element.getAttribute("readOnly").equals("true"));

        element=driver.findElement(By.id(form.getProperty("BANK_NAME")));
        assertTrue("Bank Name field  does not exist",element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(testData[0]);

        List<WebElement> salary = driver.findElements(By.id(form.getProperty("SALARY")));
        for (WebElement x : salary) {
            if(x.getTagName().equals("input")){
                x.sendKeys(Keys.CONTROL + "a");
                x.sendKeys(testData[1]);
            }
        }

        setValueAssertForSelect(driver,form.getProperty("CURR_COMBO"),testData[2]);

        List<WebElement> balance = driver.findElements(By.id(form.getProperty("BALANCE")));
        for (WebElement x : balance) {
            if(x.getTagName().equals("input")){
                x.sendKeys(Keys.CONTROL + "a");
                x.sendKeys(testData[3]);
            }
        }

        formQBEtester(driver,testKey[0]);
        List<WebElement> processingCenter = driver.findElements(By.id(form.getProperty("PROCESSING_CENTER")));
        for (WebElement x : processingCenter) {
            if(x.getTagName().equals("input")){
                assertTrue("Parent to Child data passing in QBE failed", x.getAttribute("value").equals(""));
            }
        }

        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame("panel4");

        driver.findElement(By.id("Save4")).click();
        driver.switchTo().alert().accept();
        Thread.sleep(1000);
        driver.findElement(By.id("Close5")).click();
        driver.switchTo().defaultContent();

        Thread.sleep(1000);
        driver.switchTo().frame("panel2");
        Thread.sleep(2000);
        driver.findElement(By.id(form.getProperty("SEARCH_BUTTON"))).click();
        Thread.sleep(3000);
        element=driver.findElement(By.id(form.getProperty("TABLE_ID"))).findElement(By.tagName("tbody"));
        list=element.findElements(By.tagName("tr"));
        list2=list.get(testKey[1]).findElements(By.tagName("td"));
        list2.get(testKey[1]).sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        driver.findElement(By.id(form.getProperty("VIEW_ACCOUNT"))).click();
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel5");

        element=driver.findElement(By.id(form.getProperty("BANK_NAME")));
        assertTrue("Modification failed : Bank Name not saved in database", element.getAttribute("value").equalsIgnoreCase(testData[0]));

        List<WebElement> salary1 = driver.findElements(By.id(form.getProperty("SALARY")));
        for (WebElement x : salary1) {
            if(x.getTagName().equals("input")){
                System.out.println("Value :"+x.getAttribute("value"));
                System.out.println("Test Data :"+testData[4]);
                assertTrue("Modification failed : Salary not saved in database", x.getAttribute("value").equals(testData[4]));
            }
        }

        element=driver.findElement(By.id(form.getProperty("CURRENCY")));
        assertTrue("Modification failed :Currency not saved in database",element.getAttribute("value").equalsIgnoreCase(testData[2]));

        List<WebElement> balance1 = driver.findElements(By.id(form.getProperty("BALANCE")));
        for (WebElement x : balance1) {
            if(x.getTagName().equals("input")){
                System.out.println("Value :"+x.getAttribute("value"));
                System.out.println("Test Data :"+testData[5]);
                assertTrue("Modification failed : Balance not saved in database",x.getAttribute("value").equals(testData[5]));
            }
        }

    }

    public void formQBEtester(WebDriver driver,int testKey) throws InterruptedException, IOException {

        switchToPanel(driver);
        WebElement element;
        Properties form = getProperty();
        Thread.sleep(2000);
        String key = Integer.toString(testKey);

        element=driver.findElement(By.id(form.getProperty("EMPREF_QBE")));
        assertTrue("Employee Reference in the QBE window is not available", element.isDisplayed());
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(key);

        driver.findElement(By.id("SearchNow1")).click();

        WebElement e = doubleClickTable(driver,form.getProperty("QBE_TABLE"),key);
        if(e!=null){
            doubleClick(driver,e);
        }
        else
        {
            assertTrue("No data found after clicking the QBE Search",e.equals(null));
        }
    }
    public WebElement doubleClickTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));

        for (WebElement row : allRows) {
            table=null;
            if(index==0){index++; continue;}
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public void doubleClick(WebDriver driver, WebElement e) {

        try{
            //For IE
            e.click();
            ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);

            // For FireFox and Chrome
            /*((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                    "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                    "arguments[0].dispatchEvent(evt);", e);*/
        }catch (Exception ex){}
    }


    public void switchToPanel(WebDriver  driver) throws InterruptedException, IOException {
        Thread.sleep(1000);
        Properties form = getProperty();
        driver.findElement(By.id(form.getProperty("FORM_QBE"))).click();
        driver.switchTo().frame("CWpanel1");
        driver.switchTo().frame("mywindowframe");
    }
    public void setValueAssertForSelect(WebDriver driver,String id, String value){
        WebElement element;
        List<WebElement>list;
        element=driver.findElement(By.id(id));
        assertTrue(id+" does not exist", element.isDisplayed());
        element.click();
        element=driver.findElement(By.id("styleDropDown"));
        assertTrue("No drop box found", element.isDisplayed());
        list=element.findElements(By.tagName("li"));
        assertTrue("No data found in drop box",!list.isEmpty());
        for(WebElement obj:list){
            if(obj.getText().equals(value)){
                obj.click();
                break;
            }
        }
    }
}
