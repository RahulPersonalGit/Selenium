package GL;

import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 547798
 * Date: 3/6/13
 * Time: 8:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class tstRangeQbe {


    public void testRangeQBE(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        CommonFunctions commonFunctions=new CommonFunctions();
        List<WebElement> list,list2;
        driver.switchTo().defaultContent();
        /* element = driver.findElement(By.id("menubar_container"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);*/
        CommonFunctions comm = new CommonFunctions();
       /* comm.openPage(driver,"CADSL");
        Thread.sleep(3000);*/
        driver.switchTo().frame("panel5");
        Thread.sleep(2000);
        driver.findElement(By.id("MCB_SearchWC_wca_businessPartner_button")).click();
        WebElement iframe=driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe"));
        driver.switchTo().frame(iframe);
        Thread.sleep(2000);

        PaginationTester paginationTester=new PaginationTester();
        String[] valueL={"awse","a","f"};
        String[] valueB={"4","1","5"};
        String[] idLogin={"MCB_SearchWC_wca_loginID","MCB_SearchWC_wca_loginID_op-box","MCB_SearchWC_wca_loginID_op-lists","divcol_MCB_SearchWC_wca_loginID","MCB_SearchWC_wca_loginID_From","MCB_SearchWC_wca_loginID_To","drill_MCB_SearchWC_wca_loginID","MCB_SearchWC_wca_loginID_ok"};
        String[] idBP={"MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_businessPartner_op-box","MCB_SearchWC_wca_businessPartner_op-lists","divcol_MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_businessPartner_From","MCB_SearchWC_wca_businessPartner_To","drill_MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_businessPartner_ok"};
        driver.findElement(By.id("Search")).click();
        new CommonFunctionsForGL().closeAlert(driver);
        new CommonFunctionsForGL().closePopup(driver,"footerCloseBtn");
    //    assertTrue("pagination failed",paginationTester.testPagination(driver,"bui_w_TestRangeQBE_Table","next","prev","wca_employeeReference"));
        rangeQBE(driver,idLogin,"Login Id",valueL,"Search","bui_w_TestRangeQBE_Table",iframe);
        Thread.sleep(2000);
        rangeQBE(driver,idBP,"Buisness Partner",valueB,"Search","bui_w_TestRangeQBE_Table",iframe);
    }



    public void setValueAndAssert2(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId) throws InterruptedException{
        WebElement element=null;
        CommonFunctions commonFunctions = new CommonFunctions();
        List<WebElement> list = driver.findElements(By.id(id));
        for (WebElement x : list) {
            if(x.getTagName().equals("input")){
                element=x;
                x.sendKeys(value);
            }
        }
        driver.findElement(By.id(buttonID)).click();
        new CommonFunctionsForGL().closePopup(driver,"footerCloseBtn");
        assertTrue("table data not match",verifySearchCondition(driver,columnName,tableId,value));
        new CommonFunctionsForGL().clearContent(driver,element);
    }



    public void  rangeQBE(WebDriver driver,String[] inputId,String columnID,String[] value,String buttonId,String tableId,WebElement iframe) throws InterruptedException, IOException {
        WebElement element;
        List<WebElement>list;
        CommonFunctions commonFunctions=new CommonFunctions();
         if(columnID.equals("Buisness Partner"))
        {
            Thread.sleep(1000);
            driver.findElement(By.id("MCB_SearchWC_wca_businessPartner_button")).click();
            driver.switchTo().frame(driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe")));
            Thread.sleep(1000);
            driver.findElement(By.id("Search")).click();
            new CommonFunctionsForGL().closePopup(driver,"footerCloseBtn");
            //bui_ct_GL_qbeAllControlsSearchList_Table
            element=driver.findElement(By.id("bui_ct_GL_qbeAllControlsSearchList_Table")).findElement(By.tagName("tbody"));
            list=element.findElements(By.tagName("tr"));
            element=list.get(0).findElements(By.tagName("td")).get(0);
           // element.click();
            doubleClick(driver,element);
          //  formQBEtester(driver,Integer.parseInt(value[0]));
            driver.switchTo().defaultContent();
            driver.switchTo().frame("panel5");
            driver.switchTo().frame(iframe);
            driver.findElement(By.id("Search")).click();
            new CommonFunctionsForGL().closePopup(driver,"footerCloseBtn");
            assertTrue("table data not match",verifySearchCondition(driver,columnID,tableId,value[0]));
            new CommonFunctionsForGL().clearContent(driver,driver.findElement(By.id(inputId[0])));
        }
        else
        setValueAndAssert2(driver,inputId[0],columnID,value[0],buttonId,tableId);

        element=driver.findElement(By.id(inputId[1]));
        assertTrue(inputId[1]+" does not exist",element.isDisplayed());
        element.click();
        element=driver.findElement(By.id(inputId[2])) ;
        list=element.findElements(By.tagName("li"));
        // System.out.println("list size>>>"+list.size());
        for (WebElement x :list) {
            if(x.getAttribute("data-value").equals("between")){
                System.out.println("in");
                x.click();
                break;
            }
        }
        Thread.sleep(2000);
        // System.out.println("list size>>>"+inputId[6]);
        element=driver.findElement(By.id(inputId[6]));
        element.click();
        Thread.sleep(5000);
        WebElement elementDiv=driver.findElement(By.id(inputId[3]));
        assertTrue("No box to enter",element.isDisplayed());
        Thread.sleep(2000);
        element=driver.findElement(By.id(inputId[4]));
        assertTrue(inputId[4]+" not exist",element.isDisplayed());
        element.sendKeys(value[1]);
        element=driver.findElement(By.id(inputId[5]));
        assertTrue(inputId[5]+" not exist",element.isDisplayed());
        element.sendKeys(value[2]);
        element=elementDiv.findElement(By.id(inputId[7]));
        element.click();
        element=driver.findElement(By.id("Search"));
        element.click(); //MCB_SearchWC_wca_loginID
        new CommonFunctionsForGL().closePopup(driver,"footerCloseBtn");
        element=driver.findElement(By.id("MCB_SearchWC_wca_loginID"));
//        commonFunctions.clearContent(driver,element);
    }
    public boolean verifySearchCondition(WebDriver driver, String header,String tableId,String value) throws InterruptedException {

        int rqdHeadrIndex = 0, rqdDataIndex = 0;
        List<WebElement> allRows = readTableContent(driver, tableId, "tr");

        //DO NOT DELETE , REQUIRED TO READ TABLE HEADERS
        for (WebElement row : allRows) {
            List<WebElement> tableHeaders = row.findElements(By.tagName("th"));
            for (WebElement cell : tableHeaders) {
                if (cell.getText().equals(header)) {
                    break;
                }
                rqdHeadrIndex++;
            }
        }            // i points to position where "user name" exists
        //TO READ THE ROW DATA
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                continue;
            }
            rqdDataIndex = 0;
            for (WebElement cell : tableData) {

                if(rqdDataIndex == rqdHeadrIndex)
                {
                    if(cell.getText().equals(value))
                    {
                        rqdDataIndex++;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public List<WebElement> readTableContent(WebDriver driver,String tableId, String tagName) throws InterruptedException {
        WebElement table = driver.findElement(By.id(tableId));
        List<WebElement> allRows = table.findElements(By.tagName(tagName));
        return allRows;
    }
    public void doubleClick(WebDriver driver, WebElement e) {

        try{
            //For IE
            if(getBrowserName(driver).contains("internet")){
                e.click();
                ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
            }
            else
            {
                // For FireFox and Chrome
                ((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                        "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                        "arguments[0].dispatchEvent(evt);", e);
            }
        }catch (Exception ex){}
    }
    public String getBrowserName(WebDriver driver) throws IOException,InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName+" "+browserVersion);
        return  browserName;
    }
}
