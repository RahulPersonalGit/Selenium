package GL;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;


/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 1/31/13
 * Time: 2:33 PM
 * To change this template use File | Settings | File Templates.
 */
public class GLAS {
    CommonFunctionsForGL commonFunctionsForGL =new CommonFunctionsForGL();
    CSVReader csvReader=new CSVReader();
    String hyperLink[]=csvReader.readCSV("hyperLink","GLNew.csv");
    String initialComponents[]=csvReader.readCSV("initialASComponents","GLNew.csv");
    String dropdown[]=csvReader.readCSV("dropdown", "GLNew.csv");
    String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","GLNew.csv");
    String newSearchName[]=csvReader.readCSV("newSearchName","InputData.csv");
    String selectOptionAS[]=csvReader.readCSV("selectOptionAS","GLNew.csv");
    String selectOptions[]=csvReader.readCSV("selectOptions","GLNew.csv");
    String dblTextBox[]=csvReader.readCSV("dblTextBox","GLNew.csv");
    String dblAnchor[]=csvReader.readCSV("dblAnchor","GLNew.csv");
    String updateIds[]=csvReader.readCSV("updateIds","GLNew.csv");
    String updateValues[]=csvReader.readCSV("updateValues","InputData.csv");
    String dataLabel[]=csvReader.readCSV("dataLabel", "GLNew.csv");
    String equalsLabel[]=csvReader.readCSV("equalsLabel", "GLNew.csv");
    String tableID[]=csvReader.readCSV("tableId","GL.csv");
    String tableHeaders[]=csvReader.readCSV("tableHeaders","GL.csv");
    String asButtons[]=csvReader.readCSV("asButtons","GLNew.csv");
    String asSavedSearch[]=csvReader.readCSV("asSavedSearch","GLNew.csv");
    String asQueryClose[]=csvReader.readCSV("asQueryClose","GL.csv");
    String panels[]=csvReader.readCSV("timeZone","GLNew.csv");

    public void advancedGL(WebDriver driver) throws InterruptedException, IOException {
        driver.switchTo().defaultContent();
        commonFunctionsForGL.switchFrame(driver,"panel2");
        driver.findElement(By.id(hyperLink[1])).click();
	   driver.findElement(By.id(asButtons[1])).click();
        commonFunctionsForGL.checkComponents(driver, initialComponents);

        testRanges(driver,dropdown,asMoreActionsOptions,selectOptionAS,selectOptions);
        driver.findElement(By.id(dropdown[3])).click();
        driver.findElement(By.id(asMoreActionsOptions[2])).click();
        String[] valueToBeEntered={"qsTextBox0","qsTextBox1","qsTextBox2","qsTextBox3"};
       for(int i=1;i<5;i++){
            String data[]=csvReader.readCSV(valueToBeEntered[i-1],"InputData.csv");
            commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[i], new String[]{"", dataLabel[i], equalsLabel[i], dblTextBox[i], dblAnchor[i]});
            Thread.sleep(100);
            emptyTest(driver,dblTextBox[i],data,dblAnchor[i],updateIds[i],new String[]{tableID[1],tableHeaders[i]},0);
            nonEmptyASTest(driver,dblTextBox[i],data,dblAnchor[i],updateIds[i],new String[] {tableID[1],tableHeaders[i]},0);
            if(i==4)
                createNewSearch(driver, dropdown[3], asMoreActionsOptions[5], newSearchName[i],true);
            else
                createNewSearch(driver, dropdown[3], asMoreActionsOptions[5], newSearchName[i],false);
        }
        updateSaveDelete(driver);

    }
    public void advancedGLNew(WebDriver driver) throws InterruptedException, IOException {
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        commonFunctionsForGL.switchFrame(driver,panels[1]);
        Thread.sleep(1000);
        commonFunctionsForGL.clickElement(driver,hyperLink[1]);
        Thread.sleep(1000);
        commonFunctionsForGL.clickElement(driver,asButtons[1]);
        Thread.sleep(1000);

        commonFunctionsForGL.checkComponents(driver, initialComponents);

        testRangesNew(driver,dropdown,asMoreActionsOptions,selectOptionAS,selectOptions);
       driver.findElement(By.id("moreActions")).findElement(By.tagName("a")).click();
     //   Thread.sleep(1000);
       // driver.findElement(By.id("Startnewsearch")).click();
        Thread.sleep(1000);
        driver.findElement(By.id(asMoreActionsOptions[2])).click();
        String[] valueToBeEntered={"qsTextBox0","qsTextBox1","qsTextBox2","qsTextBox3","qsTextBox4","qsTextBox5"};

        for(int i=1;i<6;i++){
            String data[]=csvReader.readCSV(valueToBeEntered[i-1],"InputData.csv");
            commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[i], new String[]{"", dataLabel[1], equalsLabel[1], dblTextBox[i], dblAnchor[i]});
            Thread.sleep(100);
            emptyTest(driver,dblTextBox[i],data,dblAnchor[i],updateIds[i],new String[]{tableID[1],tableHeaders[i]},0);
            if(i!=3&&i!=4&&i!=5&&i!=6)  {
                nonEmptyASTest(driver,dblTextBox[i],data,dblAnchor[i],updateIds[i],new String[] {tableID[1],tableHeaders[i]},0);
            }
            /*if(i==3){
                commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_userStatus-input","bui_ct_GL_ControlsSearch_wca_userStatus-lists","Entered");
                Thread.sleep(100);
                driver.findElement(By.id("addLink")).click();
            }*/
            if(i==6){
               commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_nationality-input","bui_ct_GL_ControlsSearch_wca_nationality-lists","ADP");
                Thread.sleep(100);
                driver.findElement(By.id("addLink")).click();
            }
            if(i==1||i==2||i==3)
                createNewSearch(driver, dropdown[3], asMoreActionsOptions[5], newSearchName[i],false);
        }
        updateSaveDeleteNew(driver);
    }
    public void emptyTest(WebDriver driver,String id,String value[],String ancherId,String insideQueryContainer,String[] tableIds,int level) throws InterruptedException {
        if(id.equals(dblTextBox[3])||id.equals(dblTextBox[6])){

        }
        else{
            driver.findElement(By.id(id)).sendKeys("");
            driver.findElement(By.id(ancherId)).click();
        }

        commonFunctionsForGL.closeAlert(driver);

    }
    public void testRanges(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        DifferentRanges differentRanges=new DifferentRanges();
        differentRanges.testNumberRange(driver, dropdown, asMoreActionsOptions, selectOptionAS, selectOptions);
        differentRanges.testCharRange(driver, dropdown, asMoreActionsOptions, selectOptionAS, selectOptions);
        differentRanges.testDropDownRange(driver,dropdown,asMoreActionsOptions,selectOptionAS,selectOptions);
    }
    public void testRangesNew(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException, IOException {
        DifferentRanges differentRanges=new DifferentRanges();
        differentRanges.testNumberRangeNew(driver, dropdown, asMoreActionsOptions, selectOptionAS, selectOptions);
        //differentRanges.testCharRangeNew(driver, dropdown, asMoreActionsOptions, selectOptionAS, selectOptions);
        //differentRanges.testDropDownRangeNew(driver,dropdown,asMoreActionsOptions,selectOptionAS,selectOptions);
    }
    public void clickSavedName(WebDriver driver,String name){
        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(name)){
                div.click();
                break;
            }
        }
    }
    public WebElement isElementDisplayed(WebDriver driver,String id){
        List<WebElement> allId=driver.findElements(By.id(id));
        for(WebElement e:allId){
            if(e.isDisplayed()){
                return e;
            }
        }
        return null;
    }
    public void createNewSearch(WebDriver driver,String id,String value,String newName,boolean checkPublic) throws InterruptedException, IOException {
        String saveAsNewElements[]=csvReader.readCSV("saveAsNewElements","GLNew.csv");
        //driver.findElement(By.id(id)).click();  for chrome
        //driver.findElement(By.id(id)).findElement(By.tagName("a")).sendKeys(Keys.ENTER);     for ie
        if(new CommonFunctionsForQBE().getBrowserName(driver).contains("internet")){

            driver.findElement(By.id(id)).findElement(By.tagName("a")).click();
        }
        else if(new CommonFunctionsForQBE().getBrowserName(driver).contains("firefox")){

            driver.findElement(By.id(id)).findElement(By.tagName("a")).click();
        }
        else
        {
            driver.findElement(By.id(id)).click();
        }
        commonFunctionsForGL.checkComponents(driver,asMoreActionsOptions);
        Thread.sleep(1000);
        driver.findElement(By.id(value)).click();
        Thread.sleep(1000);
        commonFunctionsForGL.checkComponents(driver, saveAsNewElements);

        WebElement element=isElementDisplayed(driver,saveAsNewElements[2]);
        Thread.sleep(1000);
        element.click();
        Thread.sleep(1000);
        commonFunctionsForGL.closeAlert(driver);
        driver.findElement(By.id(saveAsNewElements[1])).clear();
        Thread.sleep(1000);
        driver.findElement(By.id(saveAsNewElements[1])).sendKeys(newName);
        Thread.sleep(1000);
        if(checkPublic){
            Thread.sleep(1000);
            driver.findElement(By.id(saveAsNewElements[4])).click();
            Thread.sleep(1000);
        };
        Thread.sleep(1000);
        element.click();
    }
    public void save(WebDriver driver,String name) throws InterruptedException {
        driver.findElement(By.id(dropdown[2])).click();
        clickSavedName(driver,name);
        for(int i=1;i<3;i++){
            driver.findElement(By.id(asQueryClose[i])).click();
            Thread.sleep(2000);
        }
        driver.findElement(By.id(dropdown[3])).click();
        driver.findElement(By.id(asMoreActionsOptions[4])).click();
        driver.findElement(By.id(asButtons[1])).click();
    }
    public void saveNew(WebDriver driver,String name) throws InterruptedException {
        driver.findElement(By.id(dropdown[2])).click();
        clickSavedName(driver,name);
        for(int i=1;i<3;i++){
            driver.findElement(By.id(asQueryClose[i])).click();
            Thread.sleep(2000);
        }
        driver.findElement(By.id(dropdown[3])).click();
        driver.findElement(By.id(asMoreActionsOptions[4])).click();
        driver.findElement(By.id(asButtons[1])).click();
    }
    public void update(WebDriver driver,String updateIds[],String dblTextbox[],String updateValue[],String ancher[]) throws InterruptedException {
        driver.findElement(By.id(dropdown[2])).click();
        clickSavedName(driver,newSearchName[4]);
        for(int i=1;i<updateIds.length;i++){
            if(i==3){
                driver.findElement(By.id(updateIds[i])).click();
                //driver.findElement(By.id(dblTextbox[i])).sendKeys(updateValue[i]);
                //driver.findElement(By.id(ancher[i])).click();
            }else{
            driver.findElement(By.id(updateIds[i])).click();
            driver.findElement(By.id(dblTextbox[i])).clear();
            driver.findElement(By.id(dblTextbox[i])).sendKeys(updateValue[i]);
            driver.findElement(By.id(ancher[i])).click();
            }


        }
        driver.findElement(By.id(asButtons[1])).click();
        driver.findElement(By.id(dropdown[3])).click();
        Thread.sleep(1000);
        driver.findElement(By.id(asMoreActionsOptions[4])).click();
    }
    public void updateNew(WebDriver driver,String updateIds[],String dblTextbox[],String updateValue[],String ancher[]) throws InterruptedException, IOException {
        driver.findElement(By.id(dropdown[2])).click();
        clickSavedName(driver,newSearchName[4]);
//        for(int i=1;i<4;i++){
//            if(i==3){
//                driver.findElements(By.id(updateIds[i])).get(i-1).click();
//                commonFunctionsForGL.setValueAssertForSelect(driver,dblTextbox[i],"bui_ct_GL_ControlsSearch_wca_userStatus-lists","Active");
//                driver.findElement(By.id("updateLink")).click();
//            }else{
//                driver.findElements(By.id(updateIds[i])).get(i-1).click();
//                driver.findElement(By.id(dblTextbox[i])).clear();
//                driver.findElement(By.id(dblTextbox[i])).sendKeys(updateValue[i]);
//                driver.findElement(By.id("updateLink")).click();
//            }
//
//
//        }
        driver.findElement(By.id(asButtons[1])).click();
      // commonFunctionsForGL.closePopup(driver, "footerCloseBtn");
        if(driver.findElements(By.className("bancs-dialog-close")).size()!=0){
            Thread.sleep(1000);
            driver.findElement(By.className("bancs-dialog-close")).click();
            Thread.sleep(1000);
        }
        //driver.findElement(By.id(dropdown[3])).click(); for chrome
        //driver.findElement(By.id(dropdown[3])).findElement(By.tagName("a")).sendKeys(Keys.ENTER); for ie

        if(new CommonFunctionsForQBE().getBrowserName(driver).contains("internet")){

            driver.findElement(By.id(dropdown[3])).findElement(By.tagName("a")).sendKeys(Keys.ENTER);
        }
        else
        {         Thread.sleep(1000);
            if(driver.findElements(By.className("bancs-dialog-close")).size()!=0){
                driver.findElement(By.className("bancs-dialog-close")).click();
                Thread.sleep(1000);
            }
            driver.findElement(By.id(dropdown[3])).click();
        }

        Thread.sleep(1000);
        driver.findElement(By.id(asMoreActionsOptions[4])).click();
    }
    public void deleteSavedSearch(WebDriver driver,String name){
        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        driver.findElement(By.id(dropdown[2])).click();
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(name) || div.getText().equals(name+" "+"*")){
                div.click();
                break;
            }
        }
        driver.findElement(By.id(dropdown[3])).click();
        driver.findElement(By.id(asMoreActionsOptions[6])).click();
        commonFunctionsForGL.closeAlert(driver);
    }
    public void nonEmptyASTest(WebDriver driver,String id,String value[],String ancherId,String insideQueryContainer,String[] tableIds,int level) throws InterruptedException {
        equalsValue(driver,id,value,ancherId,insideQueryContainer,tableIds);
        Thread.sleep(100);
        driver.findElement(By.id(asButtons[1])).click();
        commonFunctionsForGL.tableData(driver,tableIds[0],tableIds[1],value,level);
    }
    public void equalsValue(WebDriver driver,String id,String value[],String ancherId,String insideQueryContainer,String[] tableIds) throws InterruptedException {
        driver.findElement(By.id(id)).sendKeys(value[value.length-1]);
        driver.findElement(By.id(ancherId)).click();
        Assert.assertTrue("value inside query container not present ", commonFunctionsForGL.isElementPresent(driver, By.id(insideQueryContainer)));
        driver.findElement(By.id(asButtons[1])).click();
        Thread.sleep(1000);
        if(driver.findElements(By.className("bancs-dialog-close")).size()!=0){
            driver.findElement(By.className("bancs-dialog-close")).click();
            Thread.sleep(1000);
        }
        commonFunctionsForGL.tableData(driver,tableIds[0],tableIds[1],value,0);
    }
    public void updateSaveDelete(WebDriver driver) throws InterruptedException, IOException {
        SettingDefault settingDefault=new SettingDefault();
        update(driver,updateIds,dblTextBox,updateValues,dblAnchor);
        save(driver,newSearchName[4]);
        settingDefault.setAsDefault(driver, newSearchName[1]);
        for(int i=1;i<newSearchName.length;i++)
            deleteSavedSearch(driver,newSearchName[i]);
    } public void updateSaveDeleteNew(WebDriver driver) throws InterruptedException, IOException {
        SettingDefault settingDefault=new SettingDefault();
        updateNew(driver,updateIds,dblTextBox,updateValues,dblAnchor);
        /*saveNew(driver,newSearchName[3]);
        settingDefault.setAsDefault(driver, newSearchName[1]);
        for(int i=1;i<newSearchName.length-1;i++)
            deleteSavedSearch(driver,newSearchName[i]);*/
    }
}