package GL;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertTrue;


/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:30 PM
 * To change this template use File | Settings | File Templates.
 */
public class DifferentRanges {
    CSVReader csvReader=new CSVReader();
    CommonFunctionsForGL commonFunctionsForGL =new CommonFunctionsForGL();
    String inOutInLinkButton[]=csvReader.readCSV("inOutInLinkButton","GLNew.csv");
    String dataLabel[]=csvReader.readCSV("dataLabel", "GLNew.csv");
    String equalsLabel[]=csvReader.readCSV("equalsLabel", "GLNew.csv");
    String dblTextBox[]=csvReader.readCSV("dblTextBox","GLNew.csv");
    String dblAnchor[]=csvReader.readCSV("dblAnchor","GLNew.csv");
    String updateIds[]=csvReader.readCSV("updateIds","GLNew.csv");
    String tableID[]=csvReader.readCSV("tableId","GLNew.csv");
    String tableHeaders[]=csvReader.readCSV("tableHeaders","GLNew.csv");


    String asButtons[]=csvReader.readCSV("asButtons","GL.csv");
    String inNotInButton[]=csvReader.readCSV("inNotInButton","GL.csv");
    String errorMsg[]=csvReader.readCSV("errorMsg","GL.csv");
    int numLevels[]={1,7,8,9,10};
    int charLevels[]={2,3,4,1,5,6};

    public void testNumberRange(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        int level=0;
        String tableHeaders[]={"wca_employeeReference","wca_lastLoginTime"};
        String[] labelName={"bui_ct_GL_ControlsSearch_wca_employeeReference","bui_ct_GL_ControlsSearch_wca_lastLoginTime"};
        String[] values={"EmployeeRef","LoginTime"};
        String[] textboxes={"disp_bui_ct_GL_ControlsSearch_wca_employeeReference_Value","disp_bui_ct_GL_ControlsSearch_wca_lastLoginTime_Value"};
        String[] equalsLabel={"bui_ct_GL_ControlsSearch_wca_employeeReference_op_label","bui_ct_GL_ControlsSearch_wca_lastLoginTime_op_label"};
        String dblAnchor[]={"bui_ct_GL_ControlsSearch_wca_employeeReference_add","bui_ct_GL_ControlsSearch_wca_lastLoginTime_add"};
        String[] updateIds={"bui_ct_GL_ControlsSearch_wca_employeeReference_critDiv","bui_ct_GL_ControlsSearch_wca_lastLoginTime_critDiv"};
        for(int j=0;j<2;j++){
            level=0;
        for(int i=4;i<9;i++){
            String input[]=csvReader.readCSV(values[j]+i,"InputData.csv");
            driver.findElement(By.id(dropdown[3])).click();
            driver.findElement(By.id(asMoreActionsOptions[2])).click();
            commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], labelName[j], new String[]{"", equalsLabel[j], textboxes[j], dblAnchor[j]});
            Thread.sleep(100);
            for(int k=0;k<i;k++)
                driver.findElement(By.id(equalsLabel[j])).click();
            int option=numLevels[level++];
            for(int d=1;d<input.length;d++){
                testData(driver, textboxes[j], new String[]{input[d]}, dblAnchor[j], updateIds[j], new String[]{tableID[1], tableHeaders[j]}, option);
                driver.findElement(By.id(updateIds[j])).click();
            }
        }
        }
    }
    public void testNumberRangeNew(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException, IOException {
        int level=0;
        String tableHeaders[]={"wca_employeeReference","wca_userEffectiveDate"};
        String[] labelName={"Employee Reference","User Effective Date"};
        String[] values={"EmployeeRef","UserEffectiveDate"};
        String[] textboxes={"bui_ct_GL_ControlsSearch_wca_employeeReference","bui_ct_GL_ControlsSearch_wca_userEffectiveDate"};
        String[] equalsLabel={"searchBarOperator","searchBarOperator"};
        String dblAnchor[]={"addLink","addLink"};
        String[] updateIds={"queryLabel","queryLabel"};
        String[] oprId={"operatorType"};
        String[] operators={"Equals","between","In","Not In","Not Equals","Greater Than","Lesser Than","Greater or Equals","Lesser or Equals"};
        for(int j=0;j<2;j++){          //add login time
            level=0;
            for(int i=4;i<9;i++){
                String input[]=csvReader.readCSV(values[j]+i,"InputData.csv");
                //Thread.sleep(3000);
                //driver.findElement(By.id(dropdown[3])).click(); for chrome
                //driver.findElement(By.id(dropdown[3])).findElement(By.tagName("a")).sendKeys(Keys.ENTER); for ie
                if(new CommonFunctionsForQBE().getBrowserName(driver).contains("internet")){
                    Thread.sleep(1000);
                    WebElement webElement=driver.findElement(By.id("advanceSearchBox")).findElement(By.id("moreActions"));
                    Thread.sleep(2000);
                        webElement.click();
                }
                else if(new CommonFunctionsForQBE().getBrowserName(driver).contains("firefox")){
                    driver.findElement(By.id(dropdown[3])).findElement(By.tagName("a")).click();
                }
                else
                {      Thread.sleep(1000);
                    driver.findElement(By.id(dropdown[3])).click();
                }
                Thread.sleep(1000);
                WebElement webElement=  driver.findElement(By.id("advanceSearchBox")).findElement(By.id(asMoreActionsOptions[2]));
                Thread.sleep(1000);
                webElement.click();
                commonFunctionsForGL.doubleClickForSelectOptionsNew(driver, selectOptionAS[1], labelName[j], new String[]{"", equalsLabel[j], textboxes[j], dblAnchor[j]});
                Thread.sleep(100);
                new QBEOpeations().clickSelect(driver,oprId[0],"option",operators[i]);
                Thread.sleep(1000);
                int option=numLevels[level++];
                for(int d=1;d<input.length;d++){
                    testData(driver, textboxes[j], new String[]{input[d]}, dblAnchor[j], updateIds[j], new String[]{tableID[1], tableHeaders[j]}, option);
                    commonFunctionsForGL.closeAlert(driver);
                    Thread.sleep(1000);
                    if(driver.findElements(By.className("bancs-dialog-close")).size()!=0){
                    driver.findElement(By.className("bancs-dialog-close")).click();
                    }
                    driver.findElement(By.id(updateIds[j])).click();
                }

            }
        }
    }
    public void testCharRange(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        String variableName[]={"","","Standard","Alternate"};
        for(int step=2;step<3;step++)  {
            int level=0;
            for(int i=1;i<7;i++){
                String input[]=csvReader.readCSV(variableName[step]+i,"InputData.csv");
                String inTextboxes[]=csvReader.readCSV("inNotIn" + variableName[step] + "TextBox", "GL.csv");
                driver.findElement(By.id(dropdown[3])).click();
                driver.findElement(By.id(asMoreActionsOptions[2])).click();
                commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[step], new String[]{"", dataLabel[step], equalsLabel[step], dblTextBox[step], dblAnchor[step]});
                Thread.sleep(100);
                for(int j=0;j<i;j++)
                    driver.findElement(By.id(equalsLabel[step])).click();
                int option=charLevels[level++];
                if(i>=5){
                        in(driver,inOutInLinkButton[step],inTextboxes,input);
                        driver.findElement(By.id(dblAnchor[step])).click();
                        driver.findElement(By.id(asButtons[1])).click();
                        commonFunctionsForGL.tableData(driver,tableID[1],tableHeaders[step],input,option);
                }
                else{
                    for(int d=1;d<input.length;d++){
                        testData(driver, dblTextBox[step], new String[]{input[d]}, dblAnchor[step], updateIds[step], new String[]{tableID[1], tableHeaders[step]}, option);
                        Thread.sleep(1000);
                        driver.findElement(By.id(updateIds[step])).click();
                    }
                }
            }
        }
    }
    public void testCharRangeNew(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        String variableName[]={"","","Standard","Alternate"};
        String[] operators={"Equals","Contains","Starts With","Ends With","Not Equals","In","Not In"};
        for(int step=2;step<3;step++)  {
            int level=0;
            for(int i=1;i<5;i++){
                String input[]=csvReader.readCSV(variableName[step]+i,"InputData.csv");
                String inTextboxes[]=csvReader.readCSV("inNotIn" + variableName[step] + "TextBox", "GLNew.csv");
                driver.findElement(By.id(dropdown[3])).click();
                driver.findElement(By.id(asMoreActionsOptions[2])).click();
                commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[step], new String[]{"", dataLabel[1], equalsLabel[step], dblTextBox[step], dblAnchor[step]});
                Thread.sleep(100);
                new QBEOpeations().clickSelect(driver,equalsLabel[step],"option",operators[i]);
                int option=charLevels[level++];
                if(i>=5){
                    commonFunctionsForGL.checkComponents(driver,new String[]{"",dblAnchor[step],inOutInLinkButton[step]});
                    in(driver,inOutInLinkButton[step],inTextboxes,input);
                    driver.findElement(By.id(dblAnchor[step])).click();
                    driver.findElement(By.id(asButtons[1])).click();
                    commonFunctionsForGL.tableData(driver,tableID[1],tableHeaders[step],input,option);
                }
                else{
                    for(int d=1;d<input.length;d++){
                        testData(driver, dblTextBox[step], new String[]{input[d]}, dblAnchor[step], updateIds[step], new String[]{tableID[1], tableHeaders[step]}, option);
                        Thread.sleep(1000);
                        driver.findElement(By.id(updateIds[step])).click();
                    }
                }
            }
        }
    }
    public void testData(WebDriver driver, String id, String value[], String ancherId, String insideQueryContainer, String tableIds[], int level) throws InterruptedException {
        String asButtons[]=csvReader.readCSV("asButtons","GLNew.csv");
        Thread.sleep(1000);
        driver.findElement(By.id(id)).clear();
        Thread.sleep(1000);
        driver.findElement(By.id(id)).click();
        Thread.sleep(1000);
        driver.findElement(By.id(id)).sendKeys(value[value.length - 1]);
        Thread.sleep(1000);
        try{
            Thread.sleep(1000);
            WebElement webElement=  driver.findElement(By.id("addQuery")).findElement(By.id(ancherId));
            Thread.sleep(1000);
            webElement.click();
        }catch(Exception e){}
       // assertTrue("value inside query container not present ", commonFunctionsForGL.isElementPresent(driver, By.id(insideQueryContainer)));
        try{driver.findElement(By.id(asButtons[1])).click();}catch(Exception e){}
        commonFunctionsForGL.closeAlert(driver);
        commonFunctionsForGL.closePopup(driver, "footerCloseBtn");
        commonFunctionsForGL.closePopup(driver,errorMsg[1]);
        Thread.sleep(1000);
//        System.out.println("value "+ commonFunctionsForGL.tableData(driver,tableIds[0]z,tableIds[1],value,level));
    }
    public void in(WebDriver driver,String inLinkButton,String inIds[],String inValues[]){

        driver.findElement(By.id(inLinkButton)).click();
        for(int i=1;i<inIds.length;i++){
            driver.findElement(By.id(inIds[i])).sendKeys(inValues[i]);
        }
        driver.findElement(By.id(inNotInButton[1])).click();
    }





    public void testDropDownRange(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        String variableName[]={"","Alternate","","","Nationality","Balance"};
        String statusDropDowns[]={"selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox0_Value_Text","selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox1_Value_Text",
                                "selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox2_Value_Text","selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox3_Value_Text"};
        for(int step=3;step<7;step++)  {
            int level=0;
             if(step!=4&&step!=5)
            for(int i=2;i<4;i++){
                String input[]=csvReader.readCSV(variableName[step-2]+i,"InputData.csv");
                String inTextboxes[]=csvReader.readCSV("inNotIn" + variableName[step-2] + "TextBox", "GL.csv");
                driver.findElement(By.id(dropdown[3])).click();
                driver.findElement(By.id(asMoreActionsOptions[2])).click();
                commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[step], new String[]{"", dataLabel[step], equalsLabel[step], dblTextBox[step], dblAnchor[step]});
                Thread.sleep(100);
                for(int j=0;j<i;j++)
                    driver.findElement(By.id(equalsLabel[step])).click();
                int option=charLevels[level++];
                if(i>=2){
                    statusDropDowns=csvReader.readCSV("statusDropDown"+step,"GL.csv");
                        driver.findElement(By.id(inOutInLinkButton[step])).click();
                        for(int inData=1;inData<inTextboxes.length;inData++){
                            driver.findElement(By.id(statusDropDowns[inData])).click();
                            WebElement element=driver.findElement(By.id("styleDropDown"));
                            List<WebElement> allLi=element.findElements(By.tagName("li"));
                            for(WebElement li:allLi){
                                if(li.getAttribute("value").equals(input[1])){
                                        li.click();
                                        break;
                                }
                            }
                        }
                        driver.findElement(By.id(inNotInButton[1])).click();
                        driver.findElement(By.id(dblAnchor[step])).click();
                        driver.findElement(By.id(asButtons[1])).click();
                        commonFunctionsForGL.tableData(driver,tableID[1],tableHeaders[step],input,option);
                    }
                else{
                    WebElement element=driver.findElement(By.id("styleDropDown"));
                    List<WebElement> allLi=element.findElements(By.tagName("li"));
                    for(WebElement li:allLi){
                        if(li.getAttribute("value").equals(input[1])){
                            li.click();
                            break;
                        }
                    }
                    driver.findElement(By.id(dblAnchor[step])).click();
                    driver.findElement(By.id(asButtons[1])).click();
                }
            }
        }
    }
    public void testDropDownRangeNew(WebDriver driver,String dropdown[],String asMoreActionsOptions[],String selectOptionAS[],String selectOptions[]) throws InterruptedException {
        String variableName[]={"","Alternate","","","Nationality","Balance"};
        String statusDropDowns[]={"selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox0_Value_Text","selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox1_Value_Text",
                "selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox2_Value_Text","selectCombo_disp_bui_ct_GL_ControlsSearch_wca_userStatus_inputbox3_Value_Text"};
        String operators[]={"Equals","Not Equals","In","Not In"};
        for(int step=3;step<4;step++)  {
            int level=0;
            if(step!=4&&step!=5)
                for(int i=2;i<4;i++){
                    String input[]=csvReader.readCSV(variableName[step-2]+i,"InputData.csv");
                    String inTextboxes[]=csvReader.readCSV("inNotIn" + variableName[step-2] + "TextBox", "GLNew.csv");
                    driver.findElement(By.id(dropdown[3])).click();
                    driver.findElement(By.id(asMoreActionsOptions[2])).click();
                    commonFunctionsForGL.doubleClickForSelectOptions(driver, selectOptionAS[1], selectOptions[step], new String[]{"", dataLabel[1], equalsLabel[1], dblTextBox[step], dblAnchor[step]});
                    Thread.sleep(100);
                   /* for(int j=0;j<i;j++)
                        driver.findElement(By.id(equalsLabel[step])).click();*/
                    new QBEOpeations().clickSelect(driver,equalsLabel[step],"option",operators[i]);
                    int option=charLevels[level++];
                    /*if(i>=2){

                        statusDropDowns=csvReader.readCSV("statusDropDown"+step,"GLNew.csv");
                        driver.findElement(By.id(inOutInLinkButton[step])).click();
                        for(int inData=1;inData<inTextboxes.length;inData++){
                            driver.findElement(By.id(statusDropDowns[inData])).click();
                            WebElement element=driver.findElement(By.id("styleDropDown"));
                            List<WebElement> allLi=element.findElements(By.tagName("li"));
                            for(WebElement li:allLi){
                                if(li.getAttribute("value").equals(input[1])){
                                    li.click();
                                    break;
                                }
                            }
                        }
                        driver.findElement(By.id(inNotInButton[1])).click();
                        driver.findElement(By.id(dblAnchor[step])).click();
                        driver.findElement(By.id(asButtons[1])).click();
                        commonFunctionsForGL.tableData(driver,tableID[1],tableHeaders[step],input,option);
                    }
                    else{
                        WebElement element=driver.findElement(By.id("styleDropDown"));
                        List<WebElement> allLi=element.findElements(By.tagName("li"));
                        for(WebElement li:allLi){
                            if(li.getAttribute("value").equals(input[1])){
                                li.click();
                                break;
                            }
                        }
                        driver.findElement(By.id(dblAnchor[step])).click();
                        driver.findElement(By.id(asButtons[1])).click();
                    }*/
                }
        }
    }

}
