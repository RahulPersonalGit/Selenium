package GL;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.lift.WebDriverTestContext;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Driver;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

public class CommonFunctionsForGL {
    Constants constants=new Constants();
    public void testLogin(WebDriver driver) throws IOException, InterruptedException{
        WebElement element;
        element=driver.findElement(By.id("userId"));
        driver.findElement(By.name("userId")).sendKeys("SYSADMIN");
        Thread.sleep(1000);
        driver.findElement(By.id("password")).sendKeys("abcd1234");
        Thread.sleep(1000);
        element.sendKeys(Keys.TAB);
        element=driver.findElement(By.id("entity"));
        System.out.println("entity is enabled");
        Thread.sleep(1000);
        element=driver.findElement(By.id("Login"));
        System.out.println("login is there");
        Thread.sleep(100);
        element.click();
        System.out.println("login is clicked");
    }
    public void Login(WebDriver driver,String[] loginPageData) throws IOException {
        WebElement element;
        try {
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element = driver.findElement(By.id(loginPageData[0]));
            assertTrue("userId is not there", element.isDisplayed());
            driver.findElement(By.id(loginPageData[0])).sendKeys(loginPageData[1]);
            driver.findElement(By.id(loginPageData[2])).sendKeys(loginPageData[3]);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[4]));
            assertTrue("entity is not there", element.isEnabled());
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[5]));
            assertTrue("Login is not there", element.isDisplayed());
            element.sendKeys(Keys.RETURN);
            if ((driver.findElement(By.id(loginPageData[5]))).isDisplayed()) {
                element.sendKeys(Keys.TAB);
                element.sendKeys(Keys.ENTER);
            }
            Thread.sleep(constants.THOUSANDMILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void openPage(WebDriver driver,String pageName) throws IOException, InterruptedException {
        WebElement element;
        Properties event=getProperty("Home");
        boolean flag=false;
        String after,before;
        Thread.sleep(1000);
        element=driver.findElement(By.id(event.getProperty("userMenu")));
        for(int i=0;i<5;i++){
            testKeyBoardPress(driver, i);
            Thread.sleep(100);
            element.sendKeys(Keys.RIGHT);
            try{driver.findElement(By.linkText(event.getProperty(pageName))).isDisplayed();}catch(Exception e){continue;}
            before=after="";
            while(true){
                before=driver.findElement(By.className("bancs-menu_active")).getText();
                if(event.getProperty(pageName).equals(before)){
                    flag=true;
                    break;
                }
                Thread.sleep(100);
                element.sendKeys(Keys.DOWN);
                if(before.equals(after)){
                    element.sendKeys(Keys.RIGHT);
                    if(before.equals(driver.findElement(By.className("bancs-menu_active")).getText())) break;
                }
                after=before;
            }
            if(flag) break;
        }
        if(flag){
            Thread.sleep(100);
            element.sendKeys(Keys.RETURN);
        }
    }
    public boolean tableData(WebDriver driver,String tableId,String header,String value[],int option){
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        if(index==size)return true;
        return false;
    }
    public int compare(WebElement element,String value[],int option){
        int length=value.length;
        boolean flag=false;
        length-=1;
        switch (option){
            case 0:if(element.getText().equalsIgnoreCase(value[length]))
                    return 1;
                   break;
            case 1:if(!(element.getText().equalsIgnoreCase(value[length])))
                    return 1;
                  break;
            case 2:if(element.getText().contains(value[length].toLowerCase()) || element.getText().contains(value[length].toUpperCase()))
                    return 1;
                   break;
            case 3:if(element.getText().startsWith(value[length].toLowerCase()) || element.getText().startsWith(value[length].toUpperCase()))
                    return 1;
                   break;
            case 4:if(element.getText().endsWith(value[length].toLowerCase()) || element.getText().endsWith(value[length].toUpperCase()))
                    return 1;
                   break;
            case 5:for(int i=1;i<value.length;i++){
                        if(element.getText().equalsIgnoreCase(value[i])){
                            flag=true;
                            break;
                        }
                   }
                   if(flag)return 1;
                    break;
            case 6:int i=1;
                    for(i=1;i<value.length;i++){
                        if(!element.getText().equalsIgnoreCase(value[i])){
                            flag=true;
                        }
                    }
                    if(flag && i==value.length)return 1;
                    break;
            case 7:int val=Integer.parseInt(value[length]);
                    int toCompare=Integer.parseInt(element.getText());
                    if(toCompare>val)
                        return 1;
                    break;
            case 8:int val1=Integer.parseInt(value[length]);
                   int toCompare1=Integer.parseInt(element.getText());
                   if(toCompare1<val1)
                      return 1;
                   break;
            case 9:int val2=Integer.parseInt(value[length]);
                    int toCompare2=Integer.parseInt(element.getText());
                    if(toCompare2>=val2)
                        return 1;
                    break;
            case 10:int val3=Integer.parseInt(value[length]);
                    int toCompare3=Integer.parseInt(element.getText());
                    if(toCompare3<=val3)
                        return 1;
                    break;
        }
        return 0;
    }
    public boolean isElementPresent(WebDriver driver,By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public Properties getProperty(String language) throws IOException {
        Properties home=new Properties();
        language+=".properties";
        FileInputStream in=new FileInputStream(language);
        home.load(in);
        return home;
    }
    public boolean testTab(WebDriver driver,int tab,String tabName) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        boolean flag=false;
        driver.switchTo().defaultContent();

            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==tab){
                    element=li.findElement(By.tagName("a"));
                    if(element.getText().equals(tabName)){
                        flag=true;
                        break;
                    }
               }
               i++;
            }

        return flag;
    }
    public void testCloseTabs(WebDriver driver,int[] tab) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        driver.switchTo().defaultContent();
        for(int a:tab){
            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==a){
                    List<WebElement> allLiElements=li.findElements(By.tagName("span"));
                    for(WebElement span:allLiElements)
                        element=span;
                    assertTrue(element+"not found",element.isDisplayed());
                    element.click();
                    break;
                }
                i++;
            }
        }
    }
    public void switchFrame(WebDriver driver,String panel) throws InterruptedException {
        driver.switchTo().frame(panel);
    }
    public void closeAlert(WebDriver driver){
        try{
            Alert alert = driver.switchTo().alert();
            alert.accept();
        }catch (Exception e){}
    }
    public void closePopup(WebDriver driver,String id){
        try{
        driver.findElement(By.id(id)).click();
        }catch(Exception e){}
    }
    public void testKeyEventUserMenu(WebDriver driver) throws IOException, InterruptedException {
        Properties menuBar=getProperty("Home");
        WebElement element;
        element=driver.findElement(By.id(menuBar.getProperty("userMenu")));
        assertTrue("userMenu not found",isElementPresent(driver, By.id(menuBar.getProperty("userMenu"))));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        Thread.sleep(constants.TENMILLISECONDS);
    }
    public void testKeyBoardPress(WebDriver driver,int i) throws IOException, InterruptedException {
        Properties menuItem=getProperty("Home");
        Thread.sleep(constants.THOUSANDMILLISECONDS);
        testKeyEventUserMenu(driver);
        WebElement element=driver.findElement(By.id(menuItem.getProperty("userMenu")));
        Thread.sleep(1000);
        for(int j=0;j<i;j++)
            element.sendKeys(Keys.DOWN);
    }
    public void previousDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextEnabled(WebDriver driver){
        assertTrue("Previous Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void configCollapsableAssert(WebDriver driver){
        assertTrue("Config View Size value changed",configViewSize(driver));
        assertTrue("Control Table Button is not displayed",driver.findElement(By.id("ctrlTblBtn")).isDisplayed());
        assertTrue("show table button expanded",!driver.findElement(By.id("Create19")).isDisplayed());
    }
    public void doubleClick(WebDriver driver, WebElement e) {
        /*e.click();
        ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);*/
        try{
            //For IE
            if(getBrowserName(driver).contains("internet")){
                e.click();
                ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
            }
            else
            {
                // For FireFox and Chrome
                ((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                        "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                        "arguments[0].dispatchEvent(evt);", e);
            }
        }catch (Exception ex){}


    }
    public String getBrowserName(WebDriver driver) throws  IOException,InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName+" "+browserVersion);
        return  browserName;
    }
    public void clickSelected(WebDriver driver,String id,String valueToBeClicked) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allUlElements = element.findElements(By.tagName("li"));
        for(WebElement li:allUlElements){
            if(li.getText().equals(valueToBeClicked)){
               li.click();
                break;
            }
        }
    }
    public void backToPage(WebDriver driver,String pageName){
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                element.click();
                break;
            }
        }
    }
    public boolean checkPage(WebDriver driver,String pageName){
        boolean flag=false;
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                flag=true;
                element.click();
                break;
            }
        }
        return flag;
    }
    public void checkComponents(WebDriver driver,String initialComponents[]){
        for(int i=1;i<initialComponents.length;i++)
            try{
            assertTrue(initialComponents[i]+" not found",isElementPresent(driver, By.id(initialComponents[i])));
            } catch (Exception e){
                System.out.println("Message"+e);
            }
    }
    public void setValueAssertForSelect(WebDriver driver,String id, String divValue,String value){
        WebElement element,div;
        List<WebElement>list;
        element=driver.findElement(By.id(id));
        assertTrue(id+" does not exist", element.isDisplayed());
        element.click();
        div=driver.findElement(By.id(divValue));
       // element=div.findElement(By.className("bancs-comboBox_list"));
        assertTrue("No drop box found", element.isDisplayed());
        list=div.findElements(By.tagName("li"));
        assertTrue("No data found in drop box",!list.isEmpty());
        for(WebElement obj:list){
            if(obj.getText().equals(value)){
                obj.click();
                break;
            }
        }
    }
    public void closePage(WebDriver driver,String pageName){
        assertTrue(pageName + " not found", checkPage(driver, pageName));
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        boolean flag=false;
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName))
                flag=true;
            if(flag){
                List<WebElement> allSpanElements = li.findElements(By.tagName("span"));
                for(WebElement span:allSpanElements)
                    element=span;
                element.click();
                break;
            }
        }
    }
    public boolean configViewSize(WebDriver driver){
        String s=driver.findElement(By.id("confViewSizeSle")).getAttribute("value");
        if(s.equals("22"))
            return true;
        return false;
    }
    public WebElement searchInTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            if(index==0){index++; continue;}
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                      break;
                }
            }
            if(flag)break;
        }
        return table;
    }

    public void doubleClickTable(WebDriver driver ) throws IOException {
        WebElement e=searchInTable(driver,"ar_ct_TimeZoneSearchList_Table","CET");
        if(e!=null){
            doubleClick(driver,e);
        }
        testCloseTabs(driver,new int[]{3});
    }
    public void rightClickOnTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement element=searchInTable(driver,id,valueToBeSearched);
        if(element!=null){
            element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        }
    }
    public void doubleClickForSelectOptions(WebDriver driver,String id,String valueToBeClicked,String ids[]) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allTh=element.findElements(By.tagName("option"));
        String s[]=new String[allTh.size()];
        int index=0;
        for(WebElement el:allTh)
            s[index++]=el.getText();
        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            if(option.getAttribute("value").equals(valueToBeClicked)){
                Thread.sleep(1000);
                option.click();
                doubleClick(driver, option);
                Thread.sleep(1000);
                checkComponents(driver, ids);
                break;
            }
        }
    }
    public void doubleClickForSelectOptionsNew(WebDriver driver,String id,String valueToBeClicked,String ids[]) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allTh=element.findElements(By.tagName("option"));
        String s[]=new String[allTh.size()];
        int index=0;
        for(WebElement el:allTh)
            s[index++]=el.getText();


        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        System.out.println("Size of allOptions ="+allOptions.size());
        for(WebElement option:allOptions){
            if(option.getAttribute("value").equals(valueToBeClicked)){
                Thread.sleep(1000);
                option.click();
                try{
                    //For IE
                    if(getBrowserName(driver).contains("internet")){
                        option.click();
                        ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", option);
                    }
                    else
                    {
                        // For FireFox and Chrome
                        ((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                                "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                                "arguments[0].dispatchEvent(evt);", option);
                    }
                }catch (Exception ex){}


                Thread.sleep(1000);
                checkComponents(driver, ids);
                break;
            }
        }
    }

public boolean sortingTable(WebDriver driver,String id,String header,int order){
        WebElement element=driver.findElement(By.id(id)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        String previous="";
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            if(order==0){
                if(previous.compareTo(element.getText())<0){  // ascending order
                    previous=element.getText();
                    index++;
                }
            }
            else{
                if(previous.compareTo(element.getText())>0){ //descending  order
                    previous=element.getText();
                    index++;
                }
            }
        }
        if(size==index)
            return true;
        return false;
    }
    public void clearContent(WebDriver driver,WebElement element){
        if(element.getAttribute("id").equals("selectCombo_simpleSearchValue_Value_Text")){
            driver.findElement(By.id("selectCombo_simpleSearchValue_Value")).click();
            element=driver.findElement(By.id("styleDropDown"));
            List<WebElement> liElements=element.findElements(By.tagName("li"));
            for(WebElement ele:liElements){
                if(ele.getAttribute("key").equals("0")){
                    ele.click();
                    break;
                }
            }


        }else if(element.getAttribute("id").equals("bui_ct_GL_ControlsSearch_wca_userStatus-input")){
            driver.findElement(By.id("bui_ct_GL_ControlsSearch_wca_userStatus-input")).click();
            element=driver.findElement(By.id("bui_ct_GL_ControlsSearch_wca_userStatus-lists"));
            List<WebElement> liElements=element.findElements(By.tagName("li"));
            liElements.get(0).click();


        } else if(element.getAttribute("id").equals("bui_ct_GL_ControlsSearch_wca_nationality-input")){
            driver.findElement(By.id("bui_ct_GL_ControlsSearch_wca_nationality-input")).click();
            element=driver.findElement(By.id("bui_ct_GL_ControlsSearch_wca_nationality-lists"));
            List<WebElement> liElements=element.findElements(By.tagName("li"));
            liElements.get(0).click();


        }

        else{
            element.clear();
        }
    }
    public void doubleClickTableNew(WebDriver driver ,String tableId,String valueToBeClicked) throws IOException, InterruptedException {
        WebElement e=searchInTableNew(driver,tableId,valueToBeClicked);
        if(e!=null){
            Thread.sleep(1000);
            doubleClick(driver,e);
        }
    }
    public WebElement searchInTableNew(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            table=null;
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public void clickElement(WebDriver driver, String id) throws IOException, InterruptedException {
       WebElement Test= driver.findElement(By.id(id));
        Thread.sleep(1000);
        Test.click();

    }
    public boolean tableDataForNewRI(WebDriver driver, String tableId, String header, String value[], int option){
        WebElement element=driver.findElement(By.id(tableId));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("thead")).findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        System.out.println("size="+size+" index="+index);
        if(index==0)
            System.out.println("No data found for "+value[value.length-1]);
        if(index==size)return true;
        return false;
    }
}