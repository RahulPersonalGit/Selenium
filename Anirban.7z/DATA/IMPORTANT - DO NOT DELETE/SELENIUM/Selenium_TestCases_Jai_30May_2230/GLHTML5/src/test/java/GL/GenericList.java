package GL;
import org.openqa.selenium.*;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 1/29/13
 * Time: 8:09 PM
 * To change this template use File | Settings | File Templates.
 */
public class GenericList {
    CommonFunctions commonFunctions=new CommonFunctions();
    CSVReader csvReader=new CSVReader();
    String timeZone[]=csvReader.readCSV("timeZone","GLNew.csv");
    String dropdown[]=csvReader.readCSV("dropdown","GLNew.csv");
    String buttons[]=csvReader.readCSV("buttons","GLNew.csv");
    String qsCombo[]=csvReader.readCSV("qsCombo","GLNew.csv");
    String tableId[]=csvReader.readCSV("tableId","GLNew.csv");
    String tableHeaders[]=csvReader.readCSV("tableHeaders","GLNew.csv");
    String textBoxID[]=csvReader.readCSV("textbox","GLNew.csv");
    String errorMSg[]=csvReader.readCSV("errorMsg","GLNew.csv");
    CommonFunctionsForGL commonFunctionsForGL=new CommonFunctionsForGL();
    CommonFunctionsForQBE commonFunctionsForQBE=new CommonFunctionsForQBE();

    public void test1(WebDriver driver) throws InterruptedException, IOException {
        commonFunctions.switchFrame(driver,timeZone[1]);
        Thread.sleep(1000);
        startTestsNew(driver);
    }
    public void startTests(WebDriver driver) throws IOException, InterruptedException {
        Thread.sleep(1000);
        commonFunctions.checkComponents(driver, csvReader.readCSV("initialQSComponents","GL.csv"));
        driver.findElement(By.id(buttons[1])).click();
        new PaginationTester().testPagination(driver,tableId[1],"bui_ct_GL_ControlsSearchList_Table_next_but","bui_ct_GL_ControlsSearchList_Table_prev_but","wca_employeeReference");
       // commonFunctions.doubleClickTable(driver,tableId[1],csvReader.readCSV("qsTextBox1","InputData.csv")[1]);
        commonFunctions.testCloseTabs(driver,new int[]{3});
        commonFunctions.switchFrame(driver,timeZone[1]);
        rightClick(driver,"");
        testTextBox(driver,qsCombo,csvReader.readCSV("timeZone","GL.csv")[0]);
        driver.findElement(By.id(buttons[2])).click();
        testCollapsible(driver, buttons[2]);
        testGLQBE1(driver);
        new GLAS().advancedGL(driver);


    }
    public void startTestsNew(WebDriver driver) throws IOException, InterruptedException {
        Thread.sleep(1000);
        commonFunctions.checkComponents(driver, csvReader.readCSV("initialQSComponents","GLNew.csv"));
        driver.findElement(By.id(buttons[1])).click();
        commonFunctionsForGL.doubleClickTableNew(driver,tableId[1],csvReader.readCSV("qsTextBox1","InputData.csv")[1]);
        Thread.sleep(1000);
        commonFunctionsForGL.testCloseTabs(driver,new int[]{3});
        Thread.sleep(1000);
        commonFunctions.switchFrame(driver,timeZone[1]);
        //Thread.sleep(1000);
       new PaginationTester().testPagination(driver,tableId[1],"next","prev","wca_employeeReference");
        new GLAS().advancedGLNew(driver);
        driver.findElement(By.id("simpleSearchLink")).click();

        testGLQBE1New(driver);
      }

    public void setValueAssertForSelect(WebDriver driver,String id, String divValue,String value){
        WebElement element,div;
        List<WebElement>list;
        element=driver.findElement(By.id(id));
        assertTrue(id+" does not exist", element.isDisplayed());
        element.click();
        div=driver.findElement(By.id(divValue));
        element=div.findElement(By.className("bancs-comboBox_list"));
        assertTrue("No drop box found", element.isDisplayed());
        list=element.findElements(By.tagName("li"));
        assertTrue("No data found in drop box",!list.isEmpty());
        for(WebElement obj:list){
            if(obj.getText().equals(value)){
                obj.click();
                break;
            }
        }
    }



    public void testTextBox(WebDriver driver,String qsCombo[],String panel) throws InterruptedException {
        for(int i=0;i<7;i++){

            String inputData[]=csvReader.readCSV("qsTextBox"+i,"InputData.csv");
            nonEmptyTestForTextField(driver,new String[] {panel,qsCombo[i+2]},tableHeaders[i+1],inputData,i+1);




        }
    }
    public void testTextBoxNew(WebDriver driver,String qsCombo[],String panel) throws InterruptedException {
        for(int i=0;i<6;i++){

            String inputData[]=csvReader.readCSV("qsTextBox"+i,"InputData.csv");

            nonEmptyTestForTextFieldNew(driver, new String[]{panel, qsCombo[i + 2]}, tableHeaders[i + 1], inputData, i + 1);






        }
    }
    public void testCollapsible(WebDriver driver,String buttons) throws InterruptedException, IOException {
        ColumnOptions columnOptions=new ColumnOptions();
        ExportingPages exportingPages=new ExportingPages();
        String controlButtons[]=csvReader.readCSV("controlButtons","GL.csv");
        String qsMoreActionButtons[]=csvReader.readCSV("qsMoreActionButtons","GL.csv");
        String downloadLinks[]=csvReader.readCSV("downloadLinks","GL.csv");
        for(int i=1;i<controlButtons.length;i++){
            driver.findElement(By.id(controlButtons[i])).click();
            commonFunctions.testCloseTabs(driver, new int[]{3});
            commonFunctions.switchFrame(driver,timeZone[1]);
        }

        columnOptions.columnOptions(driver, qsMoreActionButtons);
    }
    public void testCollapsibleNew(WebDriver driver) throws InterruptedException {
    WebElement element;
    element=driver.findElement(By.id("moreAction"));
    assertTrue("More actions is not displayed ",element.isDisplayed());
    element.click();
    Thread.sleep(1000);

        assertTrue("column options not found",commonFunctionsForGL.isElementPresent(driver, By.id("columnOptions")));
    driver.findElement(By.id("columnOptions")).click();
    String buttonIds[]={"SelAllAvlCols","AvlBtn","ShowBtn","SelAllShowCols","moveUp","moveDown","image1","image3","image2","showColumns"};
    String availableOptions[]={"Login Id","First Name","Business Partner","User Effective Date","Last Logged in Time"};
    driver.findElement(By.id(buttonIds[3])).click();
    commonFunctionsForGL.closeAlert(driver);
    driver.findElement(By.id(buttonIds[2])).click();
    element= driver.findElement(By.id(buttonIds[6]));
    commonFunctionsForGL.closeAlert(driver);
    element.click();
    commonFunctionsForGL.closeAlert(driver);
    element.click();
    element=driver.findElement(By.id("Search"));
    assertTrue("Search button is not displayed ",element.isDisplayed());
    element.click();
    }

    public void rightClick(WebDriver driver,String value) throws IOException, InterruptedException {
        String rightClick[]=csvReader.readCSV("rightClick","GLNew.csv");
        for(int i=1;i<rightClick.length;i++){
            commonFunctions.rightClickOnTable(driver, tableId[1], value);
            commonFunctions.checkComponents(driver,rightClick);
            driver.findElement(By.id(rightClick[i])).click();
            if(commonFunctions.testTab(driver,5,csvReader.readCSV("tabNames","GLNew.csv")[i]))
                commonFunctions.testCloseTabs(driver,new int[]{5});
            commonFunctions.switchFrame(driver,timeZone[1]);
        }
    }
    public void nonEmptyTestForTextField(WebDriver driver,String[] id,String header,String[] value,int index) throws InterruptedException {
        driver.findElement(By.id(dropdown[1])).click();
        commonFunctions.clickSelected(driver,qsCombo[1],id[1]);
        assertTrue("Text Field is not empty",commonFunctions.isElementPresent(driver,By.id(textBoxID[1])));
        for(int i=1;i<value.length-1;i++){
            new CommonFunctionsForGL().clearContent(driver,driver.findElement(By.id(textBoxID[index])));
            driver.findElement(By.id(textBoxID[index])).sendKeys(value[i]);
            driver.findElement(By.id(buttons[1])).click();
            commonFunctions.closeAlert(driver);
            commonFunctions.closePopup(driver,errorMSg[1]);
            new CommonFunctionsForGL().clearContent(driver,driver.findElement(By.id(textBoxID[index])));

        }

            driver.findElement(By.id(textBoxID[index])).sendKeys(value[value.length - 1]);
            commonFunctions.closePopup(driver,errorMSg[1]);
            driver.findElement(By.id(buttons[1])).click();
            commonFunctions.tableData(driver, tableId[1], header, value,0);
    }
    public void clickSelect(WebDriver driver,String textBoxId,String tagName,String valueToBeSelected){
        WebElement element2=commonFunctionsForQBE.findDisplayedElement(driver,textBoxId);
        if(tagName.equals("option"))element2.click();
        List<WebElement> allOptions=element2.findElements(By.tagName(tagName));
        for(WebElement option:allOptions){
            if(option.getText().equalsIgnoreCase(valueToBeSelected)){
                option.click();
                break;
            }

        }
    }
    public void nonEmptyTestForTextFieldNew(WebDriver driver,String[] id,String header,String[] value,int index) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By.id(dropdown[1])).click();
        Thread.sleep(1000);
        commonFunctions.clickSelectedNew(driver, qsCombo[1], id[1]);


        for(int i=1;i<value.length-1;i++){
            Thread.sleep(1000);
            assertTrue("Text Field is not empty",commonFunctions.isElementPresent(driver,By.id(textBoxID[index])));
            new CommonFunctionsForGL().clearContent(driver,driver.findElement(By.id(textBoxID[index])));
            if(index==1||index==2||index==4||index==5){
                driver.findElement(By.id(textBoxID[index])).sendKeys(value[i]);
            }else if(index==3){
                Thread.sleep(1000);
                commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_userStatus-input","bui_ct_GL_ControlsSearch_wca_userStatus-lists","Entered");
            }else if(index==6){
                Thread.sleep(1000);
                commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_nationality-input","bui_ct_GL_ControlsSearch_wca_nationality-lists","INDIA");
            }
            try{
            driver.findElement(By.id(buttons[1])).click();}catch(Exception e){}
            commonFunctions.closeAlert(driver);
            Thread.sleep(1000);
            commonFunctions.closePopup(driver,errorMSg[1]);

            new CommonFunctionsForGL().clearContent(driver,driver.findElement(By.id(textBoxID[index])));

        }
        if(index==1||index==2||index==4||index==5){
            driver.findElement(By.id(textBoxID[index])).sendKeys(value[value.length - 1]);
        }else if(index==3){
            Thread.sleep(1000);
            commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_userStatus-input","bui_ct_GL_ControlsSearch_wca_userStatus-lists","ActiveWait");
        }else if(index==6){
            Thread.sleep(1000);
            commonFunctionsForGL.setValueAssertForSelect(driver,"bui_ct_GL_ControlsSearch_wca_nationality-input","bui_ct_GL_ControlsSearch_wca_nationality-lists","AFGHANISTAN");
        }
        commonFunctions.closePopup(driver,errorMSg[1]);
        try{
            driver.findElement(By.id(buttons[1])).click();}catch(Exception e){}
        commonFunctions.closeAlert(driver);
        Thread.sleep(1000);
        commonFunctions.closePopup(driver,errorMSg[1]);

        commonFunctionsForGL.tableDataForNewRI(driver, tableId[1], header, value, 0);
        Thread.sleep(1000);
    }
    public void testGLQBE1(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        String components[]={"","Help7","Close8","MCB_SearchWC_wca_employeeReference_label","MCB_SearchWC_wca_employeeReference","MCB_SearchWC_wca_loginId_label","MCB_SearchWC_wca_loginId",
                "MCB_SearchWC_wca_firstName_label","MCB_SearchWC_wca_firstName","MCB_SearchWC_wca_businessPartner_label","MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_userStatus_label","selectCombo_MCB_SearchWC_wca_userStatus_Text",
                "MCB_SearchWC_wca_lastLoginTime_label","MCB_SearchWC_wca_lastLoginTime","MCB_SearchWC_wca_userEffectiveDate_label","MCB_SearchWC_wca_userEffectiveDate","srchBut_2","bui_w_SearchListQBE_Table","bui_w_SearchListQBE_Table_prev_but","bui_w_SearchListQBE_Table_next_but"};
        String ids[]={"ar_ct_UserDetail_N_wca_TimeZone_button"};
        String panels[]={"panel2","CWpanel1"};
        String tableHeaders[]={"wca_LoginId","wca_firstName","wca_employeeReference","wca_businessPartner","wca_processingCenter","wca_emailID"};

        /*Blank Search*/

        new QBEOpeations().switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("srchBut_2")).click();
        while(driver.findElement(By.id(components[components.length-1])).isEnabled()){
            driver.findElement(By.id(components[components.length-1])).click();
            Thread.sleep(10);
        }
        while(driver.findElement(By.id(components[components.length-2])).isEnabled()){
            driver.findElement(By.id(components[components.length-2])).click();
            Thread.sleep(10);
        }
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","Arun");


        new QBEOpeations().switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_firstName","suchi");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_firstName",new String[]{"suchi"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","suchi");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_firstName",new String[]{"suchi"},0);



        new QBEOpeations().switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_loginId","q");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_loginId",new String[]{"q"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","q");


        new QBEOpeations().switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_businessPartner","465465");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_businessPartner",new String[]{"465465"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","465465");


        new QBEOpeations().switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("MCB_SearchWC_wca_lastLoginTime")).sendKeys("");
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_lastLoginTime","00:00:00");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_lastLoginTime",new String[]{"00:00:00"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","00:00:00");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_lastLoginTime",new String[]{"00:00:00"},0);


        new QBEOpeations().switchToPanelGL(driver, panels);
        new QBEOpeations().commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("MCB_SearchWC_wca_userEffectiveDate")).sendKeys("");
        new QBEOpeations().sendKeysToElement(driver, "MCB_SearchWC_wca_userEffectiveDate", "04/12/2012");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForGL.tableData(driver,"bui_w_SearchListQBE_Table","wca_userEffectiveDate",new String[]{"04/12/2012"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","04/12/2012");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);

        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_userEffectiveDate",new String[]{"04/12/2012"},0);
    }
    public void testGLQBE1New(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        String components[]={"","Help7","Close8","MCB_SearchWC_wca_employeeReference","MCB_SearchWC_wca_loginId","MCB_SearchWC_wca_firstName","MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_userStatus-input",
                "MCB_SearchWC_wca_lastLoginTime","MCB_SearchWC_wca_userEffectiveDate","Search","bui_w_SearchListQBE_Table"};
        String ids[]={"ar_ct_UserDetail_N_wca_TimeZone_button"};
        String panels[]={"panel2","CWpanel1"};
        String tableHeaders[]={"wca_LoginId","wca_firstName","wca_employeeReference","wca_businessPartner","wca_processingCenter","wca_emailID"};

        /*Blank Search*/

        new QBEOpeations().switchToPanelGLNew(driver,panels);
        driver.findElement(By.id("Search")).click();
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("Search")).click();

        commonFunctionsForQBE.doubleClickTableNew(driver,"bui_w_SearchListQBE_Table","Arun");


        new QBEOpeations().switchToPanelGLNew(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_firstName","Sucharita");
        driver.findElement(By.id("Search")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableDataForNewRI(driver,"bui_w_SearchListQBE_Table","wca_firstName",new String[]{"suchi"},0));
        Thread.sleep(2000);
        commonFunctionsForQBE.doubleClickTableNew(driver,"bui_w_SearchListQBE_Table","Sucharita");
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("Search")).click();
        commonFunctionsForQBE.tableDataForNewRI(driver,"bui_ct_GL_ControlsSearchList_Table","wca_firstName",new String[]{"suchi"},0);



        new QBEOpeations().switchToPanelGLNew(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_loginId","SUCHARITA");
        driver.findElement(By.id("Search")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableDataForNewRI(driver,"bui_w_SearchListQBE_Table","wca_loginId",new String[]{"SUCHARITA"},0));
        commonFunctionsForQBE.doubleClickTableNew(driver,"bui_w_SearchListQBE_Table","SUCHARITA");


        new QBEOpeations().switchToPanelGLNew(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_businessPartner","465465");
        driver.findElement(By.id("Search")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableDataForNewRI(driver,"bui_w_SearchListQBE_Table","wca_businessPartner",new String[]{"465465"},0));
        commonFunctionsForQBE.doubleClickTableNew(driver,"bui_w_SearchListQBE_Table","465465");

        new QBEOpeations().switchToPanelGLNew(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("MCB_SearchWC_wca_lastLoginTime")).sendKeys("");
        new QBEOpeations().sendKeysToElement(driver,"MCB_SearchWC_wca_lastLoginTime","00:00:00");
        driver.findElement(By.id("Search")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableDataForNewRI(driver,"bui_w_SearchListQBE_Table","wca_lastLoginTime",new String[]{"00:00:00"},0));
        commonFunctionsForQBE.doubleClickTableNew(driver,"bui_w_SearchListQBE_Table","3435");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("Search")).click();
        commonFunctionsForQBE.tableDataForNewRI(driver,"bui_ct_GL_ControlsSearchList_Table","wca_lastLoginTime",new String[]{"00:00:00"},0);



    }
    public void advanceSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element,option;

        String[] searchOptions={"Employee Reference","User Name","User Status","Last Logged in Time","User Effective Date","Nationality","Balance"};
        String[] searchidOptions={"bui_ct_GL_ControlsSearch_wca_employeeReference","bui_ct_GL_ControlsSearch_wca_firstName","bui_ct_GL_ControlsSearch_wca_userStatus-input","bui_ct_GL_ControlsSearch_wca_lastLoginTime","bui_ct_GL_ControlsSearch_wca_userEffectiveDate","bui_ct_GL_ControlsSearch_wca_nationality-input","bui_ct_GL_ControlsSearch_wca_balanceCurrency-input"};
        String inputs[]={"2","suchi","ENTERED","00:00:00","04/12/2012","INDIA","ADP"};
        element=driver.findElement(By.id("advancedSearchLink"));
        assertTrue("Advance search link is not found ",element.isDisplayed());
        element.click();
        Thread.sleep(3000);
        WebElement optionTable =driver.findElement(By.id("searchSelect"));
        assertTrue("Option table is not displayed",optionTable.isDisplayed());
        List<WebElement> rowsList = optionTable.findElements(By.tagName("option"));


        for(int i=0;i<6;i++){
            if(i!=2&&i!=5)
            for(WebElement x:rowsList){
                if(x.getText().equals(searchOptions[i])){
                    assertTrue("Option is displayed", x.isDisplayed());
                    x.click();
                    ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", x);
                    Thread.sleep(1000);
                    element=driver.findElement(By.id(searchidOptions[i]));
                    assertTrue("search field is not displayed",element.isDisplayed());
                    element=driver.findElement(By.id("addLink"));
                    assertTrue("add criteria is not displayed",element.isDisplayed());
                    element.click();
                    commonFunctionsForGL.closeAlert(driver);
                    element=driver.findElement(By.id(searchidOptions[i]));
                    rowsList = optionTable.findElements(By.tagName("option"));
                    break;
                }
            }
        }
    }
    public void advanceSearchMoreOptions(WebDriver driver) throws IOException, InterruptedException {
        WebElement element,option;
        String[] searchOptions={"Employee Reference","User Name","User Status","Last Logged in Time","User Effective Date","Nationality","Balance"};
        String[] searchidOptions={"bui_ct_GL_ControlsSearch_wca_employeeReference","bui_ct_GL_ControlsSearch_wca_firstName","bui_ct_GL_ControlsSearch_wca_userStatus-input","bui_ct_GL_ControlsSearch_wca_lastLoginTime","bui_ct_GL_ControlsSearch_wca_userEffectiveDate","bui_ct_GL_ControlsSearch_wca_nationality-input","bui_ct_GL_ControlsSearch_wca_balanceCurrency-input"};
        String inputs[]={"2","suchi","ENTERED","00:00:00","04/12/2012","INDIA","ADP"};
        WebElement optionTable =driver.findElement(By.id("searchSelect"));
        List<WebElement> rowsList = optionTable.findElements(By.tagName("option"));
        System.out.println(rowsList);
        for(int i=0;i<searchOptions.length;i++){
            for(WebElement x:rowsList){
                if(x.getText().equals(searchOptions[i])){
                    x.click();
                    ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", x);
                    Thread.sleep(1000);
                    element=driver.findElement(By.id(searchidOptions[i]));
                    if(searchOptions[i].equals("Login")) {
                        element.sendKeys("q");
                        element=driver.findElement(By.id("addLink"));
                        element.click();
                        element=driver.findElement(By.id("Search"));
                        element.click();
                    }
                    if(searchOptions[i].equals("User Name")) {
                        element.sendKeys("w");
                        element=driver.findElement(By.id("addLink"));
                        element.click();
                        element=driver.findElement(By.id("Search"));
                        element.click();
                        //        element=driver.findElement(By.id("Search"));
                        driver.findElement(By.id("Login_img2")).click();
                        element=driver.findElement(By.name("AdvSearch"));
                        element.click();
                        driver.findElement(By.id("User Name_img1")).click();
                        element=driver.findElement(By.id("MCB_SearchWC_wca_firstName"));
                        element.sendKeys("a");
                        element=driver.findElement(By.className("searchStyle1"));
                        element.click();
                        element=driver.findElement(By.name("AdvSearch"));
                        element.click();
                        commonFunctionsForGL.closeAlert(driver);
                        saveAndDeleteSearch(driver);
                    }
                    rowsList = optionTable.findElements(By.tagName("option"));
                    break;
                }
            }
        }
    }
    public void saveAndDeleteSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element,option;
        Thread.sleep(2000);
        element=driver.findElement(By.id("mcMoreActnCombo"));
        assertTrue("Save Search combo  is not found ",element.isDisplayed());
        element.click();
        Thread.sleep(1000);
        driver.findElement(By.id("saveas")).click();
        element=driver.findElement(By.id("searchname"));
        element.click();
        element.sendKeys("try4");
        element=driver.findElement(By.id("newsearch1"));
        element.click();
    }
}