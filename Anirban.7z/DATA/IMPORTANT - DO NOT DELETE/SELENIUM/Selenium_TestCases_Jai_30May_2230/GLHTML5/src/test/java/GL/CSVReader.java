package GL;


import GL.CommonFunctions;

import java.io.BufferedReader;
import java.io.FileReader;

public class CSVReader {
    GL.CommonFunctions commonFunctions=new CommonFunctions();
    String testCaseParameteres[] = new String[20];
    String as[]={};
    private int panelNo=1,lineNumber = 0, tokenNumber = 0, i = 0;

    public String[] readCSV(String firstWord,String fileName) {
        try {
            String csvFile="D:\\GLTestcases\\SearchTestCases\\src\\test\\java\\data\\"+fileName;

            //create BufferedReader to read csv file
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            String line = "";


            //read comma separated file line by line
            while ((line = br.readLine()) != null) {
                lineNumber++;
                String as1[]=line.split(",");
                if(as1[0].equals(firstWord)){
                    return as1;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /*public static void main(String args[]){
        String[] riArray=new CSVReader().readCSV("buttons");
        for(String a:riArray)System.out.println(a);
    }*/

    /*private void TestCaseExecutionSteps(WebDriver driver, String[] ListDataFromCSV) throws InterruptedException {


    }
*/

}
