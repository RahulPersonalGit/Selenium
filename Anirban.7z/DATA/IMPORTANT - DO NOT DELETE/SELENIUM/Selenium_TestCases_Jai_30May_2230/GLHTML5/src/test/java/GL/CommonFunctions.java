package GL;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

public class CommonFunctions  {
    Constants constants=new Constants();
    public void Login(WebDriver driver,String[] loginPageData) throws IOException {
        WebElement element;
        try {
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element = driver.findElement(By.id(loginPageData[0]));
            assertTrue("userId is not there", element.isDisplayed());
            driver.findElement(By.id(loginPageData[0])).sendKeys(loginPageData[1]);
            driver.findElement(By.id(loginPageData[2])).sendKeys(loginPageData[3]);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[4]));
            assertTrue("entity is not there", element.isEnabled());
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[5]));
            assertTrue("Login is not there", element.isDisplayed());
            element.sendKeys(Keys.RETURN);
            if ((driver.findElement(By.id(loginPageData[5]))).isDisplayed()) {
                element.sendKeys(Keys.TAB);
                element.sendKeys(Keys.ENTER);
            }
            Thread.sleep(constants.THOUSANDMILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void openPage(WebDriver driver,String pageName) throws IOException, InterruptedException {
        WebElement element;
        Properties event=getProperty("Home");
        boolean flag=false;
        String after,before;
        element=driver.findElement(By.id(event.getProperty("userMenu")));
        for(int i=0;i<5;i++){
            testKeyBoardPress(driver, i);
            element.sendKeys(Keys.RIGHT);
            try{driver.findElement(By.linkText(event.getProperty(pageName))).isDisplayed();}catch(Exception e){continue;}
            before=after="";
            while(true){
                before=driver.findElement(By.className("bancs-menu_active")).getText();
                if(event.getProperty(pageName).equals(before)){
                    flag=true;
                    break;
                }
                element.sendKeys(Keys.DOWN);
                if(before.equals(after)){
                    element.sendKeys(Keys.RIGHT);
                    if(before.equals(driver.findElement(By.className("bancs-menu_active")).getText())) break;
                }
                after=before;
            }
            if(flag) break;
        }
        if(flag)element.sendKeys(Keys.RETURN);
    }
    public boolean tableData(WebDriver driver,String tableId,String header,String value[],int option){
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            System.out.println(th.getAttribute("columnLabel")+" and  "+header);
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        System.out.println("index=" + index + " size=" + size);
        if(index==size)return true;
        return false;
    }
    public int compare(WebElement element,String value[],int option){
        int length=value.length;
        boolean flag=false;
        length-=1;
        System.out.println("option="+option+" element="+element.getText()+" value="+value[length]);
        switch (option){
            case 0:if(element.getText().equals(value[length]))
                    return 1;
                   break;
            case 1:if(!(element.getText().equals(value[length])))
                    return 1;
                  break;
            case 2:if(element.getText().contains(value[length]))
                    return 1;
                   break;
            case 3:if(element.getText().startsWith(value[length]))
                    return 1;
                   break;
            case 4:if(element.getText().endsWith(value[length]))
                    return 1;
                   break;
            case 5:for(int i=1;i<value.length;i++){
                        if(element.getText().equals(value[i])){
                            flag=true;
                            break;
                        }
                   }
                   if(flag)return 1;
                    break;
            case 6:int i=1;
                    for(i=1;i<value.length;i++){
                        if(!element.getText().equals(value[i])){
                            flag=true;
                        }
                    }
                    if(flag && i==value.length)return 1;
                    break;
            case 7:int val=Integer.parseInt(value[length]);
                    int toCompare=Integer.parseInt(element.getText());
                    if(toCompare>val)
                        return 1;
                    break;
            case 8:int val1=Integer.parseInt(value[length]);
                   int toCompare1=Integer.parseInt(element.getText());
                   if(toCompare1<val1)
                      return 1;
                   break;
            case 9:int val2=Integer.parseInt(value[length]);
                    int toCompare2=Integer.parseInt(element.getText());
                    if(toCompare2>=val2)
                        return 1;
                    break;
            case 10:int val3=Integer.parseInt(value[length]);
                    int toCompare3=Integer.parseInt(element.getText());
                    if(toCompare3<=val3)
                        return 1;
                    break;
        }
        return 0;
    }
    public boolean isElementPresent(WebDriver driver,By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public Properties getProperty(String language) throws IOException {
        Properties home=new Properties();
        language+=".properties";
        FileInputStream in=new FileInputStream(language);
        home.load(in);
        return home;
    }
    public boolean testTab(WebDriver driver,int tab,String tabName) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        boolean flag=false;
        driver.switchTo().defaultContent();

            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==tab){
                    element=li.findElement(By.tagName("a"));
                    if(element.getText().equals(tabName)){
                        flag=true;
                        break;
                    }
               }
               i++;
            }

        return flag;
    }
    public void testCloseTabs(WebDriver driver,int[] tab) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        driver.switchTo().defaultContent();
        for(int a:tab){
            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==a){
                    List<WebElement> allLiElements=li.findElements(By.tagName("span"));
                    for(WebElement span:allLiElements)
                        element=span;
                    assertTrue(element+"not found",element.isDisplayed());
                    element.click();
                    break;
                }
                i++;
            }
        }
    }
    public void switchFrame(WebDriver driver,String panel) throws InterruptedException {
        driver.switchTo().frame(panel);
        Thread.sleep(constants.THOUSANDMILLISECONDS);
    }
    public void closeAlert(WebDriver driver){
        try{
            Alert alert = driver.switchTo().alert();
            alert.accept();
        }catch (Exception e){}
    }

    public void closePopup(WebDriver driver,String id){
        try{
        //driver.findElement(By.id(id)).click();
            driver.findElement(By.className("bancs-dialog-close")).click();
        }catch(Exception e){}
    }
    public void testKeyEventUserMenu(WebDriver driver) throws IOException, InterruptedException {
        Properties menuBar=getProperty("Home");
        WebElement element;
        element=driver.findElement(By.id(menuBar.getProperty("userMenu")));
        assertTrue("userMenu not found",isElementPresent(driver, By.id(menuBar.getProperty("userMenu"))));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        Thread.sleep(constants.TENMILLISECONDS);
    }
    public void testKeyBoardPress(WebDriver driver,int i) throws IOException, InterruptedException {
        Properties menuItem=getProperty("Home");
        Thread.sleep(constants.THOUSANDMILLISECONDS);
        testKeyEventUserMenu(driver);
        WebElement element=driver.findElement(By.id(menuItem.getProperty("userMenu")));
        for(int j=0;j<i;j++)
            element.sendKeys(Keys.DOWN);
    }
    public void testDropDown(WebDriver driver,String button,String value) throws InterruptedException {
        driver.findElement(By.id(button)).click();
        driver.findElement(By.xpath(value)).click();
    }
    public void testPassDate(WebDriver driver,String fieldName,String dateValue){
        driver.findElement(By.id(fieldName)).clear();
        driver.findElement(By.id(fieldName)).sendKeys(dateValue);
    }
    public void previousDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextEnabled(WebDriver driver){
        assertTrue("Previous Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void configCollapsableAssert(WebDriver driver){
        assertTrue("Config View Size value changed",configViewSize(driver));
        assertTrue("Control Table Button is not displayed",driver.findElement(By.id("ctrlTblBtn")).isDisplayed());
        assertTrue("show table button expanded",!driver.findElement(By.id("Create19")).isDisplayed());
    }
    public void doubleClick(WebDriver driver, WebElement e) {
        e.click();
        ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
    }
    public void clickSelected(WebDriver driver,String id,String valueToBeClicked) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allUlElements = element.findElements(By.tagName("li"));
        for(WebElement li:allUlElements){
            if(li.getAttribute("key").equals(valueToBeClicked)){
               li.click();
                break;
            }
        }
    }
    public void clickSelectedNew(WebDriver driver,String id,String valueToBeClicked) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allUlElements = element.findElements(By.tagName("li"));
        /*for(WebElement li:allUlElements){
            if(li.getAttribute("key").equals(valueToBeClicked)){
                li.click();
                break;
            }
        }*/
        allUlElements.get(Integer.parseInt(valueToBeClicked)).click();
    }
    public void backToPage(WebDriver driver,String pageName){
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                element.click();
                break;
            }
        }
    }
    public boolean checkPage(WebDriver driver,String pageName){
        boolean flag=false;
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                flag=true;
                element.click();
                break;
            }
        }
        return flag;
    }
    public void checkComponents(WebDriver driver,String initialComponents[]){
        for(int i=1;i<initialComponents.length;i++)
            assertTrue(initialComponents[i]+" not found",isElementPresent(driver, By.id(initialComponents[i])));
    }
    public void closePage(WebDriver driver,String pageName){
        assertTrue(pageName + " not found", checkPage(driver, pageName));
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        boolean flag=false;
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName))
                flag=true;
            if(flag){
                List<WebElement> allSpanElements = li.findElements(By.tagName("span"));
                for(WebElement span:allSpanElements)
                    element=span;
                element.click();
                break;
            }
        }
    }
    public boolean configViewSize(WebDriver driver){
        String s=driver.findElement(By.id("confViewSizeSle")).getAttribute("value");
        if(s.equals("22"))
            return true;
        return false;
    }
    public boolean searchResultBar(WebDriver driver,String value){
        boolean flag=false;
        WebElement fieldSet=driver.findElement(By.id("ar_w_UserList_N"));
        fieldSet=fieldSet.findElement(By.tagName("div"));
        List<WebElement> allDivs= fieldSet.findElements(By.tagName("div"));
        for(WebElement option:allDivs){
            if(option.getText().equals(value)){
                flag=true;
                break;
            }
        }
        return flag;
    }
    public WebElement searchInTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            if(index==0){index++; continue;}
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                      break;
                }
            }
            if(flag)break;
        }
        return table;
    }

    public void doubleClickTable(WebDriver driver,String tableId ,String data) throws IOException {
        WebElement e=searchInTable(driver,tableId,data);
        if(e!=null){
            doubleClick(driver,e);
        }
    }
    public void rightClickOnTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement element=searchInTable(driver,id,valueToBeSearched);
        if(element!=null){
           // element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
            Actions builder = new Actions(driver);
            Action rClick = builder.contextClick(element).build();
            rClick.perform();
        }
    }
}