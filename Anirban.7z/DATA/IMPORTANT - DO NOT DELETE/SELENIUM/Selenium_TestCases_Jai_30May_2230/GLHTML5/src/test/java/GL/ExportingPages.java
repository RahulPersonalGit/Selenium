package GL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Iterator;
import java.util.Set;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExportingPages {
    CSVReader csvReader=new CSVReader();
    CommonFunctionsForGL commonFunctionsForGL =new CommonFunctionsForGL();

    public void exportPage(WebDriver driver,String moreActions[],String downloadLink){
        String exporting[]=csvReader.readCSV("exporting","GL.csv");
        String currentURL=driver.getCurrentUrl();
        driver.findElement(By.id(moreActions[0])).click();
        driver.findElement(By.id(moreActions[1])).click();
        for(int i=1;i<exporting.length;i++)
            assertTrue(exporting[i]+" not found", commonFunctionsForGL.isElementPresent(driver,By.id(exporting[i])));
        driver.findElement(By.id(exporting[4])).click();
        commonFunctionsForGL.closeAlert(driver);
        driver.findElement(By.id(exporting[2])).click();
        driver.findElement(By.id(exporting[3])).click();
        driver.findElement(By.id(exporting[4])).click();

        driver.findElement(By.id(downloadLink)).click();
        switchToOldWindow(driver,currentURL);
        driver.switchTo().defaultContent();
        driver.switchTo().frame("panel2");
        driver.findElement(By.id(exporting[5])).click();
    }
    public void switchToOldWindow(WebDriver driver,String url){
    /*    WebDriver popup=null;
        Set<String> windowIterator = driver.getWindowHandles();
        Iterator iter = windowIterator.iterator();
        while(iter.hasNext()) {
            String windowHandle = iter.next().toString();
            popup = driver.switchTo().window(windowHandle);
            if (popup.getTitle().equals(driver.getTitle())) {
                url=driver.getCurrentUrl();
                driver.switchTo().window(url);
                break;
            }
        }
*/

        WebDriver popup = null;
        // String windowname=driver.getWindowHandle();
        Set<String> windowname = driver.getWindowHandles();
        System.out.println("window size "+windowname.size());
        Iterator<String> window = windowname.iterator();

        while (window.hasNext()) {
            String windowHandle = window.next();
            popup = driver.switchTo().window(windowHandle);
            popup = driver.switchTo().defaultContent().switchTo().frame("windowHandle");

            System.out.println("------------------POP-UP WINDOW NAME---->"+ popup.getTitle().toString());
            // if (popup.getTitle().toString().equalsIgnoreCase("Window Two")) {
            popup.findElement(By.name("Save File")).click();
            //Thread.sleep(5000);
            break;
        }
    }
}

