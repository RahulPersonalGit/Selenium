package GL;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.DesiredCapabilities;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public abstract  class BrowserConfig {
    private static final int IMG_WIDTH =500;
    private static final int IMG_HEIGHT = 100;
    protected  String URL;
    protected  String baseUrl;
    protected  String username;
    protected  String ScreenShotPath;
    protected String PDFPath;
    protected  String wac;
    protected String SeleniumGrid;
    protected  DesiredCapabilities[] browsers ;
    protected String ZipPath;
    protected WebDriver augmentedDriver;
    protected int FirefoxInstances;
    protected int IEInstances;
    protected int ChromeInstances;
    protected String Firefoxversion[];
    protected String IEversion[];
    protected  String ChromeVersion[] ;
    protected BrowserConfig() {

        InputStream in =getClass().getClassLoader().getResourceAsStream("file.properties");
        Properties p = new Properties();
        try {
            p.load(in);
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
//        // system.out.println("Reading Config.." );
        baseUrl = p.getProperty("baseUrl");
//        // system.out.println("baseUrl = " + baseUrl );
        URL=p.getProperty("URL");
//        // system.out.println("URL = " + URL );
        username=p.getProperty("username");
//        // system.out.println("username = " + username );
        ScreenShotPath=p.getProperty("ScreenShotPath");
//        // system.out.println("ScreenShotPath = " + ScreenShotPath );
        PDFPath=p.getProperty("PDFPath");
//        // system.out.println("PDFPath = " + PDFPath );
        SeleniumGrid=p.getProperty("SeleniumGrid");
//        // system.out.println("SeleniumGrid = " + SeleniumGrid );
        wac=p.getProperty("wac");
//        // system.out.println("wac = " + wac );
        ZipPath=p.getProperty("ZIPPath");

        FirefoxInstances= Integer.parseInt(p.getProperty("Firefox"));
        IEInstances=  Integer.parseInt(p.getProperty("InternetExplorer"));
        ChromeInstances=Integer.parseInt(p.getProperty("Chrome"));

        browsers= new DesiredCapabilities[FirefoxInstances+IEInstances+ChromeInstances];
        Firefoxversion = p.getProperty("FireFoxVersion").split(",");
        IEversion      = p.getProperty("InternetExplorerVersion").split(",");
        ChromeVersion  = p.getProperty("ChromeVersion").split(",");

        initializebrowser(FirefoxInstances,"Firefox");
        initializebrowser(ChromeInstances,"Chrome");
        initializebrowser(IEInstances,"InternetExplorer");

    }

    public void initializebrowser(int instances,String browser)
    {
        if(browser.equals("Firefox"))
        {

            for(int counter =0;counter<instances;counter++)
            {
                browsers[counter]=DesiredCapabilities.firefox();
                String f=Firefoxversion[counter];
//                // system.out.println(f);
                browsers[counter].setVersion(f);
            }

        }
        if(browser.equals("InternetExplorer"))
        {   int counter,j;
            for(counter=FirefoxInstances,j=0;counter<FirefoxInstances+instances;counter++,j++)
            {
                browsers[counter]=DesiredCapabilities.internetExplorer();
                String g=IEversion[j];
//                // system.out.println(g);
                browsers[counter].setVersion(g);
            }
        }
        if(browser.equals("Chrome"))
        {   int counter,j;
            for(counter =(FirefoxInstances+IEInstances),j=0;counter<(FirefoxInstances+IEInstances)+instances;counter++,j++)
            {
                browsers[counter]=DesiredCapabilities.chrome();
                String h=ChromeVersion[j];
//                // system.out.println(h);
                browsers[counter].setVersion(h);
            }
        }
    }



    protected void  resizeImage(String FileName)
    {

        BufferedImage originalImage =null;
        try {
            originalImage = ImageIO.read(new File(ScreenShotPath +"/"+ FileName));
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_RGB : originalImage.getType();

        double thumbRatio = (double) IMG_WIDTH / (double) IMG_HEIGHT;
        int imageWidth = originalImage.getWidth(null);
        int imageHeight = originalImage.getHeight(null);

        double aspectRatio = (double) imageWidth / (double) imageHeight;
        if (thumbRatio < aspectRatio) {
            imageHeight = IMG_HEIGHT  ;
        } else {
            imageWidth = IMG_WIDTH     ;

        }
//        // system.out.println("Aspect Ratio" + aspectRatio + "Thumbratio" + thumbRatio);

        // Draw the scaled image                 newImage       newHeight
        BufferedImage newImage = new BufferedImage(imageWidth, imageHeight, type);
        //   BufferedImage newImage = new BufferedImage(newWidth, newHeight,originalImage);
        Graphics2D graphics2D = newImage.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.drawImage(originalImage, 0, 0, imageWidth, imageHeight, null);


        try {
            ImageIO.write(newImage, "jpeg", new File(ScreenShotPath+"/"+FileName));
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }


    }
    protected void  takeScreenShot(WebDriver driver,String FileName)
    {
        File scrFile;
        int type;
        BufferedImage originalImage,resizeImageJpg;

        try {
            if(SeleniumGrid.equals("Y"))
            {
                augmentedDriver = new Augmenter().augment(driver);
            }
            else
            {
                augmentedDriver=driver;
            }
            // augmentedDriver = new Augmenter().augment(driver);
            scrFile = ((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File(ScreenShotPath+"/" + FileName));

        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }

    }
    protected void EnterPassword(WebDriver driver) {

        driver.findElement(By.linkText("1")).click();
        driver.findElement(By.linkText("2")).click();
        driver.findElement(By.linkText("3")).click();
        driver.findElement(By.linkText("1")).click();
        driver.findElement(By.linkText("2")).click();
        driver.findElement(By.linkText("3")).click();
    }


    protected  void makeZip(String BrowserName)
    {
        try
        {

//            deleteFiles();
//            // system.out.println("Zipping file at path"+ZipPath);
            Date date = new Date() ;
            String file = new Timestamp(date.getTime()).toString().replaceAll(" ","").replaceAll("-","").replaceAll(":","");
            File inFolder=new File(ScreenShotPath);
            File outFolder=new File(ZipPath+"/Report"+file+BrowserName+".zip");
            ZipOutputStream out = new ZipOutputStream(new
                    BufferedOutputStream(new FileOutputStream(outFolder)));
            BufferedInputStream in = null;
            byte[] data  = new byte[1000];
            String files[] = inFolder.list();
//            // system.out.println(files.length);
            for (int i=0; i<files.length; i++)
            {
                in = new BufferedInputStream(new FileInputStream
                        (inFolder.getPath() + "/" + files[i]), 1000);
                out.putNextEntry(new ZipEntry(files[i]));
                int count;
                while((count = in.read(data,0,1000)) != -1)
                {
                    out.write(data, 0, count);
                }
                out.closeEntry();
            }
            out.flush();
            out.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

//    protected void makePDF(){
//        Document document=new Document();
//        Date date = new Date() ;
//        Image image;
//        String file = new Timestamp(date.getTime()).toString().replaceAll(" ","").replaceAll("-","").replaceAll(":","");
//        try {
//            // system.out.println("MakingPDF");
//            PdfWriter.getInstance(document, new FileOutputStream(ZipPath+"Report"+file+".pdf"));
//            document.open();
//            File inFolder=new File(ScreenShotPath);
//            String files[] = inFolder.list();
//            for(String imageName : files)
//            {
//                resizeImage(imageName);
//                image = com.itextpdf.text.Image.getInstance(ScreenShotPath +"/"+ imageName);
//                document.add(image);
//            }
//            document.close();
//
//        } catch (DocumentException e) {
//            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//        } catch (MalformedURLException e) {
//            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//        } catch (IOException e) {
//            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
//        }
//
//    }

    public void deleteFiles(){
//        // system.out.println("Deleting files at "+ ZipPath);
        File file = new File(ZipPath);
        file.setReadable(false);
        if(file.delete())
        {
//            // system.out.println("Files Deleted Sucessfully");
        }
        else
        {
//            // system.out.println("Files Not Deleted");
        }
//        String[] myFiles;
//        boolean wasDeleted;
//        if(file.isDirectory()){
//            myFiles = file.list();
//            // system.out.println("No.of files to be deleted"+myFiles.length);
//            for (int i=0; i<myFiles.length; i++) {
//                File myFile = new File(file, myFiles[i]);
//                wasDeleted = myFile.delete();
//                if (!wasDeleted)
//                {
//                    // system.out.println("File not deleted"+myFiles[i]);
//                }
//            }
//        }

    }
}