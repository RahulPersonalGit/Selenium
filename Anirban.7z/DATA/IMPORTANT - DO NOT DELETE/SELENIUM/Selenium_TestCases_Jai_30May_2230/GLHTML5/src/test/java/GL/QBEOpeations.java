package GL;


import org.openqa.selenium.*;

import java.io.IOException;
import java.util.List;



/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/11/13
 * Time: 12:07 PM
 * To change this template use File | Settings | File Templates.
 */
public class QBEOpeations {
    CommonFunctionsForQBE commonFunctionsForQBE=new CommonFunctionsForQBE();
    GL.CSVReader csvReader=new CSVReader();
    String hyperLink[]=csvReader.readCSV("hyperLink","TimeZone.csv");

    public void testGLQBE1(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        String components[]={"","Help7","Close8","MCB_SearchWC_wca_employeeReference_label","MCB_SearchWC_wca_employeeReference","MCB_SearchWC_wca_loginId_label","MCB_SearchWC_wca_loginId",
                "MCB_SearchWC_wca_firstName_label","MCB_SearchWC_wca_firstName","MCB_SearchWC_wca_businessPartner_label","MCB_SearchWC_wca_businessPartner","MCB_SearchWC_wca_userStatus_label","selectCombo_MCB_SearchWC_wca_userStatus_Text",
                "MCB_SearchWC_wca_lastLoginTime_label","MCB_SearchWC_wca_lastLoginTime","MCB_SearchWC_wca_userEffectiveDate_label","MCB_SearchWC_wca_userEffectiveDate","srchBut_2","bui_w_SearchListQBE_Table","bui_w_SearchListQBE_Table_prev_but","bui_w_SearchListQBE_Table_next_but"};
        String ids[]={"ar_ct_UserDetail_N_wca_TimeZone_button"};
        String panels[]={"panel2","CWpanel1"};
        String tableHeaders[]={"wca_LoginId","wca_firstName","wca_employeeReference","wca_businessPartner","wca_processingCenter","wca_emailID"};

        /*Blank Search*/

        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("srchBut_2")).click();
        while(driver.findElement(By.id(components[components.length-1])).isEnabled()){
            driver.findElement(By.id(components[components.length-1])).click();
            Thread.sleep(10);
        }
        while(driver.findElement(By.id(components[components.length-2])).isEnabled()){
            driver.findElement(By.id(components[components.length-2])).click();
            Thread.sleep(10);
        }
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","Arun");


        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        sendKeysToElement(driver,"MCB_SearchWC_wca_firstName","suchi");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_firstName",new String[]{"suchi"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","suchi");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_firstName",new String[]{"suchi"},0);



        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        sendKeysToElement(driver,"MCB_SearchWC_wca_loginId","q");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_loginId",new String[]{"q"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","q");


        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        sendKeysToElement(driver,"MCB_SearchWC_wca_businessPartner","465465");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_businessPartner",new String[]{"465465"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","465465");


        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("MCB_SearchWC_wca_lastLoginTime")).sendKeys("");
        sendKeysToElement(driver,"MCB_SearchWC_wca_lastLoginTime","00:00:00");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_lastLoginTime",new String[]{"00:00:00"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","00:00:00");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_lastLoginTime",new String[]{"00:00:00"},0);


        switchToPanelGL(driver,panels);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id("MCB_SearchWC_wca_userEffectiveDate")).sendKeys("");
        sendKeysToElement(driver,"MCB_SearchWC_wca_userEffectiveDate","04/12/2012");
        driver.findElement(By.id("srchBut_2")).click();
        System.out.println("table data ="+commonFunctionsForQBE.tableData(driver,"bui_w_SearchListQBE_Table","wca_userEffectiveDate",new String[]{"04/12/2012"},0));
        commonFunctionsForQBE.doubleClickTable(driver,"bui_w_SearchListQBE_Table","04/12/2012");
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);

        Thread.sleep(1000);
        driver.findElement(By.id("SearchNow1")).click();
        commonFunctionsForQBE.tableData(driver,"bui_ct_GL_ControlsSearchList_Table","wca_userEffectiveDate",new String[]{"04/12/2012"},0);
    }

    public void testQBEInSearchListQBE(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;

        String components[]=csvReader.readCSV("qbeSLcomponents","TimeZone.csv");
        String ids[]=csvReader.readCSV("qbeSLids","TimeZone.csv");
        String panels[]=csvReader.readCSV("qbeSLpanels","TimeZone.csv");
        String tableHeaders[]=csvReader.readCSV("qbeSLtableHeaders","TimeZone.csv");
        String textBox[]=csvReader.readCSV("qbeSLtextBox","TimeZone.csv");
        String inputValue[]=csvReader.readCSV("qbeSLinputValue","TimeZone.csv");
        String tableDataValue[]=csvReader.readCSV("qbeSLtableDataValue","TimeZone.csv");
        String colHeader[]=csvReader.readCSV("qbeSLcolHeader","TimeZone.csv");
        String dblClickValue[]=csvReader.readCSV("qbeSLdblClickValue","TimeZone.csv");
        String testValue[]=csvReader.readCSV("qbeSLtestValue","TimeZone.csv");
        String search[]=csvReader.readCSV("qbeSLsearch","TimeZone.csv");


        String tableId[]=csvReader.readCSV("qbeSLtableId","TimeZoneNew.csv");
        String bpValue[]=csvReader.readCSV("qbeSLbpValue","TimeZoneNew.csv");

        switchToPanel(driver, panels, ids[1]);
        commonFunctionsForQBE.checkComponents(driver,components);

        driver.findElement(By.id(search[1])).click();
        commonFunctionsForQBE.doubleClickTable(driver,tableId[1],"Arun");

        for(int i = 1;i<textBox.length;i++){
            switchToPanel(driver, panels, ids[1]);
            commonFunctionsForQBE.checkComponents(driver, components);
            sendKeysToElement(driver, textBox[i], inputValue[i]);
            driver.findElement(By.id(search[1])).click();
            commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");
            commonFunctionsForQBE.closeAlert(driver);
            System.out.println("table data =" + commonFunctionsForQBE.tableData(driver, tableId[1], colHeader[i], new String[]{testValue[i]}, 0));

           if(commonFunctionsForQBE.searchInTable(driver,tableId[1],dblClickValue[i])!=null){
            commonFunctionsForQBE.doubleClickTable(driver, tableId[1], dblClickValue[i]);
            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            driver.switchTo().frame(panels[1]);
            Thread.sleep(1000);
            String txtValue=driver.findElement(By.id(bpValue[1])).getAttribute("title");
            System.out.println(txtValue);
            driver.findElement(By.id(search[2])).click();
               System.out.println("table data after search ="+commonFunctionsForQBE.tableData(driver, tableId[2], bpValue[2], new String[]{tableDataValue[i]}, 0));
        }else{
              driver.findElement(By.id(components[2])).click();

        }

        }

    }
    public void testSearchListQBE(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        String components[]=csvReader.readCSV("SLQBEcomponents","TimeZone.csv");
        String tableHeaders[]=csvReader.readCSV("SLQBEtableHeaders","TimeZone.csv");
        String inputValue[]=csvReader.readCSV("SLQBEinputValue","TimeZone.csv");
        String textBoxId[]=csvReader.readCSV("SLQBEtextBoxId","TimeZone.csv");
        String search[]=csvReader.readCSV("SLQBEsearch","TimeZone.csv");
        String tableId[]=csvReader.readCSV("SLQBEtableId","TimeZone.csv");
        String navBut[]=csvReader.readCSV("SLQBEnavBut","TimeZone.csv");

        commonFunctionsForQBE.checkComponents(driver,components);
        testSearchCrt(driver,inputValue,textBoxId,search,tableHeaders,tableId[1]);
        driver.findElement(By.id(search[1])).click();
        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],tableHeaders[1]);
        testQBEInSearchListQBE(driver);

    }
    public void testSearchListQBENew(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        String components[]=csvReader.readCSV("SLQBEcomponents","TimeZoneNew.csv");
        String tableHeaders[]=csvReader.readCSV("SLQBEtableHeaders","TimeZoneNew.csv");
        String inputValue[]=csvReader.readCSV("SLQBEinputValue","TimeZoneNew.csv");
        String textBoxId[]=csvReader.readCSV("SLQBEtextBoxId","TimeZoneNew.csv");
        String search[]=csvReader.readCSV("SLQBEsearch","TimeZoneNew.csv");
        String tableId[]=csvReader.readCSV("SLQBEtableId","TimeZoneNew.csv");
        String navBut[]=csvReader.readCSV("SLQBEnavBut","TimeZoneNew.csv");

        commonFunctionsForQBE.checkComponents(driver,components);
        testSearchCrtSL(driver,inputValue,textBoxId,search,tableHeaders,tableId[1]);
        driver.findElement(By.id(search[1])).click();

         testQBEInSearchListQBENew(driver);
//        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],tableHeaders[1]);

    }
    public void testQBEInSearchListQBENew(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;

        String components[]=csvReader.readCSV("qbeSLcomponents","TimeZoneNew.csv");
        String ids[]=csvReader.readCSV("qbeSLids","TimeZoneNew.csv");
        String panels[]=csvReader.readCSV("qbeSLpanels","TimeZoneNew.csv");
        String tableHeaders[]=csvReader.readCSV("qbeSLtableHeaders","TimeZoneNew.csv");
        String textBox[]=csvReader.readCSV("qbeSLtextBox","TimeZoneNew.csv");
        String inputValue[]=csvReader.readCSV("qbeSLinputValue","TimeZoneNew.csv");
        String tableDataValue[]=csvReader.readCSV("qbeSLtableDataValue","TimeZoneNew.csv");
        String colHeader[]=csvReader.readCSV("qbeSLcolHeader","TimeZoneNew.csv");
        String dblClickValue[]=csvReader.readCSV("qbeSLdblClickValue","TimeZoneNew.csv");
        String testValue[]=csvReader.readCSV("qbeSLtestValue","TimeZoneNew.csv");
        String search[]=csvReader.readCSV("qbeSLsearch","TimeZoneNew.csv");


        String tableId[]=csvReader.readCSV("qbeSLtableId","TimeZoneNew.csv");
        String bpValue[]=csvReader.readCSV("qbeSLbpValue","TimeZoneNew.csv");

        switchToPanelNew(driver,panels,ids[1]);
        commonFunctionsForQBE.checkComponents(driver,components);

        clickSelect(driver,"bui_ct_GL_qbeAllControlsSearch_wca_userStatus","option","Entered");
        driver.findElement(By.id(search[1])).click();
        commonFunctionsForQBE.doubleClickTableNew(driver, tableId[1], "Arun");

       /* for(int i = 1;i<textBox.length;i++){
            switchToPanelNew(driver, panels, ids[1]);
            commonFunctionsForQBE.checkComponents(driver, components);
            clickSelect(driver,"bui_ct_GL_qbeAllControlsSearch_wca_userStatus","option","Entered");
            sendKeysToElement(driver, textBox[i], inputValue[i]);
            driver.findElement(By.id(search[1])).click();
            commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");
            commonFunctionsForQBE.closeAlert(driver);
            System.out.println("table data =" + commonFunctionsForQBE.tableDataForNewRI(driver, tableId[1], colHeader[i], new String[]{testValue[i]}, 0));

            if(commonFunctionsForQBE.searchInTable(driver,tableId[1],dblClickValue[i])!=null){
                commonFunctionsForQBE.doubleClickTable(driver, tableId[1], dblClickValue[i]);
                driver.switchTo().defaultContent();
                Thread.sleep(1000);
                driver.switchTo().frame(panels[1]);
                Thread.sleep(1000);
                String txtValue=driver.findElement(By.id(bpValue[1])).getAttribute("title");
                System.out.println(txtValue);
                driver.findElement(By.id(search[2])).click();
                System.out.println("table data after search ="+commonFunctionsForQBE.tableDataForNewRI(driver,tableId[2],bpValue[2],new String[]{tableDataValue[i]},0));
            }else{
                driver.findElement(By.id(components[2])).click();

            }}*/

        switchToPanelNew(driver, panels, ids[1]);
        commonFunctionsForQBE.checkComponents(driver, components);
        clickSelect(driver,"bui_ct_GL_qbeAllControlsSearch_wca_userStatus","option","Entered");
        sendKeysToElement(driver, textBox[1], inputValue[1]);
        driver.findElement(By.id(search[1])).click();
        commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");
        commonFunctionsForQBE.closeAlert(driver);
        System.out.println("table data =" + commonFunctionsForQBE.tableDataForNewRI(driver, tableId[1], colHeader[1], new String[]{testValue[1]}, 0));
        commonFunctionsForQBE.doubleClickTableNew(driver, tableId[1], dblClickValue[1]);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[1]);
        Thread.sleep(1000);
        driver.findElement(By.id(search[2])).click();
        System.out.println("table data after search ="+commonFunctionsForQBE.tableDataForNewRI(driver,tableId[2],bpValue[2],new String[]{tableDataValue[1]},0));




    }

    public void sendKeysToElement(WebDriver driver,String elementId,String value){
        List<WebElement> allIds=driver.findElements(By.id(elementId));
        for(WebElement id:allIds){
            if(id.getTagName().equalsIgnoreCase("input")){
                id.clear();
                id.sendKeys(value);
            }
        }
    }

    public void switchToPanel(WebDriver  driver,String panels[],String id) throws InterruptedException {
        driver.switchTo().defaultContent();
        Thread.sleep(2000);
        driver.switchTo().frame(panels[1]);
        Thread.sleep(2000);
        driver.findElement(By.id(id)).click();
        driver.switchTo().frame(panels[2]);
        driver.switchTo().frame("mywindowframe");
        Thread.sleep(2000);
    }

    public void switchToPanelNew(WebDriver  driver,String panels[],String id) throws InterruptedException {

        driver.switchTo().defaultContent();
        Thread.sleep(2000);
        driver.switchTo().frame(panels[1]);
        Thread.sleep(2000);
        driver.findElement(By.id(id)).click();
        Thread.sleep(2000);
        driver.switchTo().frame(driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe")));


    }

    public void switchToPanelGL(WebDriver  driver,String panels[]) throws InterruptedException {
        WebElement element;
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        element=driver.findElement(By.id("drill_simpleSearchValue"));
        element=element.findElement(By.tagName("img"));
        element.click();
        driver.switchTo().frame(panels[1]);
        driver.switchTo().frame("mywindowframe");
        Thread.sleep(2000);
    }
    public void switchToPanelGLNew(WebDriver  driver,String panels[]) throws InterruptedException {
        WebElement element;
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        driver.switchTo().frame(panels[0]);
        Thread.sleep(1000);
        element=driver.findElement(By.id("bui_ct_GL_ControlsSearch_wca_employeeReference_button"));
        Thread.sleep(1000);
        element.click();
        Thread.sleep(1000);
        driver.switchTo().frame(driver.findElement(By.id("loadDialog")).findElement(By.tagName("iframe")));
        Thread.sleep(2000);
    }


    public void clickSelect(WebDriver driver,String textBoxId,String tagName,String valueToBeSelected) throws InterruptedException {
        WebElement element2=commonFunctionsForQBE.findDisplayedElement(driver,textBoxId);
        if(tagName.equals("option")){
            Thread.sleep(1000);
            element2.click();
        };
        List<WebElement> allOptions=element2.findElements(By.tagName(tagName));
        for(WebElement option:allOptions){
            if(option.getText().equalsIgnoreCase(valueToBeSelected)){
                option.click();

                try{
                    //For IE
                    if(new CommonFunctionsForGL().getBrowserName(driver).contains("internet")){
                        option.click();
                        ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", option);
                    }
                    else
                    {
                        // For FireFox and Chrome
                        ((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                                "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                                "arguments[0].dispatchEvent(evt);", option);
                    }
                }catch (Exception ex){}
                break;
            }

        }
    }
    public void testSearchCrt(WebDriver driver,String[] inputValue,String[] textBoxId,String[] search,String[] tableHeaders,String tableId) throws InterruptedException {
        List<WebElement> elements;
        WebElement element=null;

        for(int i=1;i<textBoxId.length;i++){
             List<WebElement> txtelements=driver.findElements(By.id(textBoxId[i]));
              for(WebElement ele:txtelements){
                  if(ele.getTagName().equalsIgnoreCase("input")){
                      element=ele;
                        break;
                  }
              }
            if(tableHeaders[i].equalsIgnoreCase("wca_userStatus")){

                WebElement element2=driver.findElement(By.id(textBoxId[i]));
                element2.click();
                List<WebElement> allOptions=element2.findElements(By.tagName("option"));
                for(WebElement option:allOptions){
                    if(option.getText().equals("Entered")){
                        option.click();
                        break;
                    }

                }



            }else{
            commonFunctionsForQBE.clearContent(driver,element);
            element.sendKeys(inputValue[i]);
            }
            commonFunctionsForQBE.clearContent(driver,element);
            element.sendKeys(inputValue[i]);
            Thread.sleep(200);
            try{driver.findElement(By.id(search[1])).click();}catch(Exception e){}

            commonFunctionsForQBE.closeAlert(driver);
            commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");

            /*System.out.println(commonFunctionsForQBE.tableData(driver,tableId, tableHeaders[i], new String[]{inputValue[i]}, 0));
            Thread.sleep(200);*/
            commonFunctionsForQBE.clearContent(driver, element);
        }
    }
    public void testSearchCrtSL(WebDriver driver,String[] inputValue,String[] textBoxId,String[] search,String[] tableHeaders,String tableId) throws InterruptedException {
        List<WebElement> elements;
        WebElement element=null;

        for(int i=1;i<textBoxId.length;i++){
            List<WebElement> txtelements=driver.findElements(By.id(textBoxId[i]));
            for(WebElement ele:txtelements){
                if(ele.getTagName().equalsIgnoreCase("input")){
                    element=ele;
                    break;
                }
            }
            if(tableHeaders[i].equalsIgnoreCase("wca_userStatus")){

               driver.findElement(By.id(textBoxId[i])).click();
                clickSelect(driver,"MCB_SearchWC_wca_userStatus-lists","li","Active");



            }else{
                commonFunctionsForQBE.clearContent(driver,element);
                element.sendKeys(inputValue[i]);
            }
            commonFunctionsForQBE.clearContent(driver,element);
            element.sendKeys(inputValue[i]);
            Thread.sleep(200);
            try{driver.findElement(By.id(search[1])).click();}catch(Exception e){}

            commonFunctionsForQBE.closeAlert(driver);
            commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");

            /*System.out.println(commonFunctionsForQBE.tableData(driver,tableId, tableHeaders[i], new String[]{inputValue[i]}, 0));
            Thread.sleep(200);*/
            commonFunctionsForQBE.clearContent(driver, element);
        }
    }

    public void testCustomSearchCrt(WebDriver driver,String[] inputValue,String[] textBoxId,String[] search,String[] tableHeaders,String tableId){
        WebElement element1,element2;
        String[] allInput=csvReader.readCSV("GLQBEallInput","TimeZone.csv");
        for(int i=1;i<textBoxId.length-1;i++){
            element1=driver.findElement(By.id(textBoxId[i])) ;
            element2=driver.findElement(By.id(textBoxId[i+1]));
            element1.sendKeys(inputValue[i]);
            element2.sendKeys(inputValue[i + 1]);
            driver.findElement(By.id(search[1])).click();
            commonFunctionsForQBE.closeAlert(driver);
            commonFunctionsForQBE.closePopup(driver,"footerCloseBtn");
            commonFunctionsForQBE.closePopupNew(driver,"bancs-dialog-close");
            System.out.println("1." + commonFunctionsForQBE.tableData(driver, tableId, tableHeaders[i], new String[]{inputValue[i]}, 0));
            System.out.println("2."+commonFunctionsForQBE.tableData(driver,tableId,tableHeaders[i+1],new String[]{inputValue[i+1]},0));
            commonFunctionsForQBE.clearContent(driver, element1);
            commonFunctionsForQBE.clearContent(driver,element2);

        }
        driver.findElement(By.id(textBoxId[1])).sendKeys(allInput[1]);
        driver.findElement(By.id(textBoxId[2])).sendKeys(allInput[2]);
        driver.findElement(By.id(textBoxId[3])).sendKeys(allInput[3]);
        driver.findElement(By.id(textBoxId[4])).sendKeys(allInput[4]);
        driver.findElement(By.id(textBoxId[5])).sendKeys(allInput[5]);
        driver.findElement(By.id(search[1])).click();
        element1 = driver.findElement(By.id(textBoxId[1]));
        commonFunctionsForQBE.clearContent(driver,element1);
        element1=driver.findElement(By.id(textBoxId[2]));
        commonFunctionsForQBE.clearContent(driver,element1);
        element1=driver.findElement(By.id(textBoxId[3]));
        commonFunctionsForQBE.clearContent(driver,element1);
        element1=driver.findElement(By.id(textBoxId[4]));
        commonFunctionsForQBE.clearContent(driver,element1);
        element1=driver.findElement(By.id(textBoxId[5]));
        commonFunctionsForQBE.clearContent(driver,element1);
    }
    public void testGLQBE(WebDriver driver) throws InterruptedException {

        String components[]=csvReader.readCSV("GLQBEcomponents","TimeZoneNew.csv");
        String tableHeaders[]=csvReader.readCSV("GLQBEtableHeaders","TimeZoneNew.csv");
        String inputValue[]=csvReader.readCSV("GLQBEinputValue","TimeZoneNew.csv");
        String textBoxId[]=csvReader.readCSV("GLQBEtextBoxId","TimeZoneNew.csv");
        String search[]=csvReader.readCSV("GLQBEsearch","TimeZoneNew.csv");
        String tableId[]=csvReader.readCSV("GLQBEtableId","TimeZoneNew.csv");
        String navBut[]=csvReader.readCSV("GLQBEnavBut","TimeZoneNew.csv");

        commonFunctionsForQBE.checkComponents(driver,components);
        testSearchCrt(driver,inputValue,textBoxId,search,tableHeaders,tableId[1]);
        testCustomSearchCrt(driver,inputValue,textBoxId,search,tableHeaders,tableId[1]);
        driver.findElement(By.id(search[1])).click();
        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],tableHeaders[1]);

    }
    public void testGLQBENew(WebDriver driver) throws InterruptedException {

        String components[]=csvReader.readCSV("GLQBEcomponents","TimeZoneNew.csv");
        String tableHeaders[]=csvReader.readCSV("GLQBEtableHeaders","TimeZoneNew.csv");
        String inputValue[]=csvReader.readCSV("GLQBEinputValue","TimeZoneNew.csv");
        String textBoxId[]=csvReader.readCSV("GLQBEtextBoxId","TimeZoneNew.csv");
        String search[]=csvReader.readCSV("GLQBEsearch","TimeZoneNew.csv");
        String tableId[]=csvReader.readCSV("GLQBEtableId","TimeZoneNew.csv");
        String navBut[]=csvReader.readCSV("GLQBEnavBut","TimeZoneNew.csv");

        commonFunctionsForQBE.checkComponents(driver,components);
        testSearchCrt(driver,inputValue,textBoxId,search,tableHeaders,tableId[1]);
        driver.findElement(By.id(search[1])).click();
        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],tableHeaders[1]);
        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],tableHeaders[1]);

    }

    public void testQBEInsideTestRangeQBE(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;

        String components[]=csvReader.readCSV("TRQBEcomponents","TimeZone.csv");
        String colHeader[]=csvReader.readCSV("TRQBEcolHeader","TimeZone.csv");
        String value[]=csvReader.readCSV("TRQBEvalue","TimeZone.csv");
        String textBox[]=csvReader.readCSV("TRQBEtextBox","TimeZone.csv");
        String search[]=csvReader.readCSV("TRQBEsearch","TimeZone.csv");
        String panels[]=csvReader.readCSV("TRQBEpanels","TimeZone.csv");
        String ids[]=csvReader.readCSV("TRQBEids","TimeZone.csv");
        String dblClickValue[]=csvReader.readCSV("TRQBEdblClickValue","TimeZone.csv");
        String tableDataValue[]=csvReader.readCSV("TRQBEtableDataValue","TimeZone.csv");
        String tableId[]=csvReader.readCSV("TRQBEtableId","TimeZone.csv");
        String bpTextId[]=csvReader.readCSV("TRQBEbpTextId","TimeZone.csv");
        String columnHdr[]=csvReader.readCSV("TRQBEcolumnHdr","TimeZone.csv");



        /*Blank Search*/

        switchToPanel(driver,panels,ids[1]);
        commonFunctionsForQBE.checkComponents(driver,components);
        driver.findElement(By.id(search[1])).click();

        commonFunctionsForQBE.doubleClickTable(driver,tableId[1],"Arun");

        for(int i = 1;i<textBox.length;i++){
            switchToPanel(driver, panels, ids[1]);
            commonFunctionsForQBE.checkComponents(driver, components);

            driver.findElement(By.id(textBox[i])).sendKeys(value[i]);
            driver.findElement(By.id(search[1])).click();
            System.out.println("table data =" + commonFunctionsForQBE.tableData(driver, tableId[1], colHeader[i], new String[]{dblClickValue[i]}, 0));
            commonFunctionsForQBE.doubleClickTable(driver, tableId[1], dblClickValue[i]);
            driver.switchTo().defaultContent();
            Thread.sleep(1000);
            driver.switchTo().frame(panels[1]);
            Thread.sleep(1000);
            String txtValue=driver.findElement(By.id(bpTextId[1])).getAttribute("title");
            System.out.println(txtValue);
            driver.findElement(By.id(search[2])).click();
            System.out.println("table data after search ="+commonFunctionsForQBE.tableData(driver,tableId[2],columnHdr[1],new String[]{tableDataValue[i]},0));
        }

    }

    public void testRangeQBE(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        CommonFunctions commonFunctions=new CommonFunctions();
        List<WebElement> list=null,list2;

        String[] valueL=csvReader.readCSV("TQBEvalueL","TimeZone.csv");
        String[] valueB=csvReader.readCSV("TQBEvalueB","TimeZone.csv");
        String[] idLogin=csvReader.readCSV("TQBEidLogin","TimeZone.csv");
        String[] idBP=csvReader.readCSV("TQBEidBP","TimeZone.csv");
        String[] search=csvReader.readCSV("TQBEsearch","TimeZone.csv");
        String[] navBut=csvReader.readCSV("TQBEnavBut","TimeZone.csv");
        String[] tableId=csvReader.readCSV("TQBEtableId","TimeZone.csv");
        String[] opBut=csvReader.readCSV("TQBEopBut","TimeZone.csv");
        String[] qbeBut=csvReader.readCSV("TQBEqbeBut","TimeZone.csv");
        String[] panels=csvReader.readCSV("TQBEpanels","TimeZone.csv");
        String[] labels=csvReader.readCSV("TQBElabels","TimeZone.csv");

        driver.findElement(By.id(search[1])).click();
        new PaginationTester().testPagination(driver,tableId[1],navBut[1],navBut[2],"wca_employeeReference");
        new CommonFunctionsForQBE().rangeQBE(driver,idLogin,labels[1],valueL,search[1],tableId[1],2);
        new CommonFunctionsForQBE().rangeQBE(driver,idBP,labels[2],valueB,search[1],tableId[1],7);
        Thread.sleep(1000);

        element=driver.findElement(By.id(opBut[1]));
        list=element.findElements(By.tagName("option"));
        for (WebElement x :list) {
            if(x.getAttribute("value").equals("Equals")){
                x.click();
                break;
            }
        }

        element=driver.findElement(By.id(opBut[2]));
        list=element.findElements(By.tagName("option"));
        for (WebElement x :list) {
            if(x.getAttribute("value").equals("Equals")){
                x.click();
                break;
            }
        }
        switchToPanel(driver,panels,qbeBut[1]);
        testQBEInsideTestRangeQBE(driver);
    }




}