package GL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.IOException;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:37 PM
 * To change this template use File | Settings | File Templates.
 */
public class SettingDefault {
    CommonFunctionsForGL commonFunctionsForGL =new CommonFunctionsForGL();
    GL.CSVReader csvReader=new GL.CSVReader();
    String dropdown[]=csvReader.readCSV("dropdown", "GL.csv");
    String asMoreActionsOptions[]=csvReader.readCSV("asMoreActionsOptions","GL.csv");
    String asSavedSearch[]=csvReader.readCSV("asSavedSearch","GL.csv");

    public void setAsDefault(WebDriver driver,String nameToBeSavedAsDefault) throws IOException, InterruptedException {
        driver.findElement(By.id(dropdown[2])).click();
        WebElement element=driver.findElement(By.id(asSavedSearch[2]));
        List<WebElement> allDivs=element.findElements(By.tagName("div"));
        for(WebElement div:allDivs){
            div=div.findElement(By.tagName("button"));
            if(div.getText().equals(nameToBeSavedAsDefault)){
                div.click();
                break;
            }
        }
        driver.findElement(By.id(dropdown[3])).click();
        driver.findElement(By.id(asMoreActionsOptions[3])).click();
        driver.switchTo().defaultContent();
        commonFunctionsForGL.openPage(driver,"riGenericList");
       try{
           driver.switchTo().frame("panel3");
       }catch(Exception e){
           try{driver.switchTo().frame("panel4");
           }
           catch (Exception e1){
               driver.switchTo().frame("panel5");
           }
       }
        Thread.sleep(2000);
        commonFunctionsForGL.checkComponents(driver,csvReader.readCSV("initialASComponents","GL.csv"));
        commonFunctionsForGL.testCloseTabs(driver,new int[]{3});
        driver.switchTo().frame("panel2");
    }
}
