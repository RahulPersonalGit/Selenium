package GL;


import GL.Constants;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

public class CommonFunctionsForQBE {
    GL.Constants constants=new GL.Constants();
    public void Login(WebDriver driver,String[] loginPageData) throws IOException {
        WebElement element;
        try {
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element = driver.findElement(By.id(loginPageData[0]));
            assertTrue("userId is not there", element.isDisplayed());
            element.sendKeys(loginPageData[1]);
            element.sendKeys(Keys.TAB);
            element=driver.findElement(By.id(loginPageData[2]));
            element.sendKeys(loginPageData[3]);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[4]));
            Thread.sleep(100);
            assertTrue("entity is not there", element.isEnabled());
            Thread.sleep(constants.THOUSANDMILLISECONDS);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[5]));
            assertTrue("Login is not there", element.isDisplayed());
            element.sendKeys(Keys.RETURN);
            if ((driver.findElement(By.id(loginPageData[5]))).isDisplayed()) {
                element.sendKeys(Keys.TAB);
                element.sendKeys(Keys.ENTER);
            }
            Thread.sleep(constants.THOUSANDMILLISECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void openPage(WebDriver driver,String pageName) throws IOException, InterruptedException {
        WebElement element;
        Properties event=getProperty("Home");
        boolean flag=false;
        String after,before;
        element=driver.findElement(By.id(event.getProperty("userMenu")));
        for(int i=0;i<5;i++){
            testKeyBoardPress(driver, i);
            element.sendKeys(Keys.RIGHT);
            try{driver.findElement(By.linkText(event.getProperty(pageName))).isDisplayed();}catch(Exception e){continue;}


            before=after="";
            while(true){
                before=driver.findElement(By.className("bancs-menu_active")).getText();
                if(event.getProperty(pageName).equals(before)){
                    flag=true;
                    break;
                }
                element.sendKeys(Keys.DOWN);
                if(before.equals(after)){
                    element.sendKeys(Keys.RIGHT);
                    if(before.equals(driver.findElement(By.className("bancs-menu_active")).getText())) break;
                }
                after=before;
            }
            if(flag) break;
        }
        if(flag)element.sendKeys(Keys.ENTER);
    }
    public boolean tableData(WebDriver driver,String tableId,String header,String value[],int option){
        WebElement element=driver.findElement(By.id(tableId)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        if(index==size)return true;
        return false;
    }
    public int compare(WebElement element,String value[],int option){
        int length=value.length;
        boolean flag=false;
        length-=1;
        switch (option){
            case 0:if(element.getText().equalsIgnoreCase(value[length]))
                    return 1;
                   break;
            case 1:if(!(element.getText().equalsIgnoreCase(value[length])))
                    return 1;
                  break;
            case 2:if(element.getText().contains(value[length].toLowerCase()) || element.getText().contains(value[length].toUpperCase()))
                    return 1;
                   break;
            case 3:if(element.getText().startsWith(value[length].toLowerCase()) || element.getText().startsWith(value[length].toUpperCase()))
                    return 1;
                   break;
            case 4:if(element.getText().endsWith(value[length].toLowerCase()) || element.getText().endsWith(value[length].toUpperCase()))
                    return 1;
                   break;
            case 5:for(int i=1;i<value.length;i++){
                        if(element.getText().equalsIgnoreCase(value[i])){
                            flag=true;
                            break;
                        }
                   }
                   if(flag)return 1;
                    break;
            case 6:int i=1;
                    for(i=1;i<value.length;i++){
                        if(!element.getText().equalsIgnoreCase(value[i])){
                            flag=true;
                        }
                    }
                    if(flag && i==value.length)return 1;
                    break;
            case 7:int val=Integer.parseInt(value[length]);
                    int toCompare=Integer.parseInt(element.getText());
                    if(toCompare>val)
                        return 1;
                    break;
            case 8:int val1=Integer.parseInt(value[length]);
                   int toCompare1=Integer.parseInt(element.getText());
                   if(toCompare1<val1)
                      return 1;
                   break;
            case 9:int val2=Integer.parseInt(value[length]);
                    int toCompare2=Integer.parseInt(element.getText());
                    if(toCompare2>=val2)
                        return 1;
                    break;
            case 10:int val3=Integer.parseInt(value[length]);
                    int toCompare3=Integer.parseInt(element.getText());
                    if(toCompare3<=val3)
                        return 1;
                    break;
            case 11:
            case 12:if(element.getText().charAt(0)==value[length].charAt(0))
                        return 1;
                     break;
        }
        return 0;
    }
    public boolean isElementPresent(WebDriver driver,By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
    public Properties getProperty(String language) throws IOException {
        Properties home=new Properties();
        language+=".properties";
        FileInputStream in=new FileInputStream(language);
        home.load(in);
        return home;
    }
    public boolean testTab(WebDriver driver,int tab,String tabName) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        boolean flag=false;
        driver.switchTo().defaultContent();

            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==tab){
                    element=li.findElement(By.tagName("a"));
                    if(element.getText().equals(tabName)){
                        flag=true;
                        break;
                    }
               }
               i++;
            }
        return flag;
    }
    public void testCloseTabs(WebDriver driver,int[] tab) throws IOException {
        WebElement element;
        Properties tabs=getProperty("Home");
        driver.switchTo().defaultContent();
        for(int a:tab){
            element = driver.findElement(By.id(tabs.getProperty("tab")));
            List<WebElement> allSpanElements = element.findElements(By.tagName("li"));
            int i=1;
            for (WebElement li: allSpanElements) {
                if(i==a){
                    List<WebElement> allLiElements=li.findElements(By.tagName("span"));
                    for(WebElement span:allLiElements)
                        element=span;
                    assertTrue(element+"not found",element.isDisplayed());
                    element.click();
                    break;
                }
                i++;
            }
        }
    }
    public void switchFrame(WebDriver driver,String panel) throws InterruptedException {
        driver.switchTo().frame(panel);
        Thread.sleep(constants.THOUSANDMILLISECONDS);
    }
    public void closeAlert(WebDriver driver){
        try{
            Alert alert = driver.switchTo().alert();
            alert.accept();
        }catch (Exception e){System.out.println("Hello Alert");}
    }
    public void closePopup(WebDriver driver,String id){
        try{
        driver.findElement(By.id(id)).click();
        }catch(Exception e){System.out.println("Hello popup");}
    }
    public void testKeyEventUserMenu(WebDriver driver) throws IOException, InterruptedException {
        Properties menuBar=getProperty("Home");
        WebElement element;
        element=driver.findElement(By.id(menuBar.getProperty("userMenu")));
        assertTrue("userMenu not found",isElementPresent(driver, By.id(menuBar.getProperty("userMenu"))));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        Thread.sleep(constants.TENMILLISECONDS);
    }
    public void testKeyBoardPress(WebDriver driver,int i) throws IOException, InterruptedException {
        Properties menuItem=getProperty("Home");
        Thread.sleep(constants.THOUSANDMILLISECONDS);
        testKeyEventUserMenu(driver);
        WebElement element=driver.findElement(By.id(menuItem.getProperty("userMenu")));
        for(int j=0;j<i;j++)
            element.sendKeys(Keys.DOWN);
    }
    public void previousDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextEnabled(WebDriver driver){
        assertTrue("Previous Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is disabled",driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void prevNextDisabled(WebDriver driver){
        assertTrue("Previous Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_prev_but")).isEnabled());
        assertTrue("Next Button is Enabled",!driver.findElement(By.id("ar_w_UserList_N_Table_next_but")).isEnabled());
    }
    public void configCollapsableAssert(WebDriver driver){
        assertTrue("Config View Size value changed",configViewSize(driver));
        assertTrue("Control Table Button is not displayed",driver.findElement(By.id("ctrlTblBtn")).isDisplayed());
        assertTrue("show table button expanded",!driver.findElement(By.id("Create19")).isDisplayed());
    }
    public void doubleClick(WebDriver driver, WebElement e) {

        /*try{

            e.click();
            ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);


        }catch (Exception ex){}*/

        try{
            //For IE
            if(getBrowserName(driver).contains("internet")){
                e.click();
                ((JavascriptExecutor)driver).executeScript("arguments[0].fireEvent('ondblclick');", e);
            }
            else
            {
                // For FireFox and Chrome
                ((JavascriptExecutor)driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                        "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
                        "arguments[0].dispatchEvent(evt);", e);
            }
        }catch (Exception ex){}

    }
    public void clickSelected(WebDriver driver,String id,String valueToBeClicked) throws InterruptedException {
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allUlElements = element.findElements(By.tagName("li"));
        for(WebElement li:allUlElements){
            if(li.getText().equals(valueToBeClicked)){
               li.sendKeys(Keys.ENTER);
               li.click();
                break;
            }
        }
    }
    public void backToPage(WebDriver driver,String pageName){
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                element.click();
                break;
            }
        }
    }
    public boolean checkPage(WebDriver driver,String pageName){
        boolean flag=false;
        driver.switchTo().defaultContent();
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName)){
                flag=true;
                element.click();
                break;
            }
        }
        return flag;
    }
    public void checkComponents(WebDriver driver,String initialComponents[]){
        for(int i=1;i<initialComponents.length;i++)
            assertTrue(initialComponents[i]+" not found",isElementPresent(driver, By.id(initialComponents[i])));
    }
    public WebElement getElement(List<WebElement> elements){
        for(WebElement ele:elements){
            if(ele.isDisplayed())
                return ele;
        }
        return null;
    }
    public void closePage(WebDriver driver,String pageName){
        assertTrue(pageName + " not found", checkPage(driver, pageName));
        WebElement element = driver.findElement(By.id("stWidthChecker"));
        boolean flag=false;
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li: allLiElements) {
            element = li.findElement(By.tagName("a"));
            element=element.findElement(By.tagName("span"));
            if(element.getText().equals(pageName))
                flag=true;
            if(flag){
                List<WebElement> allSpanElements = li.findElements(By.tagName("span"));
                for(WebElement span:allSpanElements)
                    element=span;
                element.click();
                break;
            }
        }
    }
    public boolean configViewSize(WebDriver driver){
        String s=driver.findElement(By.id("confViewSizeSle")).getAttribute("value");
        if(s.equals("22"))
            return true;
        return false;
    }
    public WebElement searchInTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            table=null;
            if(index==0){index++;continue;}
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                      break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public WebElement searchInTableNew(WebDriver driver,String id,String valueToBeSearched){
        WebElement table=driver.findElement(By.id(id));
        boolean flag=false;
        int index=0;
        List<WebElement> allRows = table.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        for (WebElement row : allRows) {
            table=null;
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            for (WebElement cell : tableData) {
                if(cell.getText().equals(valueToBeSearched) || valueToBeSearched==""){
                    flag=true;
                    table=cell;
                    break;
                }
            }
            if(flag)break;
        }
        return table;
    }
    public WebElement findDisplayedElement(WebDriver driver, String idToBeClicked){
        List<WebElement> elements;
        WebElement element;
        elements=driver.findElements(By.id(idToBeClicked));
        element=getElement(elements);
        return element;
    }

    public void doubleClickTable(WebDriver driver ,String tableId,String valueToBeClicked) throws IOException, InterruptedException {
        WebElement e=searchInTable(driver,tableId,valueToBeClicked);
        if(e!=null){
            doubleClick(driver,e);
        }
    }
    public void doubleClickTableNew(WebDriver driver ,String tableId,String valueToBeClicked) throws IOException, InterruptedException {
        WebElement e=searchInTableNew(driver,tableId,valueToBeClicked);
        if(e!=null){
            doubleClick(driver,e);
        }
    }
    public void rightClickOnTable(WebDriver driver,String id,String valueToBeSearched){
        WebElement element=searchInTable(driver,id,valueToBeSearched);
        if(element!=null){
            element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
        }
    }
    public void doubleClickForSelectOptions(WebDriver driver,String id,String valueToBeClicked,String ids[]){
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allTh=element.findElements(By.tagName("option"));
        String s[]=new String[allTh.size()];
        int index=0;
        for(WebElement el:allTh)
            s[index++]=el.getText();
        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            System.out.println("option attribute="+option.getAttribute("value")+" valeu to be clicked="+valueToBeClicked);
             if(option.getAttribute("value").equals(valueToBeClicked)){
                doubleClick(driver, option);
                checkComponents(driver, ids);
                break;
             }
        }
    }
    public boolean sortingTable(WebDriver driver,String id,String header,int order){
        WebElement element=driver.findElement(By.id(id)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        String previous="";
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            if(order==0){
                if(previous.compareTo(element.getText())<0){  // ascending order
                    previous=element.getText();
                    index++;
                }
            }
            else{
                if(previous.compareTo(element.getText())>0){ //descending  order
                    previous=element.getText();
                    index++;
                }
            }
        }
        if(size==index)
            return true;
        return false;
    }

    public String getBrowserName(WebDriver driver) throws  IOException,InterruptedException {
        Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
        String browserName = caps.getBrowserName();
        String browserVersion = caps.getVersion();
        System.out.println(browserName+" "+browserVersion);
        return  browserName;
    }
    public boolean sortingTable(WebDriver driver,String id,String header,int order,int type) throws ParseException {
        WebElement element=driver.findElement(By.id(id)).findElement(By.tagName("tbody"));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElements(By.tagName("tr"));
        int size=allTr.size();
        if(type==0)
            index+=sortInteger(order,allTr,position);
        else if(type==1)
            index+=sortString(order,allTr,position);
        else if(type==2)
            index+=sortDate(order,allTr,position);
        else
            index+=sortTime(order,allTr,position);
        if(size==index)
            return true;
        return false;
    }
    public int sortString(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        String previous="",next="";
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            next=element.getText();
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=element.getText();
                    index++;
                }
            }
            else{
                if(index==1)
                    previous=next;
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=element.getText();
                    index++;
                }
            }
        }
        return  index;
    }
    public int sortInteger(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0;
        int previous=0;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            int next=Integer.parseInt(element.getText());
            if(order==0){
                if(previous<=next){  // ascending order
                    previous=next;
                    index++;
                }
            }
            else{
                if(index==1)
                    previous=next;
                if(previous>=next){ //descending  order
                    previous=next;
                    index++;
                }
            }
        }
        return  index;
    }
    public int sortDate(int order,List<WebElement> allTr,int position) throws ParseException {
        WebElement element;
        DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        int index=0;
        Date previous=null;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            Date next;
            next=df.parse(element.getText());
            if(index==1)
                previous=next;
            if(order==0){
                if(previous.compareTo(next)<=0 ){  // ascending order
                    previous=next;
                    index++;
                }
            }
            else{
                if(previous.compareTo(next)>=0){  //descending  order
                    previous=next;
                    index++;
                }
            }
        }
        return  index;
    }
    public int sortTime(int order,List<WebElement> allTr,int position){
        WebElement element;
        int index=0,previousHours=0,previousMinutes=0,previousSeconds=0;
        for(WebElement tr:allTr){
            if(index==0) {
                index++;
                continue;
            }
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            String time[]=element.getText().split(":");
            int hours=Integer.parseInt(time[0]);
            int minutes=Integer.parseInt(time[1]);
            int seconds=Integer.parseInt(time[2]);
            if(index==1){
                previousHours=hours;
                previousMinutes=minutes;
                previousSeconds=seconds;
            }
            if(order==0){
                if(previousHours<=hours){            // ascending order
                    if(previousMinutes<=minutes){
                        if(previousSeconds<=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes<=minutes){
                    if(previousSeconds<=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds<=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
            else{
                if(previousHours>=hours){  // descending order
                    if(previousMinutes>=minutes){
                        if(previousSeconds>=seconds){
                            previousHours=hours;
                            previousMinutes=minutes;
                            previousSeconds=seconds;
                            index++;
                        }else break;
                    }else break;
                }else if(previousMinutes>=minutes){
                    if(previousSeconds>=seconds){
                        previousHours=hours;
                        previousMinutes=minutes;
                        previousSeconds=seconds;
                        index++;
                    }else break;
                }else if(previousSeconds>=seconds){
                    previousHours=hours;
                    previousMinutes=minutes;
                    previousSeconds=seconds;
                    index++;
                }else break;
            }
        }
        return  index;
    }
    public void clearContent(WebDriver driver,WebElement element){
        if(element.getAttribute("id").equals("selectCombo_bui_ct_GL_qbeAllControlsSearch_wca_userStatus_Value_Text")){
            driver.findElement(By.id("selectCombo_bui_ct_GL_qbeAllControlsSearch_wca_userStatus_Value")).click();
            element=driver.findElement(By.id("styleDropDown"));
            List<WebElement> liElements=element.findElements(By.tagName("li"));
            for(WebElement ele:liElements){
               if(ele.getAttribute("key").equals("0")){
                    ele.click();
                   break;
               }
            }


        }else if(element.getAttribute("id").equals("selectCombo_MCB_SearchWC_wca_userStatus_Text")){
            driver.findElement(By.id("selectCombo_MCB_SearchWC_wca_userStatus")).click();
            element=driver.findElement(By.id("styleDropDown"));
            List<WebElement> liElements=element.findElements(By.tagName("li"));
            for(WebElement ele:liElements){
                if(ele.getAttribute("key").equals("0")){
                    ele.click();
                    break;
                }
            }


        }
        else{
            element.clear();
        }
    }

    public void  rangeQBE(WebDriver driver,String[] inputId,String columnID,String[] value,String buttonId,String tableId,int anchorvalue) throws InterruptedException {
        WebElement element;
        List<WebElement>list;
        CommonFunctions commonFunctions=new CommonFunctions();
        setValueAndAssert2(driver,inputId[1],columnID,value[1],buttonId,tableId);
        element=driver.findElement(By.id(inputId[2]));
        assertTrue(inputId[2]+" does not exist",element.isDisplayed());
        list=element.findElements(By.tagName("option"));
        for (WebElement x :list) {
            if(x.getAttribute("value").equals("Between")){
                x.click();
                break;
            }
        }

        Thread.sleep(2000);
        list=driver.findElements(By.tagName("a"));
        list.get(anchorvalue).click();
        Thread.sleep(5000);
        WebElement elementDiv=driver.findElement(By.id(inputId[3]));
        assertTrue("No box to enter",element.isDisplayed());
        Thread.sleep(2000);
        element=driver.findElement(By.id(inputId[4]));
        assertTrue(inputId[4]+" not exist",element.isDisplayed());
        element.sendKeys(value[2]);
        element=driver.findElement(By.id(inputId[5]));
        assertTrue(inputId[5]+" not exist",element.isDisplayed());
        element.sendKeys(value[3]);
        list=elementDiv.findElements(By.tagName("a"));
        list.get(0).click();
        element=driver.findElement(By.id("srchBut_0"));
        element.click();
        element=driver.findElement(By.id("MCB_SearchWC_wca_loginID"));
    }

    public void setValueAndAssert2(WebDriver driver, String id,String columnName, String value,String buttonID,String tableId) throws InterruptedException{
        WebElement element=null;
        CommonFunctions commonFunctions = new CommonFunctions();
        List<WebElement> processingCenter = driver.findElements(By.id(id));
        for (WebElement x : processingCenter) {
            if(x.getTagName().equals("input")){
                element=x;
                x.sendKeys(value);
            }
        }
        driver.findElement(By.id(buttonID)).click();
        assertTrue("table data not match",verifySearchCondition(driver,columnName,tableId,value));
        clearContent(driver,element);
    }
    public void closePopupNew(WebDriver driver,String id){
        try{

            driver.findElement(By.className(id)).click();
            Thread.sleep(1000);
        }catch(Exception e){System.out.println("Hello popup");}
    }
    public boolean verifySearchCondition(WebDriver driver, String header,String tableId,String value) throws InterruptedException {

        int rqdHeadrIndex = 0, rqdDataIndex = 0;
        List<WebElement> allRows = readTableContent(driver, tableId, "tr");

        //DO NOT DELETE , REQUIRED TO READ TABLE HEADERS
        for (WebElement row : allRows) {
            List<WebElement> tableHeaders = row.findElements(By.tagName("th"));
            for (WebElement cell : tableHeaders) {
                if (cell.getText().equals(header)) {
                    break;
                }
                rqdHeadrIndex++;
            }
        }            // i points to position where "user name" exists
        //TO READ THE ROW DATA
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                continue;
            }
            rqdDataIndex = 0;
            for (WebElement cell : tableData) {

                if(rqdDataIndex == rqdHeadrIndex)
                {
                    if(cell.getText().equals(value))
                    {
                        rqdDataIndex++;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    public List<WebElement> readTableContent(WebDriver driver,String tableId, String tagName) throws InterruptedException {
        WebElement table = driver.findElement(By.id(tableId));
        List<WebElement> allRows = table.findElements(By.tagName(tagName));
        return allRows;
    }

    public boolean tableDataForNewRI(WebDriver driver, String tableId, String header, String value[], int option){
        WebElement element=driver.findElement(By.id(tableId));
        int position=0;
        int index=0;
        List<WebElement> allTh=element.findElement(By.tagName("thead")).findElement(By.tagName("tr")).findElements(By.tagName("th"));
        for(WebElement th:allTh){
            if(th.getAttribute("columnLabel").equals(header))
                break;
            position++;
        }
        List<WebElement> allTr=element.findElement(By.tagName("tbody")).findElements(By.tagName("tr"));
        int size=allTr.size();
        for(WebElement tr:allTr){
            List<WebElement> allTd=tr.findElements(By.tagName("td"));
            element=allTd.get(position);
            index+=compare(element,value,option);
        }
        System.out.println("size="+size+" index="+index);
        if(index==0)
            System.out.println("No data found for "+value[value.length-1]);
        if(index==size)return true;
        return false;
    }


}