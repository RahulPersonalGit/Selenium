package GL;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.Assert.fail;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 1/10/13
 * Time: 11:21 AM
 * To change this template use File | Settings | File Templates.
 */
public class QS_Test extends BrowserConfig {
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    Constants constants=new Constants();
    static CommonFunctionsForGL commonFunctionsForGL = new CommonFunctionsForGL();
    public void ExecuteTest(WebDriver driver, String browserName) throws Exception, IOException {
        startHere(driver);
        Thread.sleep(2000);
        /*commonFunctionsForGL.openPage(driver,"riGLQBE");
        Thread.sleep(2000);
        driver.switchTo().frame("panel2");
        Thread.sleep(3000);
        new QBEOpeations().testGLQBENew(driver);


        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
        commonFunctionsForGL.openPage(driver,"riSearchListQBE");
        Thread.sleep(2000);
        driver.switchTo().frame("panel3");
        Thread.sleep(2000);
        new QBEOpeations().testSearchListQBENew(driver);
*/

       // Thread.sleep(2000);
        driver.switchTo().defaultContent();
       // Thread.sleep(2000);
        commonFunctionsForGL.openPage(driver,"riGenericList");
        new GenericList().test1(driver);

        /*commonFunctionsForGL.openPage(driver, "riCustomAdvancedSearchList");
        Thread.sleep(2000);

        new tstRangeQbe().testRangeQBE(driver);*/

    }
    public void startHere(WebDriver driver) throws IOException, InterruptedException {
        driver.get(baseUrl);
        String[] loginPageData={"userId", "SYSADMIN", "password","abcd1234","entity","Login"};
        commonFunctionsForGL.testLogin(driver);
    }
    @Before
    public void setUp() throws Exception {
    }
    @Test
    public void testDemo() {
        if (SeleniumGrid.equals("Y")) {
            for (DesiredCapabilities browser : browsers) {
                driver = null;
                try {
                    driver = new RemoteWebDriver(new URL(URL), browser);
                    ExecuteTest(driver,browser.getBrowserName());
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                } finally {
                    if (driver != null) {
                        driver.quit();
                    }
                }
            }
        } else {
            driver = null;
            System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");

           // System.setProperty("webdriver.chrome.driver","D:\\softwares\\selenium\\IEDriverServer.exe");
            driver = new ChromeDriver();
           // driver= new FirefoxDriver();
//            driver= new InternetExplorerDriver();
            try {
                ExecuteTest(driver, null);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
                driver.quit();
            }
        }
    }
    @After
    public void quitDriver() {
        //System.out.println("over");
    }
    public void tearDown() throws Exception {
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }
}