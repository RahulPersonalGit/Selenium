package GL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 2/5/13
 * Time: 1:08 PM
 * To change this template use File | Settings | File Templates.
 */
public class ColumnOptions {
    CSVReader csvReader=new CSVReader();
    CommonFunctionsForGL commonFunctionsForGL =new CommonFunctionsForGL();
    String buttonIds[]=csvReader.readCSV("columnOptions","GL.csv");
    String availableOptions[]=csvReader.readCSV(buttonIds[buttonIds.length-1],"GL.csv");
    String controlButtons[]=csvReader.readCSV("controlButtons", "GL.csv");

    public void columnOptions(WebDriver driver,String moreActions[]) throws InterruptedException {
        driver.findElement(By.id("mcMoreActions")).click();

        driver.findElement(By.id("mcMoreActions")).click();
        Thread.sleep(2000);
        driver.findElement(By.id("columnOptions")).click();
        driver.findElement(By.id(buttonIds[4])).click();
        driver.findElement(By.id(buttonIds[3])).click();
        driver.findElement(By.id(buttonIds[7])).click();
        commonFunctionsForGL.closeAlert(driver);
        for(int i=1;i<2;i++){
            driver.findElement(By.id(buttonIds[i])).click();
            commonFunctionsForGL.closeAlert(driver);
        }
        driver.findElement(By.id(buttonIds[8])).click();
        selectOption(driver,buttonIds[buttonIds.length-1],availableOptions[1]);
        driver.findElement(By.id(buttonIds[3])).click();
        selectOption(driver, buttonIds[buttonIds.length - 1], availableOptions[3]);
        for(int i=5;i<8;i++){
            commonFunctionsForGL.closeAlert(driver);
            if(i==7)driver.findElement(By.id(buttonIds[i])).click();
            else for(int num=0;num<4;num++){
                driver.findElement(By.id(buttonIds[i])).click();
                commonFunctionsForGL.closeAlert(driver);
            }
        }
    }
    public void selectOption(WebDriver driver,String id,String value){
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allOptions=element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            if(option.getText().equals(value)){
                option.click();
                break;
            }
        }
    }
}
