package GL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class BillBoard {
    public void testMe(WebDriver driver) throws InterruptedException {
        int requiredScreen=5,presentScreen=0;
        String s1 = null;
        Thread.sleep(1000);
        for(int i=0;i<2;i++){
            driver.findElement(By.className("jcarousel-prev")).click();
            System.out.println(i + " is clicked prev");
        }
        for(int i=0;i<3;i++){
            driver.findElement(By.className("jcarousel-next")).click();
            System.out.println(i+" is clicked next");

        }
        Thread.sleep(2000);

        WebElement element;
        for(int j=1;j<8;j++){
            try{
                element=driver.findElement(By.xpath("/html/body/div/div[3]/div/div/div/div/div/div/div/div/div/ul/li["+j+"]/div/div/a/img"));
                if(element.isDisplayed()){
                    element.click();
                    System.out.println("position ="+j);
                    break;
                }
            }
            catch (Exception e){
                continue;
            }
        }
        System.out.println("y u clicked me");
    }
}