package mouse;

import junit.framework.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.util.List;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 4:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class Preferences {
    public void testPreferences(WebDriver driver) throws Exception{
        WebElement element;
        element=driver.findElement(By.id("preferences"));
        Assert.assertTrue("Preferences is not there", element.isDisplayed());
        element.click();

        Thread.sleep(100L);

        element=driver.findElement(By.id("userPreferences"));
        assertTrue("User Preferences is not there",element.isDisplayed());

        testAccordionTabs(driver);
        testThemeSelection(driver);
        testTblViewSize(driver);
        Thread.sleep(1000L);
        testMsgFadeOut(driver);
        //testChangePassword(driver);           //server not supporting
        //testMyWindows(driver);
        testApplKeyMap(driver);
        testWidgetGallery(driver);

        driver.findElement(By.linkText("Save")).click();
        driver.findElement(By.className("bancs-icon-close")).click();
    }
    public void testAccordionTabs(WebDriver driver){
        WebElement element;
        String tabs[]={"themeSelection","tblViewSize","msgFadeOut","changePassword","myWindows","applKeyMap","widgetGallery"};
        for(int i=0;i<7;i++){
            element=driver.findElement(By.id(tabs[i]));
            assertTrue(tabs[i]+" is not there",element.isDisplayed());
        }
    }
    public void testTblViewSize(WebDriver driver) throws Exception{
        WebElement element;
        int value;
        String s;

        driver.findElement(By.id("tblViewSize")).click();
        Thread.sleep(100L);
        element=driver.findElement(By.id("tblViewSizeContent"));
        assertTrue("tblViewSizeContent is not there", element.isDisplayed());

        element=driver.findElement(By.id("fir"));
        for(int increment=0;increment<3;increment++){
            element.click();  }
        element=driver.findElement(By.id("tblViewSizeSpinner"));
        s=element.getAttribute("value");
        value=Integer.parseInt(s);
        if(value==25)
            System.out.println("View size value is Correct");

        element=driver.findElement(By.id("fir"));
        for(int increment=0;increment<6;increment++){
            element.click();  }
        element=driver.findElement(By.id("tblViewSizeSpinner"));
        value=Integer.parseInt(element.getAttribute("value"));
        if(value==30){
            System.out.println("View size value is Correct");}

        driver.findElement(By.id("fir")).click();
        element=driver.findElement(By.id("tblViewSizeSpinner"));
        value=Integer.parseInt(element.getAttribute("value"));
        if(value==29){
            System.out.println("View size value is Correct");}

        element.sendKeys("25");
        System.out.println("The vlaue of view size changed to 25");
        element.sendKeys("99");
        System.out.println("The vlaue of view size changed to 99");

        driver.findElement(By.id("fir")).click();
        element=driver.findElement(By.id("tblViewSizeSpinner"));
        value=Integer.parseInt(element.getAttribute("value"));
        if(value==0){
            System.out.println("View size value is Correct");}

        element.sendKeys("asdf");
        System.out.println("The vlaue of view size changed to as");
        if((element.getAttribute("value")).equals("as")){
            System.out.println("The value changed is correct \n But it should display an error");}
    }

    public void testMsgFadeOut(WebDriver driver) throws InterruptedException {
        String tabs[]={"msgFadeOut","msgFadeOutYes","msgFadeOutNo"};
        for(String a:tabs){
            driver.findElement(By.id(a)).click();
        }
    }

    public void testChangePassword(WebDriver driver) throws InterruptedException {
        WebElement element;
        String changePasswords[][]={{"abcd1234","1234abcd","12345abcd"},
                                    {"abcd124","1234abcd","12345abcd"},
                                    {"abcd1234","1234abcde","1234abcde"},
                                    {"abcd1234","abcd1234","abcd1234"}};
        for(int i=0;i<3;i++){
                driver.findElement(By.id("changePassword")).click();
                driver.findElement(By.name("password0")).sendKeys(changePasswords[i][0]);
                driver.findElement(By.name("password1")).sendKeys(changePasswords[i][1]);
                driver.findElement(By.name("password2")).sendKeys(changePasswords[i][2]);
                driver.findElement(By.linkText("Save")).click();
                try{Alert alert = driver.switchTo().alert();
                alert.accept();}catch (Exception e){continue;}
        }
    }
    public void testMyWindows(WebDriver driver){
        WebElement element;
        driver.findElement(By.id("myWindows")).click();
        element=driver.findElement(By.id("myWindowsContent"));
        assertTrue("myWindowsContent is not there",element.isDisplayed());
        System.out.println("myWindowsContent is there");

        //Move Editable to Selected List
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div/ul/li")).click();
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[2]/div[2]/span")).click();
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li"));
        assertTrue("Element is not moved",element.isDisplayed());

        //Move all to selected List
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[2]/div/span")).click();
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li"));
        assertTrue("Role List Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li[2]"));
        assertTrue("User List Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li[3]"));
        assertTrue("Create User Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li[4]"));
        assertTrue("Editable Element is not moved", element.isDisplayed());

        //Swap positions
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[3]/ul/li[3]")).click();
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[4]/div[2]/span")).click();

        //Move All to Available List
        driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div[2]/div[4]/span")).click();
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div/ul/li"));
        assertTrue("Role List Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div/ul/li[2]"));
        assertTrue("User List Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div/ul/li[3]"));
        assertTrue("Create User Element is not moved",element.isDisplayed());
        element=driver.findElement(By.xpath("html/body/div[5]/div/div[6]/ul/li/div/div/ul/li[4]"));
        assertTrue("Editable Element is not moved", element.isDisplayed());
    }
    public void testApplKeyMap(WebDriver driver) throws InterruptedException {
        WebElement element;
        driver.findElement(By.xpath("html/body/div[6]/div/div[7]/h2/a")).click();
        Thread.sleep(100L);
        element=driver.findElement(By.id("appKeyMapContent"));
        assertTrue("appKeyMapContent is not there", element.isDisplayed());
    }
    public void testThemeSelection(WebDriver driver) throws InterruptedException {
        WebElement element;
        driver.findElement(By.id("themeSelection")).click();
        Thread.sleep(100L);
        element=driver.findElement(By.id("themeSelectionContent"));
        assertTrue("themeSelectionContent is not there", element.isDisplayed());
        String colors[]={"Orange","Blue"};
        String styles[]={"Italic","Normal"};
        String buttons[]={"fontStyle-button","brdColor-button"};
        String lists[]={"fontStyle-lists","brdColor-lists"};

        for(int i=0;i<2;i++){
            driver.findElement(By.id(buttons[0])).click();
            Thread.sleep(100L);
            element = driver.findElement(By.id(lists[0]));
            List<WebElement> allLiElements = element.findElements(By.tagName("li"));
            for (WebElement li : allLiElements) {
                if(li.getText().equals(styles[i])){
                    li.click();
                    break;
                }
            }
            driver.findElement(By.id(buttons[1])).click();
            Thread.sleep(100L);
            element = driver.findElement(By.id(lists[1]));
            allLiElements = element.findElements(By.tagName("li"));
            for (WebElement li : allLiElements) {
                if(li.getText().equals(colors[i])){
                    li.click();
                    break;
                }
            }
        }
  }
    public void testWidgetGallery(WebDriver driver) throws InterruptedException {
        WebElement element;
        driver.findElement(By.id("widgetGallery")).click();
        Thread.sleep(100L);
        element=driver.findElement(By.id("widgetGalleryContent"));
        assertTrue("widgetGalleryContent is not there", element.isDisplayed());
        driver.findElement(By.id("wg_select_WorkFlow")).click();
        driver.findElement(By.id("wg_select_STP_Queue")).click();
    }
}