package SeleniumGrid;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.io.IOException;
import java.util.List;

import static org.junit.Assert.assertTrue;

public class CommonFunctions extends GUIMODappTest {

    public void Login(WebDriver driver,String[] loginPageData) throws IOException {
        WebElement element;
        try {
            Thread.sleep(2000);
            element = driver.findElement(By.id(loginPageData[0]));
            assertTrue("userId is not there", element.isDisplayed());
            driver.findElement(By.id(loginPageData[0])).sendKeys(loginPageData[1]);
            driver.findElement(By.id(loginPageData[2])).sendKeys(loginPageData[3]);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[4]));
            assertTrue("entity is not there", element.isEnabled());
            Thread.sleep(2000);
            element.sendKeys(Keys.TAB);
            element = driver.findElement(By.id(loginPageData[5]));
            assertTrue("Login is not there", element.isDisplayed());
            element.sendKeys(Keys.RETURN);
            if ((driver.findElement(By.id(loginPageData[5]))).isDisplayed()) {
                element.sendKeys(Keys.TAB);
                element.sendKeys(Keys.ENTER);
            }
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void MenuNavigation(WebDriver driver, String[] ListDataFromCSV) throws InterruptedException {
        WebElement element;
        Actions builder;
        Thread.sleep(3000);
        element = driver.findElement(By.id(ListDataFromCSV[0]));
        Thread.sleep(1000);
        builder = new Actions(driver);
        builder.moveToElement(element).build().perform();
        element = driver.findElement(By.linkText(ListDataFromCSV[1]));
        Thread.sleep(1000);
        builder = new Actions(driver);
        builder.moveToElement(element).build().perform();
        element = driver.findElement(By.linkText(ListDataFromCSV[2]));
        element.click();
        Thread.sleep(1000);
    }
    public void switchFrame(WebDriver driver,String panel) throws InterruptedException {
        Thread.sleep(3000);
        driver.switchTo().frame(panel);
        Thread.sleep(2000);
    }
    public void initiateComboBox(WebDriver driver,String[] ListDataFromCSV) throws InterruptedException {
        Thread.sleep(3000);
        WebElement element;
        element = driver.findElement(By.id(ListDataFromCSV[3]));
        assertTrue(ListDataFromCSV[3]+" is not there", element.isDisplayed());
        driver.findElement(By.id(ListDataFromCSV[3])).click();
        Thread.sleep(1000);
        final Select selectBox = new Select(driver.findElement(By.id(ListDataFromCSV[3])));
        selectBox.selectByValue(ListDataFromCSV[4]);
    }
    public void searchDataEntry(WebDriver driver,String[] ListDataFromCSV) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By.id(ListDataFromCSV[5])).sendKeys(ListDataFromCSV[6]);
    }
    public void ButtonClick(WebDriver driver,String[] ListDataFromCSV) throws InterruptedException {
        Thread.sleep(1000);
        driver.findElement(By.id(ListDataFromCSV[7])).click();
    }
    public void accessTableData (WebDriver driver,String[] ListDataFromCSV)throws InterruptedException{

        // Grab the table
        WebElement table = driver.findElement(By.id(ListDataFromCSV[8]));

        // Now get all the TR elements from the table
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        // And iterate over them, getting the cells
        for (WebElement row : allRows) {
            List<WebElement> tableHeaders = row.findElements(By.tagName("th"));
            for (WebElement cell : tableHeaders) {
                //System.out.println(cell.getText());
                //System.out.println("_________________________");
            }
//            List<WebElement> cells = row.findElements(By.tagName("td"));
//            for (WebElement cell : cells) {
//                System.out.println(cell.getText());
//                System.out.println("_________________________");
//                break;
//            }
        }

    }

}