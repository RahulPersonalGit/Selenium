package mouse;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 2:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class Tiling {
    public void testTiling(WebDriver driver) throws InterruptedException {
        WebElement element;

        System.out.println("Tiling started");
        element=driver.findElement(By.className("stTile"));
        element.click();
        Thread.sleep(100L);

        element=driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/ul/li/input"));
        element.click();
        element=driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/ul[2]/li/a/span"));
        element.click();

        Alert alert = driver.switchTo().alert();
        alert.accept();

        element=driver.findElement(By.xpath("html/body/div[3]/div/div[2]/span/span"));
        element.click();
        Thread.sleep(100L);

        element=driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/ul/li[7]/input"));
        element.click();
        element=driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/ul/li[5]/input"));
        element.click();
        element=driver.findElement(By.xpath("html/body/div[3]/div[2]/form/div/ul[2]/li[2]/a/span"));
        element.click();

        System.out.println("Tiling ended");
    }
}