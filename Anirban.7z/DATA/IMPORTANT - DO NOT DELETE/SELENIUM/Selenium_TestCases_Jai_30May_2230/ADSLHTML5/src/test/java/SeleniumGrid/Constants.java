package SeleniumGrid;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 1/4/13
 * Time: 11:53 AM
 * To change this template use File | Settings | File Templates.
 */
public class Constants {
    int TENMILLISECONDS=10;
    int HUNDREDMILLISECONDS=100;
    int THOUSANDMILLISECONDS=1000;
    int THREETHOUSANDMILLISECONDS=3000;
    int FIVETHOUSANDMILLISECONDS=5000;
}

