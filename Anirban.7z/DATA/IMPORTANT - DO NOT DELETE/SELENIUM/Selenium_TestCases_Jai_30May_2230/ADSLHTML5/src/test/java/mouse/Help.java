package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 11:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class Help{
    public void testHelp(WebDriver driver) throws IOException, InterruptedException {
        Properties help=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        help.load(in);
        driver.findElement(By.id("help")).click();
        Thread.sleep(100L);
        driver.findElement(By.linkText(help.getProperty("contentHelp"))).click();
        driver.findElement(By.id("help")).click();
        Thread.sleep(10L);
        driver.findElement(By.linkText(help.getProperty("aboutBancs"))).click();
        driver.findElement(By.id(help.getProperty("closeAboutBancs"))).click();

    }
}