package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 3:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class APPHeader {
    public void testAppHeader(WebDriver driver){
        WebElement element;
        String elements[]={"client-logo","businessDate","userInfo"};

        System.out.println("APP Header");
        for(String a:elements){
            element=driver.findElement(By.id(a));
            assertTrue(a+" is not there", element.isDisplayed());
            System.out.println(a+" is there");
        }
    }
}
