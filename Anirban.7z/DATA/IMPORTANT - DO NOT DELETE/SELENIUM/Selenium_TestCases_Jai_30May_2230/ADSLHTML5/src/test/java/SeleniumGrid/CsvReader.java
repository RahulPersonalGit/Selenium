package SeleniumGrid;

import org.openqa.selenium.WebDriver;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.StringTokenizer;

public class CsvReader extends GUIMODappTest {
    CommonFunctions commonFunctions=new CommonFunctions();
    String testCaseParameteres[] = new String[9];
    private int panelNo=1,lineNumber = 0, tokenNumber = 0, i = 0;

    public void readCSV(WebDriver driver,String CSVFileName) {
        try {
            String csvFile = "D:\\2. DOCUMENTS\\WASTELAND\\src\\test\\java\\FileStore\\"+CSVFileName;

            //create BufferedReader to read csv file
            BufferedReader br = new BufferedReader(new FileReader(csvFile));
            String line = "";
            StringTokenizer st = null;

            //read comma separated file line by line
            while ((line = br.readLine()) != null) {
                lineNumber++;

                //use comma as token separator
                st = new StringTokenizer(line, ",");
                i = 0;
                while (st.hasMoreTokens()) {
                    tokenNumber++;
                    testCaseParameteres[i] = st.nextToken();
                    i++;
                }
                TestCaseExecutionSteps(driver,testCaseParameteres);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void TestCaseExecutionSteps(WebDriver driver, String[] ListDataFromCSV) throws InterruptedException {

                commonFunctions.MenuNavigation(driver,ListDataFromCSV);
                panelNo++;
                //System.out.println("Menu Navigation done");
                commonFunctions.switchFrame(driver,"panel"+panelNo);
                //System.out.println("Frame switched");
                commonFunctions.initiateComboBox(driver,ListDataFromCSV);
                //System.out.println("Combo-Box initiated");
                commonFunctions.searchDataEntry(driver, ListDataFromCSV);
                //System.out.println("Entered search data");
                commonFunctions.ButtonClick(driver,ListDataFromCSV);
               // System.out.println("Button Clicked");
                commonFunctions.accessTableData(driver,ListDataFromCSV);
                //System.out.println("#############################");
                driver.switchTo().defaultContent();
                //System.out.println();
                tokenNumber = 0;
                Thread.sleep(1000);
    }


}
