package SeleniumGrid;


import RI_newModel.ADSL_new;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

import static org.junit.Assert.fail;

public class GUIMODappTest extends BrowserConfig {
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    static CsvReader csvReader = new CsvReader();
    static CommonFunctions commonFunctions = new CommonFunctions();

    public void ExecuteTest(WebDriver driver, String browserName)  {
          try{
          driver.get(baseUrl);
          testLogin(driver);
          ADSL_new adsl_new =new ADSL_new();
          adsl_new.testUi(driver);
          }
          catch(Exception e){
              e.printStackTrace();
          }
    }
    public void testLogin(WebDriver driver) throws Exception {
        try {
            WebElement element;

            element = driver.findElement(By.name("userId"));
            element.sendKeys("test_12");
            Thread.sleep(2000);
            element = driver.findElement(By.id("password"));
            element.sendKeys("tcs1234");
            element.click();
            element.sendKeys(Keys.TAB);
            Thread.sleep(2000);
            if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) {
                driver.findElement(By.id("Login")).sendKeys(Keys.ENTER);
            } else {
                driver.findElement(By.id("Login")).click();
            }
        } catch (Exception e) {
            System.out.println("Login failure" + e);
        }
    }

    @Before
    public void setUp() throws Exception {
    }
    @Test
    public void testDemo() {
        if (SeleniumGrid.equals("Y")) {
            for (DesiredCapabilities browser : browsers) {
                driver = null;
                try {
                    System.out.println("original URL");
                    driver = new RemoteWebDriver(new URL(URL), browser);
                    ExecuteTest(driver,browser.getBrowserName());
                }  catch (Exception e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                } finally {
                    if (driver != null) {
                        driver.quit();
                    }
                }
            }
        } else {
            driver = null;
            System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
           driver = new InternetExplorerDriver();
        //  driver = new ChromeDriver();
//            driver = new FirefoxDriver();
            try {
                System.out.println("original URL from file.properties");
                ExecuteTest(driver, null);
            } catch (Exception e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            } finally {
//                driver.quit();
            }
        }
    }

    @After
    public void quitDriver() {
        System.out.println("over");
    }
    public void tearDown() throws Exception {
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }
    public boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}