package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 12:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class Logout {
    public void testLogout(WebDriver driver){
        WebElement element;

        element=driver.findElement(By.id("logout"));
        element.click();
        System.out.println("Logout clicked");

        element=driver.findElement(By.xpath("html/body/div[7]/div[2]/span/a[2]"));
        element.click();
        System.out.println("Logout Dialog closed");

        element=driver.findElement(By.id("logout"));
        element.click();
        System.out.println("Logout clicked");

        element=driver.findElement(By.xpath("html/body/div[7]/div[2]/span/a"));            // /html/body/div[7]/div[2]/span/a
        element.click();
        System.out.println("Successfully logged out");
    }
}
