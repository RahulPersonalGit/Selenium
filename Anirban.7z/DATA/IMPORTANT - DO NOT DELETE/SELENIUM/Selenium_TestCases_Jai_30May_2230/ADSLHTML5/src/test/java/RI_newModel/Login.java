package RI_newModel;

/**
 * Created with IntelliJ IDEA.
 * User: 548185
 * Date: 1/10/13
 * Time: 11:47 AM
 * To change this template use File | Settings | File Templates.
 */

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;


@RunWith(BlockJUnit4ClassRunner.class)
public class Login {
    private WebDriver driver;
    private String chromeDriverPath;

    @Before
    public void createDriver() {
        getBrowser();
    }

    private void getChrome() {
        System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
        driver = new ChromeDriver();
    }

    private void getInternetExplorer() {
        driver = new InternetExplorerDriver();
        System.out.println("in internetexplorer driver");
    }

    private void getFirefox() {
        driver = new FirefoxDriver();
    }
    @After
    public void quitDriver() {
        //driver.quit();
        System.out.println("over");
    }

    @Test
    public void testUi() throws InterruptedException,Exception {
        Properties login=new Properties();
        FileInputStream in = new FileInputStream("Home.properties");
        login.load(in);
        System.out.println("Started");
        driver.get("http://172.19.101.12:9888/Bancs/common/dologin.jsp?method=authMode&availHeight=708px&availWidth=1322px&JSLoadingMode=DEV");
        testLogin(driver, login);
        Thread.sleep(3000);
    }

    public void testLogin(WebDriver driver,Properties login) throws IOException, InterruptedException {
        WebElement element;
        element=driver.findElement(By.id("userId"));
        driver.findElement(By.name("userId")).sendKeys("upasana");
        driver.findElement(By.id("password")).sendKeys("abcd1234");
        element.sendKeys(Keys.TAB);
        element=driver.findElement(By.id("entity"));
        System.out.println("entity is enabled");
        Thread.sleep(3000);
        element.sendKeys(Keys.TAB);
        element=driver.findElement(By.id("Login"));
        System.out.println("login is there");
        element.sendKeys(Keys.RETURN);
        System.out.println("login is clicked");
    }

    private void getBrowser() {
        Properties browser = new Properties();
        try {
            FileInputStream in = new FileInputStream("Browser.properties");
            browser.load(in);
            String browser_Name = browser.getProperty("browser");
            chromeDriverPath = browser.getProperty("chromeDriver");
            Method method = Login.class.getDeclaredMethod("get"+browser_Name);
            method.invoke(this);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
