package keyBoard;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 528759
 * Date: 5/16/12
 * Time: 12:20 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(BlockJUnit4ClassRunner.class)
public class KeyBoard  {
    private WebDriver driver;
    private String chromeDriverPath;

    @Before
    public void createDriver() {
        getBrowser();
    }

    private void getChrome() {
        System.setProperty("webdriver.chrome.driver", chromeDriverPath);
        driver = new ChromeDriver();
    }

    private void getInternetExplorer() {
        driver = new InternetExplorerDriver();
        System.out.println("in internetexplorer driver");
    }


    private void getFirefox() {
        FirefoxProfile profile = new FirefoxProfile();
        profile.setEnableNativeEvents(false);
        WebDriver driver = new FirefoxDriver();
    }

    @After
    public void quitDriver() {
        /*driver.quit();*/
        System.out.println("over");
    }

    @Test
    public void testUi() throws InterruptedException,Exception {
        MenuKeys menuKeys=new MenuKeys();
        System.out.println("Started");

        driver.get("http://172.19.101.12:9888/Bancs/common/dologin.jsp?method=authMode&availHeight=708px&availWidth=1322px&JSLoadingMode=DEV");
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        testLogin(driver);

        Thread.sleep(5000L);

        menuKeys.pressKeys(driver);

    }
    public void testLogin(WebDriver driver) throws IOException {
        WebElement element;
        Properties login=new Properties();

        FileInputStream in = new FileInputStream("Home.properties");
        login.load(in);

        element=driver.findElement(By.id("userId"));
        assertTrue("userId is not there", element.isDisplayed());
        driver.findElement(By.name("userId")).sendKeys(login.getProperty("userId"));
        driver.findElement(By.id("password")).sendKeys(login.getProperty("password"));

        element.sendKeys(Keys.TAB);
        element=driver.findElement(By.id("entity"));
        assertTrue("entity is not there",element.isDisplayed());
        System.out.println("entity is enabled");
        element=driver.findElement(By.id("Login"));
        assertTrue("Login is not there",element.isDisplayed());
        System.out.println("login is there");
        System.out.println("login is clicked");
        if((driver.findElement(By.id("Login"))).isDisplayed()){
            element.sendKeys(Keys.ENTER);
            System.out.println("after login");
        }

    }

    private void getBrowser() {
        Properties browser = new Properties();
        try {
            FileInputStream in = new FileInputStream("Browser.properties");
            browser.load(in);
            String browser_Name = browser.getProperty("browser");
            chromeDriverPath = browser.getProperty("chromeDriver");
            Method method = KeyBoard.class.getDeclaredMethod("get"+browser_Name);
            method.invoke(this);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}
