package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 5:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class TabBar{
    public void testCloseTabs(WebDriver driver) throws IOException {
        Properties tabs=new Properties();
        String tab[]={"closeTab2","closeTab2","closeTab5","closeTab7"};
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        for(String a:tab){
            driver.findElement(By.xpath(tabs.getProperty(a))).click();
        }
    }
}
