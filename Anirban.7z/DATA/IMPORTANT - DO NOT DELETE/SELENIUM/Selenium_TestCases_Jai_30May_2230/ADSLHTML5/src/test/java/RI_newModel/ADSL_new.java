package RI_newModel;

/**
 * Created with IntelliJ IDEA.
 * User: 548185
 * Date: 1/10/13
 * Time: 11:47 AM
 * To change this template use File | Settings | File Templates.
 */
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.junit.Assert.assertTrue;


@RunWith(BlockJUnit4ClassRunner.class)
public class ADSL_new {
    private WebDriver driver;
    private String chromeDriverPath;

//    @Before
//    public void createDriver() {
//        getBrowser();
//    }
//
//    private void getChrome() {
//        System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
//        driver = new ChromeDriver();
//    }
//
//    private void getInternetExplorer() {
//        driver = new InternetExplorerDriver();
//        System.out.println("in internetexplorer driver");
//    }
//
//    private void getFirefox() {
//        driver = new FirefoxDriver();
//    }
//    @After
//    public void quitDriver() {
//        //driver.quit();
//        System.out.println("over");
//    }

//    @Test
    public void testUi(WebDriver driver) throws InterruptedException,Exception {
//        Login loginObj=new Login();
//        Properties login=new Properties();
        FileInputStream in = new FileInputStream("Home.properties");
//        login.load(in);
        System.out.println("Started");
//        driver.get("http://172.19.101.68:9888/Bancs/common/dologin.jsp?method=authMode&availHeight=708px&availWidth=1322px&JSLoadingMode=DEV");
//        loginObj.testLogin(driver, login);
        Thread.sleep(2000);
        openWindow(driver);
        Thread.sleep(1000);
        windowButton(driver);
        Thread.sleep(1000);
        clickSearch(driver);
        Thread.sleep(1000);
        clickSearchAllOptions(driver);
        Thread.sleep(1000);
       clickNextPrev(driver);
        Thread.sleep(1000);
            tableMenuCreate(driver);
        Thread.sleep(1000);
        tableMenuModify(driver);
        Thread.sleep(1000);
        tableMenuMoreActions(driver);
        Thread.sleep(2000);
        advanceSearch(driver);
        Thread.sleep(2000);
        openSavedSearch(driver);
        Thread.sleep(2000);
        contextMenu(driver);

    }
    public void openWindow(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        element=driver.findElement(By.id("userMenu"));
        element.sendKeys(Keys.ALT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RIGHT);
        element.sendKeys(Keys.DOWN);
        element.sendKeys(Keys.RETURN);
        System.out.println("User list is opened");
        assertTrue("ADSL_new is not opened from menu",element.isDisplayed());
    }
    public void checkStyle(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        WebElement titlebar=driver.findElement(By.className("windowLbl"));
        assertTrue("Window title is displayed",titlebar.isDisplayed());

        /* WebElement  title=titlebar.*/

    }
    public void windowButton(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        Thread.sleep(3000);
        System.out.println("Window buttons");
        driver.switchTo().frame("panel2");
        element=driver.findElement(By.id("Help10"));
        assertTrue("Help button is displayed",element.isDisplayed());
        element=driver.findElement(By.id("Close11"));
        assertTrue("Close button is displayed",element.isDisplayed());
    }
    public void clickSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
    //    driver.switchTo().frame("panel2");
        Thread.sleep(3000);
        element=driver.findElement(By.id("searchSelect-box"));
        assertTrue("select option is not displayed",element.isDisplayed());
        Thread.sleep(2000);
        element=driver.findElement(By.id("MCB_SearchWC_wca_loginId"));
        assertTrue("Text field is not displayed ",element.isDisplayed());
        element=driver.findElement(By.id("Search"));
        assertTrue("Search button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(2000);
    }
    public void clickSearchAllOptions(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;

        System.out.println("select box selected");

        element=driver.findElement(By.id("searchSelect-box"));
        assertTrue("select option is not displayed",element.isDisplayed());
        element.click();
        Thread.sleep(2000);
        assertTrue("Drop down is not displayed ",element.isDisplayed());
        System.out.println("select box opened");
        List<WebElement> allOptions= element.findElements(By.tagName("option"));
        for(WebElement option:allOptions){
            if(option.getText().equals("User Status")){
                option.click();
                break;
            }
        }
        Thread.sleep(2000);
        driver.findElement(By.id("Search")).click();
        assertTrue("Search button is not displayed ",element.isDisplayed());
        Thread.sleep(2000);
    }
    public void clickNextPrev(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        element=driver.findElement(By.id("next"));
        assertTrue("Next button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(3000);
        element=driver.findElement(By.id("prev"));
        assertTrue("Previous button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(2000);
    }
    public void tableMenuCreate(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        element=driver.findElement(By.id("openLink"));
        assertTrue("Show table level button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(1000);

        element=driver.findElement(By.id("rightButtonContainer")).findElement(By.id("Create12"));
        assertTrue("Create button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Properties tabs=new Properties();
        String tab[]={"closeTab3"};
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        for(String a:tab){
            driver.findElement(By.xpath(tabs.getProperty(a))).click();
        }
    }
    public void tableMenuModify(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        driver.switchTo().frame("panel2");
        Thread.sleep(1000);
        element=driver.findElement(By.id("rightButtonContainer")).findElement(By.id("Modify13"));
        assertTrue("Modify button is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(1000);
        driver.switchTo().defaultContent();
        Properties tabs=new Properties();
        String tab[]={"closeTab3"};
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        for(String a:tab){
            driver.findElement(By.xpath(tabs.getProperty(a))).click();
        }
    }
    public void tableMenuMoreActions(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        System.out.println("more actions");
        driver.switchTo().frame("panel2");
       element=driver.findElement(By.id("rightButtonContainer")).findElement(By.id("moreAction"));
        System.out.println("more"+element);
        assertTrue("More actions is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(1000);
      /*  element=driver.findElement(By.id("Authorise10"));
        assertTrue("Authorise button from more actions is not displayed ",element.isDisplayed());*/

        element=driver.findElement(By.id("tableMoreActionContainer")).findElement(By.id("View14"));
        assertTrue("View button from more actions is not displayed ",element.isDisplayed());
        element.click();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        Properties tabs=new Properties();
        String tab[]={"closeTab3"};
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        for(String a:tab){
            driver.findElement(By.xpath(tabs.getProperty(a))).click();
        }
    }
    public void contextMenu(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        Actions builder;
        System.out.println("CONTEXT MENU");
        WebElement elementTable=driver.findElement(By.id("bui_w_UserListADSL_Table"));
        assertTrue("ADSL_new table is not found ",elementTable.isDisplayed());
        ArrayList<WebElement> tableRow= (ArrayList<WebElement>) elementTable.findElements(By.tagName("tr"));
        for (WebElement row : tableRow) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                continue;
            }
            for (WebElement cell : tableData) {
                System.out.println("C2 "+ cell.getText());
                Thread.sleep(2000);
                break;
            }
            break;
        }
    }

    public void advanceSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        driver.switchTo().frame("panel2");
        Thread.sleep(3000);
        element=driver.findElement(By.id("advancedSearchLink"));
        assertTrue("Advance search link is not found ",element.isDisplayed());
        element.click();
        Thread.sleep(2000);
        WebElement optionTable =driver.findElement(By.id("leftSearchContainer")).findElement(By.id("searchSelect"));
        List<WebElement> allRows = optionTable.findElements(By.tagName("option"));
        for (WebElement row : allRows) {
            Actions builder = new Actions(driver);
        //    System.out.println("row" + row.getText());
         //   Thread.sleep(2000);
            Action doubleClick = builder.doubleClick(row).build();
            doubleClick.perform();
        }
    }
    public void openSavedSearch(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
       /* element=driver.findElement(By.id("advanceSearchBox")).findElement(By.id("moreActions"));
        assertTrue("Save Search combo  is not found ",element.isDisplayed());
        element.click();*/
        Thread.sleep(1000);
        element=driver.findElement(By.id("advanceSearchBox")).findElement(By.id("savedSearch"));
        element.click();
        Thread.sleep(1000);
        List<WebElement> savedSearch=driver.findElement(By.id("savedSearchOption")).findElements(By.tagName("a"));
        System.out.println(">>>>>>>>>>>>"+savedSearch.get(0));
        savedSearch.get(0).click();
        Thread.sleep(1000);
        System.out.println("search");
        driver.findElement(By.id("Search")).click();
        assertTrue("Search button is not displayed ",element.isDisplayed());
        Thread.sleep(1000);
    }
    public void closeTab(WebDriver driver, String TabName) throws InterruptedException {
        Thread.sleep(2000);
        List<WebElement> openedTabs = driver.findElements(By.id("stWidthChecker"));
        for (WebElement tabData : openedTabs) {
            List<WebElement> tabLi = tabData.findElements(By.tagName("li"));
            for (WebElement liData : tabLi) {
                if (liData.findElement(By.tagName("a")).getText().equals(TabName)) {
                    liData.findElement(By.className("bancs-tab-icon")).click();
                }
            }
        }
    }
    public void clickSelected(WebDriver driver,String id,String valueToBeClicked){
        WebElement element=driver.findElement(By.id(id));
        List<WebElement> allOptions= element.findElements(By.tagName("li"));
        for(WebElement option:allOptions){
            if(option.getText().equals(valueToBeClicked)){
                option.click();
                break;
            }
        }
    }
    private void getBrowser() {
        Properties browser = new Properties();
        try {
            FileInputStream in = new FileInputStream("Browser.properties");
            browser.load(in);
            String browser_Name = browser.getProperty("browser");
            chromeDriverPath = browser.getProperty("chromeDriver");
            Method method = ADSL_new.class.getDeclaredMethod("get"+browser_Name);
            method.invoke(this);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }
}