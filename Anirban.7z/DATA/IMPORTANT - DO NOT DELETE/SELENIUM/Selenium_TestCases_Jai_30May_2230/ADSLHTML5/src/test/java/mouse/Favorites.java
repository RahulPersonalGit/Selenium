package mouse;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 4:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class Favorites {
    public void testFavourites(WebDriver driver) throws InterruptedException, IOException {
        Properties favorites=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        favorites.load(in);
        String tabs[]={"userTab","roleTab","userGroupTab","maskProfileTab","jobSetupTab","jobMonitorTab","ruleSetTab","queueDepthTab","modifyTab"};
        for(String a:tabs) {
            driver.findElement(By.linkText(favorites.getProperty(a))).click();
            System.out.println("Tab is clicked");
            driver.findElement(By.id("favorites")).click();
            driver.findElement(By.id("favorites")).click();
            Thread.sleep(1000);
            driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
            Thread.sleep(100L);
        }
        driver.findElement(By.linkText("OK")).click();
    }
    public void testAddMore(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        favorites.load(in);
        for(int i=8;i<=9;i++){
            driver.findElement(By.xpath(favorites.getProperty("tab"+i))).click();
            driver.findElement(By.id("favorites")).click();
            System.out.println("Favourites is clicked");
            driver.findElement(By.linkText(favorites.getProperty("addToFavourites"))).click();
            Thread.sleep(100L);
        }
    }
    public void testOrganizeFavourites(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        favorites.load(in);

        Thread.sleep(100L);
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();
        driver.findElement(By.id("noneSelect")).click();
        driver.findElement(By.linkText(favorites.getProperty("cancel"))).click();

        Thread.sleep(100L);
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();
        driver.findElement(By.xpath("html/body/div[7]/ul/li[2]/li/input")).click();
        driver.findElement(By.linkText(favorites.getProperty("remove"))).click();

        Thread.sleep(100L);
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();
        driver.findElement(By.id("allSelect")).click();
        driver.findElement(By.linkText(favorites.getProperty("remove"))).click();
    }
    public void testRemoveAllFavorites(WebDriver driver) throws IOException, InterruptedException {
        Properties favorites=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        favorites.load(in);

        Thread.sleep(1000);
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText(favorites.getProperty("organizeFavourites"))).click();

        if(driver.findElement(By.id("allSelect")).isDisplayed()){
            driver.findElement(By.id("allSelect")).click();
            driver.findElement(By.linkText(favorites.getProperty("remove"))).click();
        }else{
            driver.findElement(By.linkText("OK")).click();
        }
    }
    public void testOpenAdded(WebDriver driver){
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText("Job SetUp")).click();
    }
    public void testAddHelpAndHome(WebDriver driver){
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        System.out.println("Favourites is clicked");
        driver.findElement(By.linkText("Add to Favourites")).click();
        driver.findElement(By.linkText("Home")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.id("favorites")).click();
        driver.findElement(By.linkText("Add to Favourites")).click();
        driver.findElement(By.linkText("OK")).click();
    }
}