package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 11:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class Messages{
    public void testMessages(WebDriver driver) throws IOException, InterruptedException {
        Properties messages=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        messages.load(in);
        driver.findElement(By.id(messages.getProperty("messages"))).click();
        Thread.sleep(100L);
        driver.findElement(By.xpath("html/body/div[7]/div/span[2]/a")).click();
    }
}
