package mouse;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/27/12
 * Time: 3:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class BirdsEyeView {
    public void testBirdsEyeView(WebDriver driver) throws IOException, InterruptedException {
        Properties birdsEyeView=new Properties();
        FileInputStream in= new FileInputStream("Home.properties");
        birdsEyeView.load(in);
        driver.findElement(By.className(birdsEyeView.getProperty("birdsEyeView"))).click();
        Thread.sleep(100L);
        driver.findElement(By.xpath(birdsEyeView.getProperty("view1"))).click();
    }
}