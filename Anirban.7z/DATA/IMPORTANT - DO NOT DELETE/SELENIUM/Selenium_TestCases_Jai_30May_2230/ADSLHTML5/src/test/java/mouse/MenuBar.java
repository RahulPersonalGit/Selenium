package mouse;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.assertTrue;

/**
 * Created with IntelliJ IDEA.
 * User: 558817
 * Date: 11/26/12
 * Time: 3:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class MenuBar {
    public void testMenuBar(WebDriver driver) throws InterruptedException, IOException {
        testMenu(driver);
        //testRI(driver);
        testSecurityManagement(driver);
        testJobSetupAndMonitor(driver);
        testQueueManager(driver);
        testReportsManagement(driver);
    }
    public void openClose(WebDriver driver) throws InterruptedException, IOException {
        //openCloseRI(driver);
        try{openCloseSM(driver);}catch(Exception e){e.printStackTrace();}
        try{openCloseJSM(driver);}catch(Exception e){e.printStackTrace();}
        try{openCloseAN(driver);}catch(Exception e){e.printStackTrace();}
        try{openCloseQM(driver);}catch(Exception e){e.printStackTrace();}
        try{openCloseRM(driver);}catch(Exception e){e.printStackTrace();}
    }
    public void openCloseRI(WebDriver driver) throws InterruptedException, IOException {
        Properties referenceImplementation=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        referenceImplementation.load(in);
        String tabs[]={"tabForm","treeForm","CADSL","ADSL"};
        for(int i=0;i<3;i++){
            testMouseMove(driver,"referenceImplementation");
            driver.findElement(By.linkText(referenceImplementation.getProperty(tabs[i]))).click();
            Thread.sleep(100L);
            closeTab(driver);
        }
    }
    public void openCloseSM(WebDriver driver) throws InterruptedException, IOException {
        openCloseSMCreate(driver);
        openCloseSMList(driver);
        openCloseSMMaintain(driver);
    }

    public void openCloseSMCreate(WebDriver driver) throws InterruptedException, IOException {
        Properties securityManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        securityManagement.load(in);
        String tabs[]={"user","roles","userGroup","maskProfile","dacQueryTemplate","dacAccessGrpList","userDacAccess","dacSetup","nlsProfile","functionSetup","maintainAba",
                       "securityParameter","timeZoneDetails","passwordSetup","actionGroupSetup","roleBasedErrorOverride","functionLevelSetup","userLevelSetup","MCPs"};
        for (String a:tabs){
            testMouseMove(driver,"securityManagement");
            driver.findElement(By.linkText(securityManagement.getProperty(a))).click();
            Thread.sleep(100L);
            closeTab(driver);
        }
    }
    public void openCloseSMList(WebDriver driver) throws InterruptedException, IOException {
        Properties securityManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        securityManagement.load(in);
        String tabs[]={"userList","roleList","userGroupList","actionGroupSetupList","smArchival","NLSProfileManagement","MCPsList","auditDetails","timeZone","securityParameterList",
                       "reKey","maskProfileList","archivalRetentionPeriod"};
        for(String a:tabs){
            testMouseMove(driver,"securityManagement");
            driver.findElement(By.linkText(securityManagement.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void openCloseSMMaintain(WebDriver driver) throws InterruptedException, IOException {
        Properties securityManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        securityManagement.load(in);
        testMouseMove(driver,"securityManagement");
        driver.findElement(By.linkText(securityManagement.getProperty("functionAuditSetup"))).click();
        Thread.sleep(500L);
        closeTab(driver);
    }
    public void openCloseJSM(WebDriver driver) throws InterruptedException, IOException {
        WebElement element;
        Properties jobSetupAndMonitor=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        jobSetupAndMonitor.load(in);
        String tabs[]={"quartzJobMonitor","jobSetup","jobMonitor","backgroundJobList","failedRecords","archivalMonitoring","entityCodeGroupSetup"};
        for(String a:tabs){
            testMouseMove(driver,"jobSetupAndMonitoring");
            driver.findElement(By.linkText(jobSetupAndMonitor.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void openCloseAN(WebDriver driver) throws InterruptedException, IOException {
        openCloseANCreate(driver);
        openCloseANList(driver);
    }
    public void openCloseANCreate(WebDriver driver) throws InterruptedException, IOException {
        Properties alertsAndNotifications=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        alertsAndNotifications.load(in);
        String tabs[]={"maintainNotificationAttribute","messageTemplate","maintainNotificationGroup","event","subscription"};
        for(int i=0;i<3;i++){
            testMouseMove(driver,"alertsAndNotifications");
            driver.findElement(By.linkText(alertsAndNotifications.getProperty(tabs[i]))).click();
            Thread.sleep(100L);
            closeTab(driver);
        }
    }
    public void openCloseANList(WebDriver driver) throws InterruptedException, IOException {
        Properties alertsAndNotifications=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        alertsAndNotifications.load(in);
        String tabs[]={"notificationLogs","eventLogs","notificationGroups","showNotificationRecepients","notificationRecipients"};
        for(String a:tabs){
            testMouseMove(driver,"alertsAndNotifications");
            driver.findElement(By.linkText(alertsAndNotifications.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void openCloseQM(WebDriver driver) throws InterruptedException, IOException {
        openCloseQMCreate(driver);
        openCloseQMMaintain(driver);
        openCloseQMList(driver);
    }
    public void openCloseQMCreate(WebDriver driver) throws InterruptedException, IOException {
        Properties queueManager=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        queueManager.load(in);
        String tabs[]={"ruleSet","queueDepth"};
        for(int i=0;i<2;i++){
            testMouseMove(driver,"queueManager");
            driver.findElement(By.linkText(queueManager.getProperty(tabs[i]))).click();
            Thread.sleep(100L);
            closeTab(driver);
        }
    }
    public void openCloseQMMaintain(WebDriver driver) throws InterruptedException, IOException {
        Properties queueManager=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        queueManager.load(in);

        testMouseMove(driver,"queueManager");
        driver.findElement(By.linkText(queueManager.getProperty("SLAs"))).click();
        Thread.sleep(500L);
        closeTab(driver);
    }
    public void openCloseQMList(WebDriver driver) throws InterruptedException, IOException {
        Properties queueManager=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        queueManager.load(in);
        String tabs[]={"SLAsList","ruleSets","managerWorkItem"};
        for(String a:tabs){
            testMouseMove(driver,"queueManager");
            driver.findElement(By.linkText(queueManager.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void openCloseRM(WebDriver driver) throws InterruptedException, IOException {
        openCloseRMCreate(driver);
        openCloseRMDCP(driver);
        openCloseRMList(driver);
    }
    public void openCloseRMCreate(WebDriver driver) throws InterruptedException, IOException {
        Properties reportsManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        reportsManagement.load(in);
        String tabs[]={"createDocuments","documentGroup","documentConfigurationParameters","toolsTemplates","reportAssocTemplate"};

        for(String a:tabs){
            testMouseMove(driver,"reportsManagement");
            driver.findElement(By.linkText(reportsManagement.getProperty(a))).click();
            Thread.sleep(100L);
            closeTab(driver);
        }
    }
    public void openCloseRMDCP(WebDriver driver) throws InterruptedException, IOException {
        Properties reportsManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        reportsManagement.load(in);
        String tabs[]={"modify","view"};
        for(String a:tabs){
            testMouseMove(driver,"reportsManagement");
            driver.findElement(By.linkText(reportsManagement.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void openCloseRMList(WebDriver driver) throws InterruptedException, IOException {
        Properties reportsManagement=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        reportsManagement.load(in);
        String tabs[]={"documents","documentGroups","requestedReports","generatedReports","regenerateReportSetup","toolsTemplatesList",
                "reportAssociatedTemplateList"};
        for(String a:tabs){
            testMouseMove(driver,"reportsManagement");
            driver.findElement(By.linkText(reportsManagement.getProperty(a))).click();
            Thread.sleep(500L);
            closeTab(driver);
        }
    }
    public void closeTab(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        driver.findElement(By.xpath(tabs.getProperty("closeTab8"))).click();
        Thread.sleep(500L);
    }
    public void testMenu(WebDriver driver) throws IOException {
        WebElement element;
        Properties menuBar=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        menuBar.load(in);
        String tabs[]={"menuList","userMenu","favorites","help","messages","archival","wizard","preferences","logout"};
        System.out.println("MenuBar");
        for(String a:tabs){
            element=driver.findElement(By.id(menuBar.getProperty(a)));
            assertTrue(a+" is not there", element.isDisplayed());
        }
    }

    public void testMouseMoveToUserMenu(WebDriver driver) throws IOException, InterruptedException {
        WebElement element;
        Actions builder;
        Properties menuBar=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        menuBar.load(in);

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
        element=driver.findElement(By.id(menuBar.getProperty("userMenu")));
        builder=new Actions(driver);
        builder.moveToElement(element).build().perform();
        Thread.sleep(1000);
        System.out.println("Mouse Moved is to User Menu");
    }

    public void testRI(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        String tab[]={"tabForm","treeForm"};

        for(String a:tab){
            Thread.sleep(500L);
            testMouseMove(driver,"referenceImplementation");
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
    }
    public void testMouseMove(WebDriver driver,String elementName) throws IOException, InterruptedException {
        WebElement element;
        Actions builder;
        Properties menuItem=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        menuItem.load(in);

        testMouseMoveToUserMenu(driver);
        element= driver.findElement(By.linkText(menuItem.getProperty(elementName)));
        builder=new Actions(driver);
        builder.moveToElement(element).build().perform();
        Thread.sleep(100L);
    }
    public void testSecurityManagement(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        String tab[]={"user","roles","userGroupList","maskProfileList"};
        for(String a:tab){
            Thread.sleep(500L);
            testMouseMove(driver,"securityManagement");
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
    }
    public void testJobSetupAndMonitor(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        String tab[]={"jobSetup","jobMonitor"};
        for(String a:tab){
            Thread.sleep(500L);
            testMouseMove(driver,"jobSetupAndMonitoring");
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
    }
    public void testQueueManager(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        String tab[]={"ruleSet","queueDepth"};
        for(String a:tab){
            Thread.sleep(500L);
            testMouseMove(driver,"queueManager");
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
    }
    public void testReportsManagement(WebDriver driver) throws InterruptedException, IOException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        String tab[]={"modify","view"};
        for(String a:tab){
            Thread.sleep(500L);
            testMouseMove(driver,"reportsManagement");
            driver.findElement(By.linkText(tabs.getProperty(a))).click();
        }
        Alert alert = driver.switchTo().alert();
        alert.accept();
    }
    public void testExtraRM(WebDriver driver) throws IOException, InterruptedException {
        Properties tabs=new Properties();
        FileInputStream in=new FileInputStream("Home.properties");
        tabs.load(in);
        Thread.sleep(500L);
        testMouseMove(driver,"reportsManagement");
        driver.findElement(By.linkText(tabs.getProperty("view"))).click();

        Thread.sleep(500L);
        testMouseMove(driver,"alertsAndNotifications");
        driver.findElement(By.linkText(tabs.getProperty("messageTemplate"))).click();

        Thread.sleep(500L);
        testMouseMove(driver,"alertsAndNotifications");
        driver.findElement(By.linkText(tabs.getProperty("event"))).click();

        Alert alert = driver.switchTo().alert();
        alert.accept();
    }
}