package com.tcs.retail.Demo;


import com.tcs.retail.BrowserConfig;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.MalformedURLException;
import java.net.URL;

import static org.junit.Assert.fail;

public class CuaAppTest extends BrowserConfig {
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    @Before
    public void setUp() throws Exception {
//        driver = new FirefoxDriver();
//        baseUrl = "https://172.19.101.5:8443";
//        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }


    @Test
    public void testDemo()  {
        if(SeleniumGrid.equals("Y"))
        {

            for(DesiredCapabilities browser : browsers)
            {
                driver=null;
                try {
                    driver = new RemoteWebDriver(new URL(URL),browser);
                    ExecuteTest(driver,browser.getBrowserName());

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally{
                    driver.quit();
                }
                makeZip(browser.getBrowserName());
                // makePDF();
//                deleteFiles();
            }
        }
        else
        {
            driver=null;
            driver=new FirefoxDriver();
            try {
                ExecuteTest(driver,null);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            finally {
                driver.quit();
            }
            makeZip("FireFox");
            //makePDF();
//            deleteFiles();
        }

    }

    public  void ExecuteTest(WebDriver driver,String browserName) throws InterruptedException {
        driver.get(baseUrl);

        if(browserName.equals("internet explorer")){
            driver.navigate().to("javascript:document.getElementById('overridelink').click()") ;
        }

        driver.findElement(By.id("userName")).clear();
        driver.findElement(By.id("userName")).sendKeys(username);

        EnterPassword(driver);
        takeScreenShot(driver,"Login.jpeg");
        driver.findElement(By.id("login")).click();

        Thread.sleep(9000);
        driver.findElement(By.linkText("Summary")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"Summary.jpeg");
        driver.findElement(By.linkText("Transactions")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"Transactions.jpeg");
        driver.findElement(By.linkText("eStatements")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"eStatements.jpeg");
        driver.findElement(By.linkText("Open New Account")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"OpenNewAccount.jpeg");
        driver.findElement(By.linkText("Pay Anyone")).click();

        Thread.sleep(2000);
        takeScreenShot(driver, "PayAnyone.jpeg");
        driver.findElement(By.linkText("Payee List")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"PayeeList.jpeg");
        driver.findElement(By.linkText("Scheduled Payments")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"ScheduledPayments.jpeg");
        driver.findElement(By.linkText("Pay Bill")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"PayBill.jpeg");
        driver.findElement(By.linkText("Biller List")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"BillerList.jpeg");
        driver.findElement(By.linkText("Scheduled Bills")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"ScheduledBills.jpeg");
        driver.findElement(By.linkText("BPAY View")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"BPAYView.jpeg");
        driver.findElement(By.linkText("Requests")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"Requests.jpeg");
        driver.findElement(By.linkText("Approvals")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"Approvals.jpeg");
        driver.findElement(By.linkText("Personal Details")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"PersonalDetails.jpeg");
        driver.findElement(By.linkText("Change WAC")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"ChangeWAC.jpeg");
        driver.findElement(By.linkText("Alerts")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"Alerts.jpeg");
        driver.findElement(By.linkText("Reorder Cheque Book")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"ReorderChequeBook.jpeg");
        driver.findElement(By.linkText("SMS Banking")).click();

        Thread.sleep(2000);
        takeScreenShot(driver,"SMSBanking.jpeg");


    }

    @After
    public void tearDown() throws Exception {

        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString)) {
            fail(verificationErrorString);
        }
    }

    private boolean isElementPresent(By by) {
        try {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }
}

