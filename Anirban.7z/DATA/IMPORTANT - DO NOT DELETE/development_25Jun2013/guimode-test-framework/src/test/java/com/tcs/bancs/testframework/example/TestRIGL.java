package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRIGL {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIGL.class.getName());


    @Before
    public void initSelenium() {



        navigatorUtility.driver= BrowserDriverContext.get();


    }





//    @Test

    public void doQuickSearch() {

        navigatorUtility
                .navigate("Maintain","ReferenceImplementation","RI Generic List")
                .clickOnComboBox("searchSelect-main", "User Name")
                .enterData("TextBox", "bui_ct_GL_ControlsSearch_wca_firstName", "")
                .clickOnButton("Search")
                .testTablePagination("bui_ct_GL_ControlsSearchList_Table")
                .rghtClickTblRow("bui_ct_GL_ControlsSearchList_Table",3,"View")
                .switchToTab("View")
                .clickonFormTab("but_bui_ct_addressDetailsCustom")
                .clickOnButton("Add10")
                .clickOnButton("Add10")
                .clickOnButton("Add10")
                .clickOnButton("Delete8")
                .clickOnButton("Delete8")
                .clickOnButton("Delete8")
                .closeTab("View")
                .takeScreenShot("GLQuickSearch")
                .closeTab("RI Generic List");




    }


    public void doAdvancedSearch() {
        navigatorUtility
                .navigate("Maintain","ReferenceImplementation","RI Generic List")
                .clickOnButton("advancedSearchLink")
                        //NEW SEARCH
                .dblClickSrchOption("searchSelect","User Name")
               .enterData("TextBox","bui_ct_GL_ControlsSearch_wca_firstName","u")

               .clickOnButton("addLink")
                .clickOnButton("Search")
//                .updateQuery("User Name")
//                .enterData("TextBox","bui_ct_GL_ControlsSearch_wca_firstName","tug")
//               .clickOnButton("updateLink")
//               .clickOnButton("Search")
//                .buttonMenu("moreActions", "Save as new")
//                .enterData("TextBox","newSaveName","savedSearch1")
//                .clickOnButton("ok")
//                .takeScreenShot("1AdvancedSearch")
//                .closeTab("RI Generic List")
//
//                .navigate("Maintain","ReferenceImplementation","RI Generic List")
//                .clickOnButton("advancedSearchLink")
//                 .buttonMenu("savedSearch","savedSearch1")
//
//                .clickOnButton("Search")
//                .clickOnButton("openLink")
//                .buttonMenu("moreAction","Export To Excel")
//                .enterData("TextBox","noOfPgsSle","1")
//                .clickOnButton("footerCloseBtn")
//                .takeScreenShot("2AdvancedSearch")
//
//                .clickOnButton("openLink")
//                .buttonMenu("moreAction","Column Options")
                        .executeColumnOptions("First Name")
                         .search()
//                        //UPDATE QUERY
//
               // .takeScreenShot("AdvancedSearch")
               .closeTab("RI Generic List")
        ;



        //To change body of implemented methods use File | Settings | File Templates.
    }


}
