package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRICADSL {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRICADSL.class.getName());


    @Before
    public void initSelenium() {



        navigatorUtility.driver= BrowserDriverContext.get();


    }






    public void doQuickSearch() {

        navigatorUtility
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                //.clickOnComboBox("searchSelect-main", "User Name")
               // .enterData("TextBox", "bui_ct_GL_ControlsSearch_wca_firstName", "u")
                .clickOnButton("Search")
                .takeScreenShot("CADSLQuickSearch")
                .closeTab("RI Custom Advanced Search List");




    }

//    @Test
    public void doAdvancedSearch() {
        navigatorUtility
                .navigate("Maintain","ReferenceImplementation", "RI Custom Advanced Search List")
                .clickOnButton("advancedSearchLink")
                        //NEW SEARCH
                .dblClickSrchOption("searchSelect","First Name")
               .enterData("TextBox","MCB_SearchWC_wca_firstName","Jay")

               .clickOnButton("addLink")
                .clickOnButton("Search")
//                        //UPDATE QUERY
                .updateQuery("First Name")
                .enterData("TextBox","MCB_SearchWC_wca_firstName","Sucharita")
               .clickOnButton("updateLink")
                .clickOnButton("Search")
                .takeScreenShot("CADSLAdvancedSearch")
                .closeTab("RI Custom Advanced Search List")
        ;



        //To change body of implemented methods use File | Settings | File Templates.
    }


}
