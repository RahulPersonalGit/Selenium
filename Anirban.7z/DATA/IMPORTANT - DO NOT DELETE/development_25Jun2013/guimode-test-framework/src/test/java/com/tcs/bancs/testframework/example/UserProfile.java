package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.api.Depends;
import com.tcs.bancs.testframework.api.RunIf;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 5/27/13
 * Time: 11:53 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class UserProfile {

    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(UserProfile.class.getName());
    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }


    public void  doAssertFields() {
        try {
            initSelenium();
                navigatorUtility
                    .navigate("Maintain","SecurityParameter","User")
                    .assertElement("ar_ct_UserDetail_N_wca_BusPartnerId")
                        .assertElement("ar_ct_UserDetail_N_wca_EmpID")
                        .assertElement("ar_ct_UserDetail_N_wca_FirstName")
                        .assertElement("ar_ct_UserDetail_N_wca_MiddleName")
                        .assertElement("ar_ct_UserDetail_N_wca_LastName")
                        .assertElement("ar_ct_UserDetail_N_wca_Department")
                        .assertElement("ar_ct_UserDetail_N_wca_EmailID")
                        .assertElement("ar_ct_UserAccess_N_wca_LoginId")
                        .assertElement("ar_ct_UserAccess_N_wca_Password")
                        .assertElement("ar_ct_UserAccess_N_wca_ConfirmPassword")
                        .takeScreenShot("AssertFieldsUser")
                    .closeTab("User");

                logger.log(Level.INFO, "TestCase Passed ");

        } catch (Exception e) {
            logger.log(Level.INFO, "Exception occured");
        }
    }

//    @Test
    @RunIf(browsers ={"IE"})
    @Depends(methods = {"com.tcs.bancs.testframework.example.UserProfile#doAssertFields"})
     public void  doFillFormFields() {
        try {

            Thread.sleep(2000);
            navigatorUtility
                    .navigate("Maintain","SecurityParameter","User")
                    .clickOnButton("ar_ct_UserDetail_N_wca_ManagerUser_button")
                    .switchQBE()
                    .search()
                    .dblClickTblRow("ar_w_qbe_ManageruserAB_Table",3)
                    .clickOnButton("ar_ct_UserDetail_N_wca_TimeZone_button")
                    .switchQBE()
                    .search()
                    .dblClickTblRow("ar_ct_qbe_NewtimezoneSearchList_Table",1)
                    .enterText("ar_ct_UserDetail_N_wca_BusPartnerId")
                    .enterText("ar_ct_UserDetail_N_wca_DfltProcessingCenter")
                    .enterText("ar_ct_UserDetail_N_wca_EmpID")
                    .enterText("ar_ct_UserDetail_N_wca_FirstName")
                    .enterText("ar_ct_UserDetail_N_wca_MiddleName")
                    .enterText("ar_ct_UserDetail_N_wca_LastName")
                    .enterText("ar_ct_UserDetail_N_wca_Department")
                    .enterText("ar_ct_UserDetail_N_wca_EmailID")
                    .enterText("ar_ct_UserAccess_N_wca_LoginId")
                    .enterText("ar_ct_UserAccess_N_wca_Password")
                    .enterText("ar_ct_UserAccess_N_wca_ConfirmPassword")
                    .takeScreenShot("FillFormFieldsUser")
                    .closeTab("User");


            logger.log(Level.INFO, "TestCase Passed ");

        } catch (Exception e) {
            logger.log(Level.INFO, "Exception occured");
            e.printStackTrace();
        }
    }

}
