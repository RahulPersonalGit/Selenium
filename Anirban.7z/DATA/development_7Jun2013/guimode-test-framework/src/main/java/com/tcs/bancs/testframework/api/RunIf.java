package com.tcs.bancs.testframework.api;






import com.tcs.bancs.testframework.util.BrowserDriverContext;
import org.openqa.selenium.WebDriver;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;


import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Retention(value = RUNTIME)
@Target(value = {METHOD, TYPE})
public @interface RunIf {


    String[] browsers() default {};



}
