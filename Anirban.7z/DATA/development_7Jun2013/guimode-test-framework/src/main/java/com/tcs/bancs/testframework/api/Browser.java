package com.tcs.bancs.testframework.api;

public class Browser {

    private BrowserName name;
    private String version;
    private String executablePath;

    public static class Builder {
        private BrowserName name;
        private String version;
        private String executablePath;

        public Builder(String executablePath) {
            this.executablePath = executablePath;
        }

        public Builder name(BrowserName name) {
            this.name = name;
            return this;
        }

        public Builder version(String version) {
            this.version = version;
            return this;
        }

        public Browser build() {
            return new Browser(this);
        }
    }

    private Browser(Builder builder) {
        this.name = builder.name;
        this.version = builder.version;
        this.executablePath = builder.executablePath;
    }

    public BrowserName getName() {
        return name;
    }

    public String getVersion() {
        return version;
    }

    public String getExecutablePath() {
        return executablePath;
    }
}