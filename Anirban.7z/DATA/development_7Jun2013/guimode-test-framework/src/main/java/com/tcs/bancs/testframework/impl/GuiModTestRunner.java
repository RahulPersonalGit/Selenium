package com.tcs.bancs.testframework.impl;

import com.tcs.bancs.testframework.util.NavigatorUtility;
import com.tcs.bancs.testframework.api.Depends;
import com.tcs.bancs.testframework.api.RunIf;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import org.junit.runner.notification.RunNotifier;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.InitializationError;
import org.openqa.selenium.WebDriver;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * JUnit Runner that need to execute GuiMod specific test cases
 *
 * @author Deepak Jacob
 */
public class GuiModTestRunner extends BlockJUnit4ClassRunner {

    private final static Logger logger = Logger.getLogger(GuiModTestRunner.class.getName());
    private static List<WebDriver> drivers = null;
    private  static List<Object> driversList = new LinkedList<Object>();
    private  boolean state=false;
    private static int  testCount=0;
    private  int  testCases=0;

    private static HashMap <String,String> namevaluemap = null;

    /**
     * Creates a BlockJUnit4ClassRunner to run {@code klass}
     *
     * @throws org.junit.runners.model.InitializationError
     *          if the test class name is malformed.
     */
    public GuiModTestRunner(Class<?> klass) throws InitializationError {
        super(klass);
    }

    @Override
    protected void runChild(FrameworkMethod method, RunNotifier notifier) {

          TestContextConfigurerImpl etc=new TestContextConfigurerImpl();
       testCases=Integer.parseInt(etc.getTestCases());
        if(!state){


           if(drivers!=null){
                for(WebDriver driver:drivers)
                {
                    logger.log(Level.INFO, "Closing the browsers ");
                    driver.quit();
                }
               drivers=null;
           }

          logger.log(Level.INFO, "Fetching the drivers to run the testCase"+ this.getName());

          if(etc.getSelenium().equals("N"))
            drivers=etc.getDrivers();
          else
            drivers=etc.getRemoteDrivers();

            state=true;
        }
       List list= super.computeTestMethods();


        String className[]=this.getTestClass().getName().split("\\.");
        BrowserDriverContext.setClassName(className[className.length-1]);
        BrowserDriverContext.setMethodNameName(this.testName(method));



        logger.log(Level.INFO, "Number of testcases"+list.size() );
        logger.log(Level.INFO, "Testcases Name"+BrowserDriverContext.getMethodName());
        logger.log(Level.INFO, "Class Name  "+BrowserDriverContext.getClassName());
           testCount++;



           for(WebDriver driver:drivers){

                logger.log(Level.INFO, "The configured Junit driver is " + this.getClass().getCanonicalName());
                logger.log(Level.INFO, "The method under test:  " + method.getMethod().toGenericString());
               BrowserDriverContext.set(driver);
                if(processRunIf(method.getMethod())){
                     logger.log(Level.INFO, "The method test:  " + method.getMethod().toGenericString() +"with Browser" + BrowserDriverContext.getBrowserName(BrowserDriverContext.get()));
                    BrowserDriverContext.get().get(etc.getURL());
                    NavigatorUtility.Login(BrowserDriverContext.get());
                    processDepends(method.getMethod());
                    super.runChild(method, notifier);




//                    if(driverCount==testCount()){
//                        BrowserDriverContext.get().close();
//                    }

                }

            }

        if(testCount==testCases){

            for(WebDriver driver:drivers)
            {
                logger.log(Level.INFO, "Closing the final browsers ");
                driver.quit();
            }


        }

       logger.log(Level.INFO, "Total TestCases are:  " + testCount);



    }

    private void processDepends(Method theMethodUnderTest) {
        List<String> dependencyList = new ArrayList<String>();
        logger.log(Level.INFO, "The method under test:  " + theMethodUnderTest.toGenericString());
        Depends depends = theMethodUnderTest.getAnnotation(Depends.class);
        if (depends != null) {
            String[] dependencies = depends.methods();
            for (String dependency : dependencies) {
                String[] parts = checkDependencies(dependency);
                String strClass = parts[0];
                String strMethod = parts[1];
                Class<? /*extends AbstractTest*/> aClass = instantiateDependentClass(strClass);
                executeMethodReflectively(strMethod, aClass);
            }
        }
    }

    private boolean processRunIf(Method method){

        RunIf runIf = method.getAnnotation(RunIf.class);
        WebDriver webDriver = BrowserDriverContext.get();
        String browserName = BrowserDriverContext.getBrowserName(webDriver);
        boolean status=false;
        if (runIf != null) {
            String[] browsers = runIf.browsers();
            for (String browser : browsers) {
                if(browserName.equals(browser))
                     status=true;

            }
        }
        else
        {
              status=true;
        }
        return status;
    }

    private Class<?> instantiateDependentClass(String strClass) {
        Class<?> aClass = null;
        try {
            aClass = (Class<? /*extends AbstractTest*/>) Class.forName(strClass);
        } catch (ClassNotFoundException e) {
            throw new GuiModTestException("Check whether the class " + strClass + " is present in the classpath");
        }
        return aClass;
    }

    private String[] checkDependencies(String dependency) {
        dependency = dependency.trim();
        int indexOfHash = dependency.indexOf('#');
        if (dependency.length() == 0 || indexOfHash == -1) {
            throw new GuiModTestException("Test Cases should be in the format - fully.qualified.ClassName#methodName");
        }
        String[] parts = dependency.split("#");
        if (parts.length != 2) {
            throw new GuiModTestException("Test Cases should be in the format - fully.qualified.ClassName#methodName");
        }
        return parts;
    }

    private void executeMethodReflectively(String strMethod, Class<?> aClass) {
        Method m = null;
        try {
            Object obj = aClass.newInstance();
            logger.log(Level.INFO, "Executing " + aClass.getCanonicalName() + "." + strMethod + "...");
            m = obj.getClass().getDeclaredMethod(strMethod, new Class<?>[]{});
            m.invoke(obj, null);
        } catch (InstantiationException e) {
            throw new GuiModTestException(e);
        } catch (IllegalAccessException e) {
            throw new GuiModTestException(e);
        } catch (NoSuchMethodException e) {
            throw new GuiModTestException(e);
        } catch (InvocationTargetException e) {
            throw new GuiModTestException(e);
        }
    }

}
