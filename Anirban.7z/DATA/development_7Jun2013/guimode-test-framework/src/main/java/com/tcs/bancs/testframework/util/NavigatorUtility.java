package com.tcs.bancs.testframework.util;

import com.tcs.bancs.testframework.impl.TestContextConfigurerImpl;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.Augmenter;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.thoughtworks.selenium.SeleneseTestBase.assertTrue;


public class NavigatorUtility {

    public static WebDriver driver;
    List<String> iframeidList = new ArrayList<String>();
    List<String> tabNamesList = new ArrayList<String>();
    static TestContextConfigurerImpl testContextConfigurer = new TestContextConfigurerImpl();
    boolean flag = false;

    public static void Login(WebDriver driver) {
        try {
            WebElement element;
            String username = new TestContextConfigurerImpl().getUserName();
            String password = new TestContextConfigurerImpl().getPassWord();
            Thread.sleep(2000);
            element = driver.findElement(By.name("userId"));
            element.sendKeys(username);
            Thread.sleep(2000);
            element = driver.findElement(By.id("password"));
            element.sendKeys(password);
            element.click();
            element.sendKeys(Keys.TAB);
            Thread.sleep(2000);
            if ((testContextConfigurer.getSelenium().equals("Y") && ((((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("chrome")) || ((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("firefox"))) || testContextConfigurer.getSelenium().equals("N") && ((BrowserDriverContext.getBrowserName(driver)).equals("Chrome") || (BrowserDriverContext.getBrowserName(driver)).equals("firefox")))
                driver.findElement(By.id("Login")).click();
            else
                driver.findElement(By.id("Login")).sendKeys(Keys.ENTER);

        } catch (Exception e) {
            System.out.println("Login Failure");
            e.printStackTrace();
        }
    }

    public void menuNavigation(String[] ListDataFromCSV) {
        try {
            WebElement element;
            Thread.sleep(1000);
            if (ListDataFromCSV[0].equals("Maintain")) {
                element = driver.findElement(By.id("userMenu"));
                element.sendKeys(Keys.ALT);
                Thread.sleep(1000);
                InputStream in = getClass().getClassLoader().getResourceAsStream("menuNav.properties");
                Properties p = new Properties();
                p.load(in);
                String h = ListDataFromCSV[1].replace(" ", "");
                String[] navSteps = p.getProperty(h).split(",");
                for (int i = 0; i < navSteps.length; i++) {
                    if (navSteps[i].equals("RIGHT")) element.sendKeys(Keys.RIGHT);
                    else if (navSteps[i].equals("LEFT")) element.sendKeys(Keys.LEFT);
                    else if (navSteps[i].equals("DOWN")) element.sendKeys(Keys.DOWN);
                }
                Thread.sleep(1000);
                element = driver.findElement(By.id("userMenucontain"));
                List<WebElement> x = element.findElements(By.tagName("a"));
                for (WebElement e : x) {
                    if (e.getText().equalsIgnoreCase(ListDataFromCSV[2])) {
                        e.click();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Menu navigation failure :" + ListDataFromCSV[0] + " " + ListDataFromCSV[1] + " " + ListDataFromCSV[2]);
            e.printStackTrace();

        }

    }

    public void tabHandler() {
        try {
            driver.switchTo().defaultContent();
            iframeidList.clear();
            tabNamesList.clear();
            WebElement iframeContainer = driver.findElement(By.id("tabpanelPositionHelper"));
            List<WebElement> divList = iframeContainer.findElements(By.tagName("div"));
            for (WebElement x : divList) {
                String h = x.getAttribute("id");
                String panelNo = x.findElement(By.tagName("iframe")).getAttribute("id");
                iframeidList.add(panelNo);
                List<WebElement> m = driver.findElement(By.id("stWidthChecker")).findElements(By.tagName("a"));
                for (WebElement n : m) {
                    if (n.getAttribute("href").contains(h)) {
                        tabNamesList.add(n.getText());
                    }
                }
            }
        } catch (Exception e) {

        }
    }

    public NavigatorUtility switchToTab(String tabName) {
        try {
            int i = 0;
            driver.switchTo().defaultContent();
            WebElement element = driver.findElement(By.id("stWidthChecker"));
            List<WebElement> tabs = element.findElements(By.tagName("a"));
            for (WebElement tab : tabs) {
                if (tab.getText().equals(tabName)) {
                    tab.click();
                    break;
                }
                i++;
            }
            switchFrame(iframeidList.get(i));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public void switchFrame(String panel) {
        driver.switchTo().frame(panel);
    }

    public void inputText(String[] ListDataFromCSV) {
        WebElement element = driver.findElement(By.id(ListDataFromCSV[0]));
        element.click();
        element.sendKeys(Keys.chord(Keys.CONTROL, "a"));
        element.sendKeys(Keys.DELETE);
        element.sendKeys(ListDataFromCSV[1]);
    }

    public NavigatorUtility openCalender(String calenderButtonId, String dateValue){
        calender(calenderButtonId,dateValue) ;
        return this;
    }

    public void calender(String calenderButtonId, String dateValue) {
        try {
            WebElement h = driver.findElement(By.id(calenderButtonId));
            h.click();
            h = driver.findElement(By.className("bancs-datepicker-container"));
            String[] date = dateValue.split("/");
            WebElement element = h.findElement(By.className("bancs-datepicker-selectMonth"));
            element.click();
            List<WebElement> list = element.findElements(By.tagName("option"));
            int monthNumber = Integer.parseInt(date[1]) - 1;
            for (WebElement option : list) {
                if (option.getAttribute("data-month").contains("" + monthNumber)) {
                    option.click();
                    break;
                }
            }
            element = driver.findElement(By.className("bancs-datepicker-selectYear"));
            element.click();
            list = element.findElements(By.tagName("option"));
            for (WebElement option : list) {
                if (option.getText().equals(date[2])) {
                    option.click();
                    break;
                }
            }
            driver.findElement(By.id("day" + Integer.parseInt(date[0]))).click();
        } catch (Exception e) {

        }
    }

    public void initiateDecoratedComboBox(String comboBoxId, String value) {
        Actions builder = new Actions(driver);
        WebElement element;
        String comboBoxName = comboBoxId.replace("-main", "");
        clickOnButtonDirect(comboBoxName + "-button");
        element = driver.findElement(By.id(comboBoxName + "-div"));
        List<WebElement> allLiElements = element.findElements(By.tagName("li"));
        for (WebElement li : allLiElements) {
            if (li.getText().equals(value) && li.findElements(By.tagName("a")).size() == 0) {
                builder.moveToElement(li).click().build().perform();
                break;
            }
            if (li.getText().equals(value) && li.findElements(By.tagName("a")).size() != 0) {
                builder.moveToElement(li.findElement(By.tagName("a"))).click().build().perform();
                break;

            }
        }
    }

    public void checkCondition(String msg, Boolean value) {
        try {
            assertTrue(msg, value);
        } catch (AssertionError e) {
            System.out.println(msg);
        }
    }

    public void doubleClick(WebElement element) {
        element.click();
        try {
//            JavascriptExecutor localdriver= (JavascriptExecutor) driver;
//            Thread.sleep(1000);
//            localdriver.executeScript("var evt = document.createEvent('MouseEvents');" +
//                    "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);" +
//                    "arguments[0].dispatchEvent(evt);", element);

            //driver.switchTo().defaultContent();

            ((JavascriptExecutor) driver).executeScript("var evt = document.createEvent('MouseEvents');" +
                    "evt.initMouseEvent('dblclick',true,true,window,0,0,0,0,0,false,false,false,false,0,null);" +
                    "arguments[0].dispatchEvent(evt);", element);

        } catch (Exception e) {

        }

    }

    public void doubleClickIE(WebElement element) {
        element.click();
        ((JavascriptExecutor) driver).executeScript("arguments[0].fireEvent('ondblclick');", element);
    }

    public List<WebElement> ReadTableContent(String tableId) {
        try {
            WebElement table = driver.findElement(By.id(tableId));
            List<WebElement> allRows = table.findElements(By.tagName("tr"));
            return allRows;
        } catch (Exception e) {
            System.out.println("Table Read Failure" + tableId);
            e.printStackTrace();
            return null;
        }
    }

    public NavigatorUtility clickOnComboBox(String comboBoxId, String value) {
        initiateDecoratedComboBox(comboBoxId, value);
        return this;
    }

    public NavigatorUtility clickOnButton(String buttonID) {
        try {
            clickOnButtonDirect(buttonID);
        } catch (Exception e) {
            System.out.println("Could not find the button with id " + buttonID);
        }
        return this;
    }

    public void clickOnButtonDirect(String buttonID) {
        try {
            Thread.sleep(1000);
            driver.findElement(By.id(buttonID)).click();
            Thread.sleep(1000);
            alerts();
        } catch (Exception e) {
            System.out.println("Could not find the button with id " + buttonID);
        }
    }

    public NavigatorUtility enterData(String pattern, String fieldId, String value) {
        try {
            if (pattern.equals("TextBox") || pattern.equals("Email")) {
                String[] inputTextDetails = {fieldId, value};
                inputText(inputTextDetails);
            }
            if (pattern.equals("Select")) {
                //   String[] dropDownDetails = {fieldId, value};
                initiateDecoratedComboBox(fieldId, value);
            }
            if (pattern.equals("QBE")) {

            }
            if (pattern.equals("Calender")) {
                calender(fieldId, value);
            }
            Thread.sleep(2000);
        } catch (Exception e) {

        }
        return this;
    }

    public NavigatorUtility assertElement(String assertElement) {
        WebElement element;
        try {
            Thread.sleep(2000);
            element = driver.findElement(By.id(assertElement));
            checkCondition(assertElement + " does not exist", element.isDisplayed());
        } catch (Exception e) {
        }

        return this;
    }

    public NavigatorUtility closeTab(String TabName) {
        try {
            if (TabName != null) {
                driver.switchTo().defaultContent();
                WebElement element = driver.findElement(By.id("stWidthChecker"));
                List<WebElement> tabLi = element.findElements(By.tagName("li"));
                for (WebElement liData : tabLi) {
                    if (liData.findElement(By.tagName("a")).getText().equals(TabName)) {
                        liData.findElement(By.className("bancs-tab-icon")).click();
                        break;
                    }
                }
                tabHandler();
                switchToTab(tabNamesList.get(tabNamesList.size() - 1));
                Thread.sleep(2000);
            }
        } catch (Exception e) {
        }
        return this;
    }

    public NavigatorUtility switchQBE() {

        WebElement element = driver.findElement(By.className("bancs-dialog")).findElement(By.tagName("iframe"));
        driver.switchTo().frame(element).findElement(By.tagName("body"));

        return this;
    }

    public NavigatorUtility dblClickTblRow(String tablename, int rownum) {
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            //To change body of catch statement use File | Settings | File Templates.
        }
        int rowCounter = 0;
        List<WebElement> allRows = ReadTableContent(tablename);
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                //TODO either an alert should come or a msg shld be thrown to indicate an error
                continue;
            }
            rowCounter++;
            if (rowCounter == rownum) {
                //    doubleClickIE(tableData.get(0));
                if ((testContextConfigurer.getSelenium().equals("Y") && ((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) || testContextConfigurer.getSelenium().equals("N") && (BrowserDriverContext.getBrowserName(driver)).equals("IE"))
                    doubleClickIE(tableData.get(0));
                else
                    doubleClick(tableData.get(0));
                break;
            }
        }

        tabHandler();
        switchToTab(tabNamesList.get(tabNamesList.size() - 1));

        return this;
    }

    public NavigatorUtility navigate(String MenuItem, String SubMenuOption, String tabName) {
        try {
            Thread.sleep(3000);
            driver.switchTo().defaultContent();
            String[] menuData = {MenuItem, SubMenuOption, tabName};
            menuNavigation(menuData);
            try {
                driver.switchTo().alert().accept();
                return this;
            } catch (Exception e) {
                System.out.println("No alerts are present");
            }
            tabHandler();
            String nameOfLastTab = tabNamesList.get(tabNamesList.size() - 1);
            String[] splitName = nameOfLastTab.split("\\(");
            if (splitName[0].equals(tabName)) {
                tabName = nameOfLastTab;
            }
            switchToTab(tabName);
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Error in Menu navigation " + MenuItem + " " + SubMenuOption + " " + tabName);
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility dblClickSrchOption(String id, String option) {
        String dblClkDetails = id;
        String y = option;
        WebElement element = driver.findElement(By.id(dblClkDetails));
        List<WebElement> allRows = element.findElements(By.tagName("option"));
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            //To change body of catch statement use File | Settings | File Templates.
        }
        for (WebElement reqdOption : allRows) {
            String h = reqdOption.getText();
            if (h.contains(y)) {
                if ((testContextConfigurer.getSelenium().equals("Y") && ((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet")) || testContextConfigurer.getSelenium().equals("N") && (BrowserDriverContext.getBrowserName(driver)).equals("IE"))
                    doubleClickIE(reqdOption);
//                    if (BrowserDriverContext.getBrowserName(driver).equals("IE"))
//                    doubleClickIE(reqdOption);
                else
                    doubleClick(reqdOption);
                break;
            }
        }
        return this;
    }

    public NavigatorUtility updateQuery(String queryText) {
        try {
            Thread.sleep(1000);
            WebElement queryContainer = driver.findElement(By.id("query1"));
            List<WebElement> queries = queryContainer.findElements(By.id("queryLabel"));
            for (WebElement x : queries) {
                if (x.getText().contains(queryText)) {
                    x.click();
                    break;
                }
            }
        } catch (Exception e) {
        }
        return this;
    }

    public NavigatorUtility tableSorting(String tableID, String columnName, String patternName, String sortingType) {
        try {
            WebElement table = driver.findElement(By.id(tableID));
            //clicking on the header cell to start ASCENDING SORT
            List<WebElement> tableHeadersList = table.findElements(By.tagName("th"));
            int rqdHeaderPosition = 0, temp = 0, headerNotFoundFlag = 0;

            for (WebElement x : tableHeadersList) {
                if (x.getText().length() > 0 && x.getText().contains(columnName)) {
                    headerNotFoundFlag++;
                    try {
                        if (sortingType.contains("A")) x.click();
                    } catch (Exception e) {
                        System.out.println("Error clicking on header " + columnName);
                        e.printStackTrace();
                    }
                    rqdHeaderPosition = temp;
                    break;
                }
                temp++;
            }

            if (sortingType.contains("D")) {
                try {
                    table = driver.findElement(By.id(tableID));
                    //clicking on the header cell to start ASCENDING SORT
                    tableHeadersList = table.findElements(By.tagName("th"));
                    rqdHeaderPosition = 0;
                    temp = 0;
                    headerNotFoundFlag = 0;
                    for (WebElement x : tableHeadersList) {
                        if (x.getText().length() > 0 && x.getText().contains(columnName)) {
                            headerNotFoundFlag++;
                            try {
                                if (sortingType.contains("A")) x.click();
                            } catch (Exception e) {
                                System.out.println("Error clicking on header" + columnName);
                                e.printStackTrace();
                            }
                            rqdHeaderPosition = temp;
                            break;
                        }
                        temp++;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            if (headerNotFoundFlag == 0) {
                System.out.println("Required Column is not present in the Table to initiate sorting");
                return this;
            }
            do {
                WebElement paginationInfo = driver.findElement(By.className("pagination"));
                WebElement next = driver.findElement(By.id("next"));
                String[] pageNoData = paginationInfo.findElement(By.tagName("span")).getText().split(" ");
                int currentPgNo = Integer.parseInt(pageNoData[1]);
                int TotalPgNo = Integer.parseInt(pageNoData[3]);

                List<WebElement> allRows = ReadTableContent(tableID);
                String string1 = "", string2 = "";
                int sortingFlag = 0;

                //TO READ THE ROW DATA
                for (WebElement row : allRows) {
                    List<WebElement> tableData = row.findElements(By.tagName("td"));
                    if (tableData.size() == 0)
                        continue;
                    string2 = tableData.get(rqdHeaderPosition).getText();

                    int comparsionResult = 0;
                    if (patternName.contains("string"))
                        comparsionResult = compareStrings(string1, string2);
                    if (patternName.contains("date"))
                        comparsionResult = compareDate(string1, string2);
                    if (patternName.contains("time"))
                        comparsionResult = compareTime(string1, string2);
                    if (patternName.contains("salary"))
                        comparsionResult = compareSalary(string1, string2);

                    try {
                        if (sortingType.contains("A")) {
                            checkCondition(string1 + " is greater than " + string2 + "----------ERROR", comparsionResult <= 0);
                        }
                        if (sortingType.contains("D"))
                            checkCondition(string1 + " is lesser than " + string2 + "----------ERROR", comparsionResult >= 0);
                        string1 = string2;
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (currentPgNo == TotalPgNo) break;
                next.click();
            } while (true);
        } catch (Exception e) {
            System.out.println("Error in Table Sorting " + tableID + " " + columnName + " " + patternName + " " + sortingType);
        }
        return this;
    }

    public NavigatorUtility executeColumnOptions(String columnelement) {
        //need to read n store the table header sequence
        String[] tableHeaderSequence = null;
        try {
            List<WebElement> tableHeaders = driver.findElement(By.tagName("table")).findElements(By.tagName("th"));
            tableHeaderSequence = new String[tableHeaders.size()];
            int i = 0;
            for (WebElement x : tableHeaders) {
                tableHeaderSequence[i] = x.getText();
                i++;
            }
        } catch (Exception e) {
            System.out.println("Table Header content read error ");
            e.printStackTrace();
        }

        try {
            clickOnButtonDirect("openLink");
            buttonMenuDirect("moreAction", "Column Options");
        } catch (Exception e) {
            System.out.println("Error in table buttons");
        }
        try {

            WebElement dialogue = driver.findElement(By.className("bancs-dialog"));
            WebElement multiSelect = driver.findElement(By.className("bancs-multiselect"));

            WebElement availableList = multiSelect.findElement(By.className("available"));
            WebElement selectedList = multiSelect.findElement(By.className("selected"));
            WebElement operationButtons = multiSelect.findElement(By.className("operation"));
            WebElement scrollButtons = multiSelect.findElement(By.className("scrollCountrol"));

            List<WebElement> availableListElements = availableList.findElements(By.tagName("li"));
            List<WebElement> selectedListElements = selectedList.findElements(By.tagName("li"));
            List<WebElement> operationButtonsList = operationButtons.findElements(By.tagName("span"));
            List<WebElement> scrollButtonsList = scrollButtons.findElements(By.tagName("span"));

            //Checking button status
            for (WebElement button : operationButtonsList) {
                String className = button.getAttribute("class");
                try {
                    if (availableListElements.size() == 0 && (className.contains("addButton") || className.contains("addAll")))
                        checkCondition("Add/AddAll button is not disabled", className.contains("disabled"));
                    if (availableListElements.size() == 0 && (className.contains("removeButton") || className.contains("removeAll")))
                        checkCondition("remove/RemoveAll button is not disabled", !className.contains("disabled"));
                    else if (selectedListElements.size() != 0 && availableListElements.size() != 0)
                        checkCondition("All button are disabled", !className.contains("disabled"));
                } catch (Exception e) {
                    System.out.println("Error");
                }
            }
            for (WebElement button : scrollButtonsList) {
                String className = button.getAttribute("class");
                try {
                    if (availableListElements.size() == 0)
                        checkCondition("Scroll button are not enabled", !className.contains("disabled"));
                    if (selectedListElements.size() == 0)
                        checkCondition("Scroll button are not disabled", className.contains("disabled"));
                } catch (Exception e) {
                    System.out.println("Error");
                }
            }

            //compare the selected column sequence with existing table header sequence
            for (int k = 0; k < selectedListElements.size(); k++) {
                try {
                    if (!tableHeaderSequence[k].equals("") && !tableHeaderSequence[k].contains(selectedListElements.get(k).getText())) {
                        System.out.println("FAILURE IN COLUMN OPTIONS .CURRENT PATTERN IS NOT REFLECTED IN TERMS OF SEQUENCE");
                        break;
                    }
                } catch (Exception e) {
                    System.out.println("Error in column sequence comparision");
                }
            }

            //reordering of columns
            int flag = 0;
//            for (WebElement x : selectedListElements) {
//                if (x.getText().contains("First Name")) {
//                    x.click();
//                    flag = 1;
//                    break;
//                }
//            }
//            if (flag == 1) {
//                scrollButtonsList.get(0).click();
//                scrollButtonsList.get(0).click();
//                scrollButtonsList.get(0).click();
//            } else {
//                //System.out.println("Required column name does not exist in the selected columns list for 1");
//            }
//            Thread.sleep(1000);


            //replacing of columns
            flag = 0;
            for (WebElement x : selectedListElements) {
                if (x.getText().contains(columnelement)) {
                    x.click();
                    flag = 1;
                    break;
                }
            }
            if (flag == 1) {
                operationButtonsList.get(1).click();
            } else {
                System.out.println("Required column name does not exist in the selected columns list for 2");
            }
            Thread.sleep(1000);
        } catch (Exception e) {
            System.out.println("Column Option operation failure .");
            e.printStackTrace();
        }
        try {
            handleDialogsDirect("Save");
//            //saving the changes . Clciking on save closes the dialogue
//            WebElement footer = driver.findElement(By.className("bancs-dialog-footer"));
//            List<WebElement> footerOptions = footer.findElements(By.tagName("a"));
//            for (WebElement option : footerOptions) {
//                if (option.getText().contains("Save")) {
//                    option.click();
//                    break;
//                }
//            }
//            Thread.sleep(2000);
////            //closing the dialogue
////            //System.out.println("Dialogue being closed");
////            footer.findElement(By.id("footerCloseBtn")).click();
        } catch (Exception e) {
            System.out.println("Save/Close operation failure");
        }
        return this;
    }

    public void buttonMenuDirect(String buttonId, String value) {
        try {
            Thread.sleep(2000);
            WebElement button = driver.findElement(By.id(buttonId));
//            button.findElement(By.tagName("a")).click();
            button.findElement(By.tagName("a")).sendKeys(Keys.SPACE);

            Thread.sleep(2000);
            List<WebElement> dropDownList = button.findElement(By.tagName("ul")).findElements(By.tagName("a"));
            int i = 0;
            for (WebElement x : dropDownList) {
                i++;
                if (x.getText().contains(value)) {
                    for (int j = 0; j <= i; j++)
                        x.sendKeys(Keys.DOWN);
                        x.click();
//                    x.sendKeys(Keys.SPACE);
                    break;
                }
            }

            Thread.sleep(3000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public NavigatorUtility buttonMenu(String buttonId, String value) {
        try {
            buttonMenuDirect(buttonId, value);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }

    public int compareDate(String string1, String string2) {
        if (string1.length() == 0 || string2.length() == 0) return 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date1 = sdf.parse(string1);
            Date date2 = sdf.parse(string2);
            int comparsionResult = date1.compareTo(date2);
            return comparsionResult;
        } catch (Exception e) {
            System.out.println("Error in compareDate " + string1 + " " + string2);
            e.printStackTrace();
            return 0;
        }
    }

    public int compareTime(String string1, String string2) {
        if (string1.length() == 0 || string2.length() == 0) return 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:MM:SS");
            Date time1 = sdf.parse(string1);
            Date time2 = sdf.parse(string2);
            int comparsionResult = time1.compareTo(time2);
            return comparsionResult;
        } catch (Exception e) {
            System.out.println("Error in compareTime " + string1 + " " + string2);
            e.printStackTrace();
            return 0;
        }
    }

    public int compareSalary(String string1, String string2) {
        if (string1.length() == 0 || string2.length() == 0) return 0;
        try {
            if (string1.contains(",")) string1 = string1.replaceAll(",", "");
            if (string2.contains(",")) string2 = string2.replaceAll(",", "");
            float salary1 = Float.parseFloat(string1);
            float salary2 = Float.parseFloat(string2);
            int j = salary1 <= salary2 ? 0 : 1;
            return j;
        } catch (Exception e) {
            System.out.println("Error in compareSalary " + string1 + " " + string2);
            e.printStackTrace();
            return 1;
        }
    }

    public NavigatorUtility takeScreenShot(String FileName) {
        File scrFile;
        WebDriver augmentedDriver;
        try {
            if (testContextConfigurer.getSelenium().equals("Y")) {
                augmentedDriver = new Augmenter().augment(driver);
            } else {
                augmentedDriver = driver;
            }
            scrFile = ((TakesScreenshot) augmentedDriver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(scrFile, new File("ScreenShots" + "/" + FileName + "-" + BrowserDriverContext.getBrowserName(BrowserDriverContext.get()) + ".jpg"));
        } catch (Exception e) {
        }
        return this;
    }

    public NavigatorUtility rghtClickTblRow(String tableId, int rowNumber, String contextMenuValue) {
        WebElement element;
        int rowCounter = 0;
        List<WebElement> allRows = ReadTableContent(tableId);
        //List<WebElement> tableHeaders = driver.findElement(By.tagName("table")).findElements(By.tagName("td"));
        for (WebElement row : allRows) {
            List<WebElement> tableData = row.findElements(By.tagName("td"));
            if (tableData.size() == 0) {
                //TODO either an alert should come or a msg shld be thrown to indicate an error
                continue;
            }
            rowCounter++;
            if (rowCounter == rowNumber) {
                if (((RemoteWebDriver) driver).getCapabilities().getBrowserName().contains("internet"))
                    rightClickIE(tableData.get(1));
                else
                    rightClick(tableData.get(1));
                break;
            }
        }
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            //To change body of catch statement use File | Settings | File Templates.
        }
        contextMenu("contextContainer", contextMenuValue);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            //To change body of catch statement use File | Settings | File Templates.
        }
        tabHandler();
        switchToTab(tabNamesList.get(tabNamesList.size() - 1));
        verifyWindowLoadError();
        return this;
    }

    public void rightClickIE(WebElement element) {
        element.sendKeys(Keys.chord(Keys.SHIFT, Keys.F10));
    }

    public void rightClick(WebElement element) {
        Actions builder = new Actions(driver);
        Action rClick = builder.contextClick(element).build();
        rClick.perform();
    }

    public void contextMenu(String contextMenuId, String value) {
        WebElement element;
        element = driver.findElement(By.id(contextMenuId));
        List<WebElement> optionsList = element.findElements(By.tagName("input"));
        for (WebElement option : optionsList) {
            if (option.getAttribute("value").contains(value)) {
                option.click();
                break;
            }
        }
    }

    public void verifyWindowLoadError() {
        List<WebElement> errorDiv = driver.findElements(By.className("error_messages"));
        List<WebElement> tdList = driver.findElements(By.className("error_table_col_critical_error"));
        try {
            checkCondition("PAGE LOAD ERROR", errorDiv.size() == 0);
            if (tdList.size() != 0) {
                for (WebElement td : tdList)
                    System.out.println(td.getText());
            }
        } catch (Exception e) {
        }
    }

    public NavigatorUtility testTablePagination(String tableId) {
        //TODO : this pagination only checks for NEXT button , need to develope one for PREV button
        String buttonBeingTested = "next";

        String rowData1 = "", rowData2 = "";
        do {
            //this block needs to be made a function so as to be called or updated after every click
            WebElement tableActionsContainer = driver.findElement(By.id("tableActionsContainer"));
            WebElement paginationInfo = tableActionsContainer.findElement(By.className("pagination"));
            WebElement confViewSizeBox = tableActionsContainer.findElement(By.id("confViewSizeBox"));
            WebElement prev = tableActionsContainer.findElement(By.id("prev"));
            WebElement next = tableActionsContainer.findElement(By.id("next"));

            String[] pageNoData = paginationInfo.findElement(By.tagName("span")).getText().split(" ");
            int currentPgNo = Integer.parseInt(pageNoData[1]);
            int TotalPgNo = Integer.parseInt(pageNoData[3]);
            int confViewSizeBoxValue = Integer.parseInt(confViewSizeBox.getAttribute("value"));
            String prevState = prev.getAttribute("class");
            String nextState = next.getAttribute("class");

            int noOfDataRows = ReadTableContent(tableId).size() - 1;

            try {
                if (TotalPgNo == 1) {
                    checkCondition("TEST CASE FAILED: TEST1 . Reason -> noOfDataRows GREATER THAN confViewSizeBox"
                            , noOfDataRows <= confViewSizeBoxValue);
                    checkCondition("TEST CASE FAILED: TEST1 . Reason -> Prev or Next buttons are enabled"
                            , prevState.contains("disabled") && nextState.contains("disabled"));
                    break;
                } else {
                    if (currentPgNo < TotalPgNo && currentPgNo > 1)
                        checkCondition("TEST CASE FAILED: TEST1 . Reason -> Next/Prev button is disabled"
                                , !nextState.contains("disabled") && !prevState.contains("disabled"));
                    if (currentPgNo == 1)
                        checkCondition("TEST CASE FAILED: TEST1 . Reason -> Prev button is not disabled for page 1"
                                , prevState.contains("disabled"));
                    if (currentPgNo == TotalPgNo)
                        checkCondition("TEST CASE FAILED: TEST1 . Reason -> Next button is not disabled for Last Page"
                                , nextState.contains("disabled"));
                    if (currentPgNo < TotalPgNo)
                        checkCondition("TEST CASE FAILED: TEST1 . Reason -> noOfDataRows NOT EQUAL TO confViewSizeBox"
                                , noOfDataRows == confViewSizeBoxValue);

                    List<WebElement> rowData = ReadTableContent(tableId);
                    int i = 0;
                    for (WebElement row : rowData) {
                        List<WebElement> tableData = row.findElements(By.tagName("td"));
                        for (WebElement cell : tableData)
                            rowData2 = rowData2 + cell.getText();
                        if (i == 1) break;
                        rowData2 = "";
                        i++;
                    }
                    if (!rowData1.equals("")) {
                        checkCondition("Table Pagination is not working . First row data did not change"
                                , !rowData1.equals(rowData2));
                    }
                    rowData1 = rowData2;
                    rowData2 = "";
                }
            } catch (Exception e) {
                e.printStackTrace();
                break;
            }
            if (currentPgNo == Integer.parseInt(pageNoData[3])) {
                buttonBeingTested = "prev";
            }
            if (currentPgNo == 1 && buttonBeingTested.equals("prev")) {
                break;
            }
            tableActionsContainer.findElement(By.id(buttonBeingTested)).click();
        } while (true);
        return this;
    }

    public NavigatorUtility checkMandatory(String Id) {
        WebElement element = driver.findElement(By.id(Id));
        if (!element.getAttribute("class").contains("mandattrdtls"))
            throw new AssertionError();
        else
            return this;
    }

    public NavigatorUtility checkFieldMaxSize(String Id, int size) {
        WebElement element = driver.findElement(By.id(Id));
        if ((Integer.parseInt(element.getAttribute("maxlength")) != size))
            throw new AssertionError();
        else
            return this;
    }

    public NavigatorUtility checkNumeric(String Id) {
        try {
            WebElement element = driver.findElement(By.id(Id));
            this.enterData("TextBox", Id, "abcd");
            element.click();
            element.sendKeys(Keys.TAB);

        } catch (Exception e) {

        } finally {
            driver.switchTo().alert().accept();
        }
        return this;
    }

    public NavigatorUtility clickonFormTab(String Id) {
        WebElement element = driver.findElement(By.id(Id));
        element.click();
        return this;
    }


    //13/6/2013 added for ADSL
    public NavigatorUtility tableActionsContainer(String buttonId) {
        try {
            if (buttonId.contains("Create")) {
                driver.findElement(By.id("tableActionsContainer")).findElement(By.id(buttonId)).click();
                alerts();
            }
            if (buttonId.contains("Modify")) {
                driver.findElement(By.id("tableActionsContainer")).findElement(By.id(buttonId)).click();
                alerts();
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error in tableActionsContainer " + buttonId);
            e.printStackTrace();
        }
        return this;
    }

    public void alerts() {
        try {
            driver.switchTo().alert().accept();
            Thread.sleep(2000);
        } catch (Exception e) {
        }
    }

    public NavigatorUtility handleAlerts(String... passConditionMsg) {
        try {
            Alert alertElement = driver.switchTo().alert();
            if (!alertElement.getText().contains(passConditionMsg[0])) {
                alertElement.accept();
                return null;
            }
            alertElement.accept();
            Thread.sleep(3000);
        } catch (Exception e) {
        }
        return this;
    }

    public void handleDialogsDirect(String... buttonToBeClicked) {
        try {
            if (buttonToBeClicked[0].contains("Ok")) {
                driver.findElement(By.className("bancs-dialog")).findElement(By.linkText(buttonToBeClicked[0])).click();
            } else if (buttonToBeClicked[0].contains("Cancel")) {
                driver.findElement(By.className("bancs-dialog")).findElement(By.linkText(buttonToBeClicked[0])).click();
            } else if (buttonToBeClicked[0].contains("Save")) {
                driver.findElement(By.className("bancs-dialog")).findElement(By.linkText(buttonToBeClicked[0])).click();
            } else if (buttonToBeClicked[0].contains("Reset")) {
                driver.findElement(By.className("bancs-dialog")).findElement(By.linkText(buttonToBeClicked[0])).click();
            } else if (buttonToBeClicked[0].contains("Close")) {
                driver.findElement(By.className("bancs-dialog")).findElement(By.linkText(buttonToBeClicked[0])).click();
            } else {
                driver.findElement(By.className("bancs-dialog-close")).click();
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error handling Dialog ");
        }
    }

    public NavigatorUtility handleDialogs(String... buttonToBeClicked) {
        try {
            if (buttonToBeClicked.length > 0) handleDialogsDirect(buttonToBeClicked);
            else handleDialogsDirect();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility enterText(String... StringElementArray) {
        String id = null;
        String value = null;
        WebElement element = null;
        Properties properties = null;

        if (StringElementArray.length == 1) {
            id = StringElementArray[0];
        } else {
            id = StringElementArray[0];
            value = StringElementArray[1];
        }
        try {
            if (value == null) {
                properties = testContextConfigurer.getProperties(BrowserDriverContext.getClassName() + ".properties");
                if (properties == null)
                    throw new FileNotFoundException("Please load " + BrowserDriverContext.getClassName() + ".properties");

                value = properties.getProperty(BrowserDriverContext.getMethodName() + "." + id);
                if (value != null) {

                    element = driver.findElement(By.id(id));
                    element.sendKeys(Keys.CONTROL + "a");
                    element.sendKeys(Keys.DELETE);
                    element.sendKeys(value);
                    element.sendKeys(Keys.TAB);
                } else {
                    throw new NotFoundException("Value not found in the property file for the id=" + id);
                }
                Thread.sleep(300);
            } else {
                element = driver.findElement(By.id(id));
                element.sendKeys(Keys.CONTROL + "a");
                element.sendKeys(Keys.DELETE);
                element.sendKeys(value);
                element.sendKeys(Keys.TAB);
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            alerts();
        }
        return this;
    }

    public NavigatorUtility findDataInTableNDoubleClick(String tableId, String valueToBeSearched) {
        try {
            WebElement table = driver.findElement(By.id(tableId));
            boolean flag = false;
            int index = 0;
            List<WebElement> allRows = ReadTableContent(tableId);
            for (WebElement row : allRows) {
                List<WebElement> tableData = row.findElements(By.tagName("td"));
                for (WebElement cell : tableData) {
                    if (cell.getText().equals(valueToBeSearched) || valueToBeSearched.equals("")) {
                        doubleClick(cell);
                        flag = true;
                        break;
                    }
                }
                if (flag) break;
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error at findDataInTableNDoubleClick()" + tableId + " " + valueToBeSearched);

        }

        return this;

    }

    public NavigatorUtility assertElementValue(String elementId, String referenceValue) {
        WebElement element;
        try {
            Thread.sleep(2000);
            element = driver.findElement(By.id(elementId));
            checkCondition("Value of " + elementId + " is different than " + referenceValue, element.getAttribute("value").equals(referenceValue));
        } catch (Exception e) {
        }

        return this;
    }

    public NavigatorUtility enterDate(String calenderButtonId, String date) {
        calender(calenderButtonId, date);
        return this;
    }

    public NavigatorUtility createUser(String fieldID) {
        int j = (int) (500 + new Random().nextInt(100) + new Random().nextInt(200));
        String x = "" + j;
        try {
            driver.findElement(By.id(fieldID)).sendKeys(x);
        } catch (Exception e) {
        }
        return this;
    }

    public void nativeSelectDirect(String selectID, String option){
        try {
            Select select = new Select(driver.findElement(By.id(selectID)));
            select.selectByVisibleText(option);
        } catch (Exception e) {
            System.out.println("Native select error");
            e.printStackTrace();
        }
    }

    public NavigatorUtility nativeSelect(String selectID, String option) {
        try {
            nativeSelectDirect(selectID,option);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility in(String inNotIn, String... values) {
        try {
            if (values.length > 0 && values.length < 5) {
                for (int i = 0; i < values.length; i++) {
                    WebElement main = driver.findElement(By.id("inNotIn"));
                    main.findElement(By.id("inNotIn" + i)).findElement(By.className("inputContainer")).click();
                    main = driver.findElement(By.id("inNotIn"));
                    main.findElement(By.id("inNotIn" + i)).findElement(By.tagName("input")).sendKeys(Keys.chord(Keys.CONTROL, "a"));
                    main.findElement(By.id("inNotIn" + i)).findElement(By.tagName("input")).sendKeys(Keys.DELETE);
                    main.findElement(By.id("inNotIn" + i)).findElement(By.tagName("input")).sendKeys(values[i]);
                    main.findElement(By.id("inNotIn" + i)).findElement(By.className("tick")).click();
                }
            }

        } catch (Exception e) {
            //System.out.println("inNotIn error");
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility removeQuery(String optionToBeUpdated) {
        try {
            WebElement queryBox = driver.findElement(By.id("queryContainer")).findElement(By.id("query1"));
            List<WebElement> queryList = queryBox.findElements(By.tagName("ul"));
            //System.out.println("No of queries are : " + queryList.size());
            for (WebElement x : queryList) {
                WebElement queryContainer = x.findElement(By.id("queryLabel"));
                String queryOption = queryContainer.findElement(By.tagName("span")).getText();
                if (queryOption.contains(optionToBeUpdated)) {
                    x.click();
                    //System.out.println("C1");
                    x.findElement(By.tagName("i")).click();
                    //System.out.println("C2");
                }
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility verifySearchCondition(String tableId, String columnName, String value) {
        try {
            int rqdHeadrIndex = 0, rqdDataIndex = 0;
            boolean foundColumn = false, foundData = false;
            List<WebElement> allRows = ReadTableContent(tableId);

            //TO READ TABLE HEADERS
            for (WebElement row : allRows) {
                List<WebElement> tableHeaders = row.findElements(By.tagName("th"));
                for (WebElement cell : tableHeaders) {
                    System.out.println("---" + cell.getText());
                    if (cell.getText().equals(columnName)) {
                        foundColumn = true;
                        break;
                    }
                    rqdHeadrIndex++;
                }
            }
            if (foundColumn == false) {
                System.out.println("Could not find the specified column " + columnName + "for table " + tableId + ".Operation failure");
                return this;
            }
            System.out.println("tableheader::" + columnName + " Index::" + rqdHeadrIndex);

            //TO READ THE ROW DATA
            for (WebElement row : allRows) {
                List<WebElement> tableData = row.findElements(By.tagName("td"));
                if (tableData.size() == 0) {
                    continue;
                }
                rqdDataIndex = 0;
                for (WebElement cell : tableData) {
                    if (rqdDataIndex == rqdHeadrIndex) {
                        if (cell.getText().contains(value)) {
                            foundData = true;
                            rqdDataIndex++;
                        } else {
                            foundData = false;
                        }
                    }
                }
            }
            if (foundData == false)
                System.out.println("Data verification has failed for table " + tableId + " with column " + columnName + " with data " + value);
        } catch (Exception e) {
            System.out.println("Error at verifySearchCondition() for input :" + tableId + " " + columnName + " " + value);
            e.printStackTrace();
        }
        return this;
    }


    //FOR HOME PAGE

    public NavigatorUtility otherMenuOptions(String menuOptionId, String... optionToBeclicked) {
        try {
            driver.switchTo().defaultContent();
            driver.findElement(By.id(menuOptionId)).sendKeys(Keys.SPACE);
            if (optionToBeclicked.length > 0) {
                System.out.println(optionToBeclicked[0]);
                WebElement element = driver.findElement(By.id(menuOptionId + "contain"));
                element.findElement(By.partialLinkText(optionToBeclicked[0])).click();
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error at otherMenuOptions() for input :" + menuOptionId);
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility addTabToFav(String tabToBeAddedToFav) {
        try {

            clickOnTab(tabToBeAddedToFav);
            driver.switchTo().defaultContent();
            openOtherMenuOptions("favorites", "Add To Favourites");
        } catch (Exception e) {
            System.out.println("Error at addTabToFav() for input :" + tabToBeAddedToFav);
            e.printStackTrace();
        }
        return this;
    }

    public void clickOnTab(String tabName) {
        try {
            int i = 0;
            driver.switchTo().defaultContent();
            WebElement element = driver.findElement(By.id("stWidthChecker"));
            List<WebElement> tabs = element.findElements(By.tagName("a"));
            for (WebElement tab : tabs) {
                if (tab.getText().equals(tabName)) {
                    tab.click();
                    break;
                }
                i++;
            }
        } catch (Exception e) {
            System.out.println("Can not click on tab : " + tabName);
            e.printStackTrace();
        }

    }

    public void openOtherMenuOptions(String menuOptionID, String... optionToBeClicked) {
        try {
            driver.switchTo().defaultContent();
            driver.findElement(By.id(menuOptionID)).click();
            System.out.println("LENGTH OF optionToBeClicked =" + optionToBeClicked.length);
            if (optionToBeClicked.length > 0) {
                System.out.println(optionToBeClicked[0]);
                WebElement element = driver.findElement(By.id(menuOptionID + "contain"));
                element.findElement(By.partialLinkText(optionToBeClicked[0])).click();
            }
            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error at openOtherMenuOptions() for input :" + menuOptionID);
            e.printStackTrace();
        }
    }

    public NavigatorUtility closeAllTabs() {
        try {
            driver.switchTo().defaultContent();
            WebElement element = driver.findElement(By.id("stWidthChecker"));
            List<WebElement> tabs = element.findElements(By.tagName("a"));
            List<WebElement> tabLi = element.findElements(By.tagName("li"));
            System.out.println("----" + tabs.size() + "  " + tabLi.size());
            for (WebElement liData : tabLi) {
                String x = liData.findElement(By.tagName("a")).getText();
                System.out.println(x);
                if (x.equals("Home")) {
                    System.out.println("---CONTINUE");
                    continue;
                }
                liData.findElement(By.tagName("a")).click();
                liData.findElement(By.className("bancs-tab-icon")).click();
            }

            Thread.sleep(2000);
        } catch (Exception e) {
            System.out.println("Error in closeAllTabs()");
            e.printStackTrace();
        }

        return this;
    }

    public NavigatorUtility preferences(String optionToBeClicked) {
        try {
            if (optionToBeClicked.equalsIgnoreCase("close") || optionToBeClicked.equalsIgnoreCase("save")) {
                Thread.sleep(1000);
                saveORclosePrefChanges(optionToBeClicked);
            } else {
                driver.switchTo().defaultContent();
                WebElement element = driver.findElement(By.id("userPreferences"));
                List<WebElement> listOfH2 = element.findElements(By.tagName("h2"));
                for (WebElement x : listOfH2) {
                    WebElement header = x.findElement(By.tagName("a"));
                    if (header.getText().equals(optionToBeClicked)) {
                        Thread.sleep(2000);
                        header.sendKeys(Keys.SPACE);
                        break;
                    }
                }
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            System.out.println("Error at preferences() for input :" + optionToBeClicked);
            e.printStackTrace();
        }
        return this;
    }

    public void saveORclosePrefChanges(String option) {
        try {
            driver.switchTo().defaultContent();
            WebElement preferences = driver.findElement(By.id("userPreferences"));
            WebElement accordian = preferences.findElement(By.id("userPrefAccordion"));
            List<WebElement> x = accordian.findElements(By.className("bancs-accordion"));
            if (option.equals("save"))
                x.get(x.size() - 1).findElement(By.tagName("a")).click();
            if (option.equals("close")) {
                x.get(0).findElement(By.className("bancs-icon-close")).click();
            }
        } catch (Exception e) {
            System.out.println("Error at saveORclosePrefChanges() for input :" + option);
            e.printStackTrace();
        }
    }

    public NavigatorUtility birdsEyeView(String tabToBeClicked) {
        try {
            System.out.println(tabToBeClicked);
            driver.switchTo().defaultContent();
            driver.findElement(By.className("stGroup")).findElement(By.tagName("span")).click();

            WebElement birdsEyeView = driver.findElement(By.id("birdsEyeView"));
            List<WebElement> listOfLi = birdsEyeView.findElements(By.tagName("li"));
            for (WebElement y : listOfLi) {
                String nameOfTab = y.findElement(By.tagName("span")).getText();
                if (nameOfTab.equals(tabToBeClicked)) {
                    y.findElement(By.tagName("img")).click();
                    break;
                }
            }
            Thread.sleep(3000);
        } catch (Exception e) {
            System.out.println("Error at birdsEyeView() for input :" + tabToBeClicked);
            e.printStackTrace();
        }
        return this;
    }

    public NavigatorUtility threeColumnSorting(String column1,String sortType1,String column2,String sortType2,String column3,String sortType3) {
        try{

            driver.findElement(By.id("sortingOption")).findElement(By.tagName("a")).click();
            Thread.sleep(2000);
            driver.findElement(By.id("sortingOptionContainer")).findElement(By.id("sortRadio1")).click();
            Thread.sleep(2000);

//            column1="wca_"+column1.replaceAll(" ","");
//            column1=column1.toLowerCase();
            nativeSelect("sortField1", column1);
            if(  ! sortType1.equals("A"))driver.findElement(By.id("sortRadio2")).click() ;
            Thread.sleep(2000);
//            column2="wca_"+column2.replaceAll(" ","");
//            column2=column2.toLowerCase();
            nativeSelect("sortField2",column2);
            if(  ! sortType2.equals("A"))driver.findElement(By.id("sortRadio4")).click() ;
            Thread.sleep(2000);
//            column3="wca_"+column3.replaceAll(" ","");
//            column3=column3.toLowerCase();
            nativeSelect("sortField3", column3);
            if(  ! sortType3.equals("A"))driver.findElement(By.id("sortRadio6")).click() ;
            Thread.sleep(2000);
            handleDialogsDirect("Ok");

        }  catch(Exception e){
            System.out.println("3 column sort failure");
            e.printStackTrace();
        }
        return this;
    }


}
