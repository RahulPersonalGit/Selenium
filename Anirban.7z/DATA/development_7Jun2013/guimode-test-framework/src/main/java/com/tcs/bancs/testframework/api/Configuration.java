package com.tcs.bancs.testframework.api;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 5/22/13
 * Time: 12:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class Configuration {
    private String baseUrl;
    private String username;
    private String password;
    private String SeleniumGridReqd;
    private String HubUrl;
    private String TestCases;




    public static class Builder {
        private String baseUrl;
        private String username;
        private String password;
        public String SeleniumGridReqd;
        private String HubUrl;
        private String TestCases;

        public Builder(String baseUrl) {
            this.baseUrl = baseUrl;
        }
        public Builder SeleniumGridReqd(String SeleniumGridReqd) {
            this.SeleniumGridReqd = SeleniumGridReqd;
            return this;
        }
        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder setHubUrl(String HubUrl) {
            this.HubUrl = HubUrl;
            return this;
        }
        public Builder setTestCases(String TestCases) {
            this.TestCases = TestCases;
            return this;
        }


        public Configuration build() {
            return new Configuration(this);
        }
    }

    private Configuration(Builder configuration) {
        this.baseUrl = configuration.baseUrl;
        this.username = configuration.username;
        this.password = configuration.password;
        this.SeleniumGridReqd=configuration.SeleniumGridReqd;
        this.HubUrl=configuration.HubUrl;
        this.TestCases=configuration.TestCases;
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public String getTestCases() {
        return TestCases;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    public String getSeleniumGridReqd() {
        return SeleniumGridReqd;
    }

    public String getHubUrl() {
        return HubUrl;
    }

}
