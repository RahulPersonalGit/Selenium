package com.tcs.bancs.testframework.api;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.AbstractWebDriverEventListener;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Use this class to provide the test context details such as
 * different browser, browser version, port on which tests need
 * to be executed etc
 *
 * @author Deepak Jacob
 */
public abstract class DefaultTestContextConfigurer {
    //The logger
    private final static Logger logger = Logger.getLogger(DefaultTestContextConfigurer.class.getName());

    /**
     * This program will accept only the properties files that are starting
     * with names - ie / chrome / firefox and opera
     */
    private static final FileFilter ACCEPTED_BROWSER_PROP_FILE_NAMES = new FileFilter() {
        @Override
        public boolean accept(File file) {
            if (file.isFile() && (file.getName().startsWith("ie")
                    || file.getName().startsWith("chrome")
                    || file.getName().startsWith("ie")
                    || file.getName().startsWith("firefox")
                    || file.getName().startsWith("opera"))) {
                return true;
            }
            return false;
        }
    };

    public abstract File registerBrowserPropertiesPath();



    public abstract boolean assumeDefaultPaths();


    public  List<WebDriver> getRemoteDrivers() {
        List<WebDriver> drivers = new ArrayList<WebDriver>();
        // Get the browsers
        List<Browser> browsers = getBrowsers();
        try{
            for (Browser browser : browsers) {
                WebDriver driver = null;
                //TODO: Screwed up logic. Improvement is a must.
                //TODO: Use map instead of if-elseif-else
                if (isIE(browser.getExecutablePath(), browser.getName())) {
                  driver = new RemoteWebDriver(new URL(getHubUrl()), DesiredCapabilities.internetExplorer());
                } else if (isFirefox(browser.getExecutablePath(), browser.getName())) {
                driver = new RemoteWebDriver(new URL(getHubUrl()), DesiredCapabilities.firefox());
                } else if (isChrome(browser.getExecutablePath(), browser.getName())) {
                driver = new RemoteWebDriver(new URL(getHubUrl()), DesiredCapabilities.chrome());
                } else if (isOpera(browser.getExecutablePath(), browser.getName())) {
                driver = new RemoteWebDriver(new URL(getHubUrl()), DesiredCapabilities.opera());
                }
                drivers.add(driver);
            }
        }catch (MalformedURLException e){
                e.printStackTrace();
        }
        return drivers;
    }
    public  List<WebDriver> getDrivers() {

     List<WebDriver> drivers = new ArrayList<WebDriver>();
        // Get the browsers
        List<Browser> browsers = getBrowsers();
        for (Browser browser : browsers) {
            WebDriver driver = null;
            //TODO: Screwed up logic. Improvement is a must.
            //TODO: Use map instead of if-elseif-else
            if (isIE(browser.getExecutablePath(), browser.getName())) {
                driver = new InternetExplorerDriver();
               } else if (isFirefox(browser.getExecutablePath(), browser.getName())) {
                driver = new FirefoxDriver();
            } else if (isChrome(browser.getExecutablePath(), browser.getName())) {
                System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
                driver = new ChromeDriver();
            }

 //     List<? extends AbstractWebDriverEventListener> listeners = registerDriverListeners();


//                EventFiringWebDriver efwd = null;
//                for (AbstractWebDriverEventListener l : listeners) {
//                    efwd = new EventFiringWebDriver(driver);
//                    efwd.register(l);
//                }
//
//                if (efwd != null) {
//                    driver = efwd;
//                }

            drivers.add(driver);
        }
        return drivers;
    }

    private boolean isOpera(String executablePath, BrowserName name) {
        return executablePath.endsWith("opera.exe")
                || name == BrowserName.OPERA;
    }

    private boolean isChrome(String executablePath, BrowserName name) {
        return executablePath.endsWith("chrome.exe")
                || name == BrowserName.GOOGLE_CHROME;
    }

    private boolean isFirefox(String executablePath, BrowserName name) {
        return executablePath.endsWith("firefox.exe")
                || name == BrowserName.FIREFOX;
    }

    private boolean isIE(String executablePath, BrowserName name) {
        return executablePath.endsWith("iexplore.exe")
                || name == BrowserName.INTERNET_EXPLORER;
    }


    private List<Browser> getBrowsers() {
        File browserPropPath = registerBrowserPropertiesPath();
        logger.log(Level.INFO, "Trying to read the browser configuration properties from "
                + browserPropPath.getAbsolutePath());
        checkDirectoryStatus(browserPropPath);

        File[] propFiles = browserPropPath.listFiles(ACCEPTED_BROWSER_PROP_FILE_NAMES);

        List<Browser> browsers = new ArrayList<Browser>();
        for (File file : propFiles) {
            logger.log(Level.INFO, "Reading browser configuration properties from file "
                    + file.getAbsolutePath());
            Browser browser = getBrowser(file);
            browsers.add(browser);
        }
        return browsers;
    }

    private Browser getBrowser(File file) {
        Properties properties = this.getProperties(file.getName());
        String executablePath = properties.getProperty("browser.executable.path");
        String name = properties.getProperty("browser.name");
        String version = properties.getProperty("browser.version");

        // check whether the provided properties are valid
        // if not throw an exception
        if (executablePath == null || name == null || version == null) {
            throw new RuntimeException("Please provide valid properties in file " + file.getAbsolutePath());
        }
        //TODO: Create a new browser name from the string.
        BrowserName browserName = null;
       if(name.equals("Internet Explorer"))
           browserName = BrowserName.INTERNET_EXPLORER;
       if(name.equals("Mozilla Firefox"))
           browserName = BrowserName.FIREFOX;
       if(name.equals("Google Chrome"))
           browserName = BrowserName.GOOGLE_CHROME;

        return new Browser.Builder(executablePath).name(browserName).version(version).build();
    }

    private HashMap<String,String> getProperty(String Classname,String methodName){
          Properties properties=getProperties(Classname+".properties");



                return null;
    }

    private void checkDirectoryStatus(File browserPropPath) {
        // check whether the provided file is a valid directory
        // if not throw an exception
        if (!browserPropPath.exists() || !browserPropPath.isDirectory()) {
            throw new RuntimeException("The path " + browserPropPath + " must be a directory");
        }
    }

    public Properties getProperties(String fileName) {
        Properties props = new Properties();
        try {
            //load a properties file from class path, inside static method
            //props.load(TestContextConfigurerImpl.class.getClassLoader().getResourceAsStream(fileName));
            props.load(this.getClass().getClassLoader().getResourceAsStream(fileName));
        } catch (IOException ex) {
            throw new RuntimeException(ex);
        }
        return props;
    }

    public String getURL(){
        return  getConfiguration().getBaseUrl();
    }
    public String getUserName(){
        return  getConfiguration().getUsername();
    }
    public String getPassWord(){
        return  getConfiguration().getPassword();
    }

    public String getSelenium(){
        return  getConfiguration().getSeleniumGridReqd();
    }
    public String getHubUrl(){
        return  getConfiguration().getHubUrl();
    }
    public String getTestCases(){
        return  getConfiguration().getTestCases();
    }
    private Configuration getConfiguration(){
        File propertyfile = new File(registerBrowserPropertiesPath()+"\\test-configurer.properties");
        logger.log(Level.INFO, "Trying to read the browser configuration properties from "
                + propertyfile.getAbsolutePath());

        Properties properties = this.getProperties(propertyfile.getName());
        String seleniumreqd=properties.getProperty("SeleniumGridReqd");
        String url = properties.getProperty("baseUrl");
        String username = properties.getProperty("username");
        String password = properties.getProperty("password");
        String hubUrl = properties.getProperty("HubURL");
        String testCases = properties.getProperty("TestCases");
        if (url == null || username == null || password == null) {
            throw new RuntimeException("Please provide valid properties in file " + propertyfile.getAbsolutePath());
        }

    return new Configuration.Builder(url).username(username).password(password).SeleniumGridReqd(seleniumreqd).setHubUrl(hubUrl).setTestCases(testCases).build();









    }
}
