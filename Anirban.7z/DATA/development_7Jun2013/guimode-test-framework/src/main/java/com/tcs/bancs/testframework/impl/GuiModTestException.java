package com.tcs.bancs.testframework.impl;

import java.lang.reflect.Method;

/**
 * AbstractTest specific test case exception
 *
 * @author Deepak Jacob
 */
public class GuiModTestException extends RuntimeException {
    public GuiModTestException(String message) {
        super(message);
    }
    public GuiModTestException(Throwable cause) {
        super(cause);
    }
    public GuiModTestException(Method method, String message){
        super("Test not executed : " + method.toGenericString() + ", specific error is " + message );
    }
}
