package com.tcs.bancs.testframework.api;

/**
 * Encapsulates browser names
 *
 * @author Deepak Jacob
 */
public enum BrowserName {

    INTERNET_EXPLORER("Internet Explorer"),
    FIREFOX("Mozilla Firefox"),
    GOOGLE_CHROME("Google Chrome"),
    OPERA("Opera");

    private final String browserName;

    BrowserName(String s) {
        this.browserName = s;
    }
}
