package com.tcs.bancs.testframework.util;

import com.tcs.bancs.testframework.api.Browser;
import com.tcs.bancs.testframework.api.BrowserName;
import com.tcs.bancs.testframework.impl.TestContextConfigurerImpl;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.util.ArrayList;
import java.util.List;

/**
 * Get the details of currently executing driver.
 */
public class BrowserDriverContext {

    private static ThreadLocal<WebDriver> DRIVER = new ThreadLocal<WebDriver>();
    private static ThreadLocal<String> ClassName = new ThreadLocal<String>();
    private static ThreadLocal<String> MethodNameName = new ThreadLocal<String>();


    public static String getClassName() {
      return ClassName.get();
    }

    public static String getMethodName() {
        return MethodNameName.get();
    }

    public static void setClassName(String className) {
        if (className == null) {
            ClassName.remove();
        }
        ClassName.set(className);
    }

    public static void setMethodNameName(String methodNameName) {
        if (methodNameName == null) {
            MethodNameName.remove();
        }
        MethodNameName.set(methodNameName);
    }


    public static WebDriver get() {
        return DRIVER.get();
    }



    public static void set(WebDriver driver) {
        if (driver == null) {
            DRIVER.remove();
        }
        DRIVER.set(driver);
    }
    public static String getBrowserName(WebDriver webDriver){
        String browserName = null;

          if(new TestContextConfigurerImpl().getSelenium().equals("N"))
          {
        if(webDriver instanceof InternetExplorerDriver)
            browserName="IE";
        if(webDriver instanceof ChromeDriver)
            browserName="Chrome";
        if(webDriver instanceof FirefoxDriver)
            browserName="Firefox";
          }
        else
          {
              if(((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().contains("internet"))
                  browserName="IE";
              if(((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().contains("chrome"))
                  browserName="Chrome";
              if(((RemoteWebDriver) webDriver).getCapabilities().getBrowserName().contains("firefox"))
                  browserName="Firefox";
          }


        return  browserName;
    }



}
