package com.tcs.bancs.testframework.impl;

import java.io.File;

/**
 * An example test context configuration.
 */
public class TestContextConfigurerImpl extends com.tcs.bancs.testframework.api.DefaultTestContextConfigurer {
    @Override
    public File registerBrowserPropertiesPath() {
        return new File("C:\\Users\\349461\\Desktop\\development_7Jun2013\\guimode-test-framework\\src\\main\\resources");
    }


    @Override
    public boolean assumeDefaultPaths() {
        return false;
    }
}
