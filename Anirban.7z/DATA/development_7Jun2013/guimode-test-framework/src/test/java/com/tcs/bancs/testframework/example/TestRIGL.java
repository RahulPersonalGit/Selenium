package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;


@RunWith(GuiModTestRunner.class)
public class TestRIGL {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver = BrowserDriverContext.get();
    }

    @Test
    public void customSearch() {
        navigatorUtility
                //openPage()
                .navigate("Maintain", "ReferenceImplementation", "RI Generic List")
                .assertElement("searchSelect-input")
                .assertElement("bui_ct_GL_ControlsSearch_wca_employeeReference")
                .assertElement("Search")
                .assertElement("advancedSearchLink")
                .assertElement("openLink")
                .assertElement("bui_ct_GL_ControlsSearchList_Table")
                .assertElement("next")
                .assertElement("prev")
                .clickOnButton("Search")
                        //doubleClickTableNew()
                .findDataInTableNDoubleClick("bui_ct_GL_ControlsSearchList_Table", "1")
                        //testCloseTabs()
                .closeTab("View Search List")
                .switchToTab("RI Generic List")
                        //testGLQBE1New()
                .clickOnButton("bui_ct_GL_ControlsSearch_wca_employeeReference_button")
                .switchQBE()
                .clickOnButton("Search")
                .assertElement("Help7")
                .assertElement("Close8")
                .assertElement("MCB_SearchWC_wca_employeeReference")
                .assertElement("MCB_SearchWC_wca_loginId")
                .assertElement("MCB_SearchWC_wca_firstName")
                .assertElement("MCB_SearchWC_wca_businessPartner")
                .assertElement("MCB_SearchWC_wca_userStatus-input")
                .assertElement("MCB_SearchWC_wca_lastLoginTime")
                .assertElement("MCB_SearchWC_wca_userEffectiveDate")
                .assertElement("Search")
                .assertElement("bui_w_SearchListQBE_Table")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table", "Arun")
                .switchToTab("RI Generic List")
                .clickOnButton("Search")
                .clickOnButton("bui_ct_GL_ControlsSearch_wca_employeeReference_button")
                .switchQBE()
                .enterText("MCB_SearchWC_wca_firstName", "Sucharita")
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table", "Sucharita")
                .switchToTab("RI Generic List")
                .clickOnButton("Search")
                .clickOnButton("bui_ct_GL_ControlsSearch_wca_employeeReference_button")
                .switchQBE()
                .enterText("MCB_SearchWC_wca_loginId", "SUCHARITA")
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table", "SUCHARITA")
                .switchToTab("RI Generic List")
                .clickOnButton("Search")
                .clickOnButton("bui_ct_GL_ControlsSearch_wca_employeeReference_button")
                .switchQBE()
                .enterText("MCB_SearchWC_wca_businessPartner", "465465")
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table", "465465")
                .switchToTab("RI Generic List")
                .clickOnButton("Search")
                .clickOnButton("bui_ct_GL_ControlsSearch_wca_employeeReference_button")
                .switchQBE()
                .enterText("MCB_SearchWC_wca_lastLoginTime", "00:00:00")
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table", "00:00:00")
                .switchToTab("RI Generic List")
                .clickOnButton("Search")
                        //testPagination()
                .testTablePagination("bui_ct_GL_ControlsSearchList_Table")
                        //advancedGLNew()
                .clickOnButton("advancedSearchLink")
                .clickOnButton("Search")
                .assertElement("savedSearch")
                .assertElement("moreActions")
                .assertElement("searchSelect")
                .assertElement("query1")
                .assertElement("Search")
                .assertElement("simpleSearchLink")
                .assertElement("prev")
                .assertElement("next")
                .assertElement("openLink")
                .buttonMenu("moreActions", "Start new search")
                .clickOnButton("Search")
                .dblClickSrchOption("searchSelect", "Employee Reference")
                .clickOnButton("addLink")
                .handleAlerts()
                .enterText("bui_ct_GL_ControlsSearch_wca_employeeReference", "1")
                        //BETWEEN OPERATION
                .nativeSelect("operatorType", "between")
                .enterText("bui_ct_GL_ControlsSearch_wca_employeeReference_from_Value", "1")
                .enterText("bui_ct_GL_ControlsSearch_wca_employeeReference_to_Value", "10")
                .clickOnButton("addLink")
                .clickOnButton("Search")
                        //IN OPERATION
                .buttonMenu("moreActions", "Start new search")
                .dblClickSrchOption("searchSelect", "Employee Reference")
                .nativeSelect("operatorType", "In")
                .in("inNotIn", "1", "2", "3")
                .clickOnButton("addLink")
                .clickOnButton("Search")
                        //UPDATE QUERY
                .updateQuery("Employee Reference")
                .in("inNotIn", "4", "5", "6")
                .clickOnButton("updateLink")
                .clickOnButton("Search")
                        //REMOVE QUERY
                .removeQuery("Employee Reference")
                .clickOnButton("Search")
                        //SAVE AS "NEW SEARCH"
                .dblClickSrchOption("searchSelect", "Employee Reference")
                .nativeSelect("operatorType", "In")
                .in("inNotIn", "1", "2", "3")
                .clickOnButton("addLink")
                .clickOnButton("Search")
                .buttonMenu("moreActions", "Save as new")
                .enterText("newSaveName", "ABCDEF")
                .clickOnButton("ok")
                .handleAlerts()
                .buttonMenu("savedSearch", "ABCDEF")
                        //SET AS DEFAULT
                .buttonMenu("moreActions", "Set this as default")
                .closeTab("RI Generic List")
                .navigate("Maintain", "ReferenceImplementation", "RI Generic List")
                        //REMOVE ABCD FROM DEFAULT
                .buttonMenu("savedSearch", "ABCDEF")
                .buttonMenu("moreActions", "Remove Default")
                .closeTab("RI Generic List")
                .navigate("Maintain", "ReferenceImplementation", "RI Generic List")
                .clickOnButton("advancedSearchLink")
                        //REMOVE ABCD
                .buttonMenu("savedSearch", "ABCDEF")
                .buttonMenu("moreActions", "Delete")
                .handleDialogs("Ok")
                .closeTab("RI Generic List")
                .navigate("Maintain", "ReferenceImplementation", "RI Generic List")

        ;
    }


}
