package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.api.Depends;
import com.tcs.bancs.testframework.api.RunIf;
import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 5/27/13
 * Time: 11:53 AM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRITabbedForm {

    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRITabbedForm.class.getName());
    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }


    public void  doAssertFields() {
        try {
            initSelenium();
                navigatorUtility
                    .navigate("Maintain", "ReferenceImplementation", "RI Tab Form")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_businessPartner_button")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_employeeReference")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_processingCenter_button")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_firstName")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_middleName")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_lastName")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_email")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_phoneNo")
                        .assertElement("bui_ct_userDetailsInner_bui_wca_salary")
                        .assertElement("bui_ct_userAccessControl_bui_wca_login")
                        .assertElement("bui_ct_userAccessControl_bui_wca_password")
                        .assertElement("bui_ct_userAccessControl_bui_wca_confirmPassword")
                        .takeScreenShot("AssertFieldsUser")
                    .closeTab("RI Tab Form");

                logger.log(Level.INFO, "TestCase Passed ");

        } catch (Exception e) {
            logger.log(Level.INFO, "Exception occured");
        }
    }

    @Test
    //@Depends(methods = {"com.tcs.bancs.testframework.example.TestRITabbedForm#doAssertFields"})
     public void  doFillFormFields() {
        try {

            Thread.sleep(2000);
            navigatorUtility
                    .navigate("Maintain", "ReferenceImplementation", "RI Tab Form")

                   // .checkNumeric("bui_ct_userDetailsInner_bui_wca_phoneNo")
                   // .checkMandatory("bui_ct_userDetailsInner_bui_wca_businessPartner")


//                    .clickOnButton("bui_ct_userDetailsInner_bui_wca_businessPartner_button")
//                    .switchQBE()
//                    .search()
//                    .dblClickTblRow("bui_w_SearchListQBE_Table",2)
//                    .clickOnButton("bui_ct_userDetailsInner_bui_wca_processingCenter_button")
//                    .switchQBE()
//                    .search()
//                    .dblClickTblRow("bui_w_SearchListQBE_Table",1)
//                    .enterText("bui_ct_userDetailsInner_bui_wca_businessPartner_button")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_employeeReference")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_processingCenter_button")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_firstName")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_middleName")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_lastName")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_email")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_phoneNo")
//                    .enterText("bui_ct_userDetailsInner_bui_wca_salary")
//                    .enterText("bui_ct_userAccessControl_bui_wca_login")
//                    .enterText("bui_ct_userAccessControl_bui_wca_password")
//                    .enterText("bui_ct_userAccessControl_bui_wca_confirmPassword")
                    .takeScreenShot("FillFormFieldsUser")
                    .closeTab("RI Tab Form");


            logger.log(Level.INFO, "TestCase Passed ");

        } catch (Exception e) {
            logger.log(Level.INFO, "Exception occured");
            e.printStackTrace();
        }
    }

}
