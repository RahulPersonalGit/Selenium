package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRIForm {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void formSteps() {
        navigatorUtility
                //openWindow()
                .navigate("Maintain", "ReferenceImplementation", "RI Advanced Search List")
                //openFormWindow()
                .clickOnButton("Search")
                .rghtClickTblRow("bui_w_UserListADSL_Table",2,"View Account")
                .switchToTab("View Account")
                //testformViewMode()
                .assertElement("groupBox0_bui_wca_employeeReference")
                .assertElementValue("groupBox0_bui_wca_employeeReference","1")
                .closeTab("View Account")
                //testFormModifyMode()
                .switchToTab("RI Advanced Search List")
                .clickOnButton("Search")
                .rghtClickTblRow("bui_w_UserListADSL_Table",2,"Modify Account")
                .switchToTab("Modify Account")
                .assertElement("groupBox0_bui_wca_employeeReference")
                .assertElementValue("groupBox0_bui_wca_employeeReference","1")
                .assertElement("groupBox1_bui_wca_bankName")
                .enterText("groupBox1_bui_wca_bankName","SBI Bank")
                .enterText("groupBox1_bui_wca_salary","75542")
                .clickOnComboBox("groupBox1_bui_wca_balanceCurrency-main","INR")
                .enterText("groupBox1_bui_wca_balanceAmount","343450")
                .clickOnButton("groupBox1_bui_wca_processingCenter_button")
                .switchQBE()
                .enterText("MCB_SearchWC_wca_employeeReference","1")
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table","565")
                .switchToTab("Modify Account")
                .clickOnButton("Save4")
                .handleAlerts()
                .clickOnButton("Close5")
                .switchToTab("RI Advanced Search List")
                .clickOnButton("Search")
                .rghtClickTblRow("bui_w_UserListADSL_Table",4,"View Account")
                .switchToTab("View Account")
                .assertElementValue("groupBox1_bui_wca_bankName","SBI Bank")
                .assertElementValue("groupBox1_bui_wca_salary","75,542.00")
                .assertElementValue("groupBox1_bui_wca_balanceAmount","343,450.00")


        ;
    }



}
