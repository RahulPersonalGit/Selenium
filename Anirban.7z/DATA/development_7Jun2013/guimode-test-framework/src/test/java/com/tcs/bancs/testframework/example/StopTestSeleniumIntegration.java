package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.api.Depends;
import com.tcs.bancs.testframework.api.RunIf;
import com.tcs.bancs.testframework.impl.TestContextConfigurerImpl;
import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 * A simple test to check the selenium integration.
 */
@RunWith(GuiModTestRunner.class)
public class StopTestSeleniumIntegration {

    private final static Logger logger = Logger.getLogger(StopTestSeleniumIntegration.class.getName());

    private static final String URL = "http://www.google.com/";

    private static List<WebDriver> drivers = null;

    public static WebDriver driver;

    public static WebDriver getDriver() {
        return driver;
    }

    public static void setDriver(WebDriver driver) {
        StopTestSeleniumIntegration.driver = driver;
    }

    public void initSelenium() {
        drivers = new TestContextConfigurerImpl().getDrivers();
        //Navigate to google search
        logger.log(Level.INFO, "Navigating to " + URL);

            BrowserDriverContext.set(driver);



        setDriver(drivers.get(0));
        getDriver().get(URL);
       // throw new RuntimeException("Error");

    }

//   @Test
//   @RunIf(browsers ={"IE"})
   @Depends(methods = {"com.tcs.bancs.testframework.example.TestSeleniumIntegration#initSelenium"})
    public void testGoogleSearch() {
        // Find the text input element by its name
        logger.log(Level.INFO, "Inside the function testGoogleSearch "  );
        WebElement element = getDriver().findElement(By.name("q"));
        // Enter something to search for
        element.sendKeys("Cheese!");
        // Now submit the form. WebDriver will find the form for us from the element
        element.submit();
        String title = getDriver().getTitle();
        logger.log(Level.INFO, "Title of the page is  " + title);
    }
    @After
    public void doAfter(){
        getDriver().quit();
    }
}
