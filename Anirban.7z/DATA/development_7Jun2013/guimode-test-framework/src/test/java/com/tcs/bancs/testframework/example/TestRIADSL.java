package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRIADSL {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void customSearch() {
        navigatorUtility
                //openWindow()
                .navigate("Maintain", "ReferenceImplementation", "RI Advanced Search List")
                .navigate("Maintain", "ReferenceImplementation", "RI Advanced Search List")
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")

                //windowButton()
//                .assertElement("Help10")
//                .assertElement("Close11")
//                //clickSearch ()
//                .assertElement("searchSelect-main")
//                .assertElement("MCB_SearchWC_wca_loginId")
//                .assertElement("Search")
//                 //clickSearchAllOptions()
//                .assertElement("searchSelect-main")
//                .clickOnComboBox("searchSelect-main","User Status")
//                .assertElement("Search")
//                .clickOnButton("Search")
//                //clickNextPrev()
//                .assertElement("next")
//                .clickOnButton("next")
//                .assertElement("prev")
//                .clickOnButton("prev")
//                // tableMenuCreate()
//                .assertElement("openLink")
//                .clickOnButton("openLink")
//                .assertElement("Create12")
//                .tableActionsContainer("Create12")
//                .closeTab("Create")
//                //tableMenuModify()
//                .switchToTab("RI Advanced Search List")
//                .assertElement("Modify13")
//                .tableActionsContainer("Modify13")
//                .closeTab("Modify")
//                //tableMenuMoreActions()
//                .switchToTab("RI Advanced Search List")
//                .buttonMenu("moreAction","View")
//                .closeTab("View")
//                //advanceSearch()
//                .switchToTab("RI Advanced Search List")
//                .assertElement("advancedSearchLink")
//                .clickOnButton("advancedSearchLink")
//                //openSavedSearch()
//                .buttonMenu("savedSearch","SAVED")
//                .clickOnButton("Search")

                ;
    }



}
