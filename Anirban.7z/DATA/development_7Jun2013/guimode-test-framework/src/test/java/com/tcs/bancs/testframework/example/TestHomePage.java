package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestHomePage {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void formSteps() {
        navigatorUtility
                //---------------operation1---------------
                //testAppHeader
                .clickOnButton("extraInfoHdr")

                //testMenuBar
                .navigate("Maintain", "SecurityParameter", "User")
                .navigate("Maintain", "SecurityParameter", "Role")
                .navigate("Maintain", "SecurityParameter", "User Group List")
                .navigate("Maintain", "SecurityParameter", "Mask Profile List")

                .navigate("Maintain", "JobSetUpTest", "Job SetUp")
                .navigate("Maintain", "JobSetUpTest", "Job Monitor")

                .navigate("Maintain", "QueueManager", "RuleSet")
                .navigate("Maintain", "QueueManager", "Queue Depth")

                .navigate("Maintain", "ReportsManagement", "Modify")
                .navigate("Maintain", "ReportsManagement", "View")

                //testRemoveAllFavorites
                .otherMenuOptions("favorites","Organize Favourites")
                .handleDialogs("Ok")
                .clickOnButton("allSelect")
                .clickOnButton("Remove")
                .clickOnButton("Ok")

                //testFavourites
                .addTabToFav("User")
                .handleDialogs("Ok")
                .addTabToFav("Role")
                .handleDialogs("Ok")
                .addTabToFav("User Group List")
                .handleDialogs("Ok")
                .addTabToFav("Mask Profile List")
                .handleDialogs("Ok")
                .addTabToFav("Job SetUp")
                .handleDialogs("Ok")
                .addTabToFav("Job Monitor")
                .handleDialogs("Ok")
                .addTabToFav("RuleSet")
                .handleDialogs("Ok")
                .addTabToFav("Queue Depth")
                .handleDialogs("Ok")
                .addTabToFav("Modify")
                .handleDialogs("Ok")
                .addTabToFav("View")
                .handleDialogs("Ok")

                //testExtraRM
                .navigate("Maintain", "SecurityParameter", "Maintain ABA")
                .navigate("Maintain", "SecurityParameter", "MCPs")
                .navigate("Maintain", "SecurityParameter", "NLS Profile")

                //testCloseTabs
                .closeAllTabs()

                //testAddMore
                .navigate("Maintain", "SecurityParameter", "Maintain ABA")
                .navigate("Maintain", "SecurityParameter", "MCPs")
                .navigate("Maintain", "SecurityParameter", "NLS Profile")
                .addTabToFav("Maintain ABA")
                .handleDialogs("Ok")
                .addTabToFav("MCPs")
                .handleDialogs("Ok")
                .addTabToFav("NLS Profile")
                .handleDialogs("Ok")

                //testOpenAdded
                .otherMenuOptions("favorites","User")

                //testOrganizeFavourites
                .otherMenuOptions("favorites","Organize Favourites")
                .clickOnButton("ar_w_UserProfile_N")
                .clickOnButton("allSelect")
                .clickOnButton("noneSelect")
                .clickOnButton("ar_w_UserProfile_N")
                .handleDialogs("Remove")
                .handleDialogs()

                //---------------operation2---------------
                //testHelp
                .otherMenuOptions("help","About TCS")
                .clickOnButton("abtBancsClose")
                .otherMenuOptions("help","Content Help")

                //testAddHelpAndHome
                .addTabToFav("Home")
                .handleDialogs("Ok")

                //testMessages
                .otherMenuOptions("messages","")

                //testBirdsEyeView
                .navigate("Maintain", "SecurityParameter", "User")
                .navigate("Maintain", "SecurityParameter", "Role")
                .birdsEyeView("User")

                //openClose
                .closeAllTabs()

                //testPreferences THEME SELECTION
                .otherMenuOptions("preferences")
                .preferences("Theme Selection")
                .clickOnComboBox("fontStyle-main","Italic")
                .clickOnComboBox("brdColor-main","Blue")

                //testPreferences TABLE VIEW SIZE
                .preferences("Table view Size")
                .clickOnButton("fir")
                .clickOnButton("sec")
                .enterText("tblViewSizeSpinner","10")
                .preferences("save")
                .preferences("close")

                //logout
                .otherMenuOptions("logout")
                .handleDialogs("Cancel")
                .otherMenuOptions("logout")
                .handleDialogs("Ok")

        ;
    }



}
