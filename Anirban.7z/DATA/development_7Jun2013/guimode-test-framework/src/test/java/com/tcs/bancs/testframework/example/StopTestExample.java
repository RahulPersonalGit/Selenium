package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.api.Depends;
import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import org.junit.Test;
import org.junit.runner.RunWith;

/**
 * A Simple test with <quote>Depends</quote> annotation
 */
@RunWith(GuiModTestRunner.class)
public class StopTestExample {

    public void initMethod() {
        System.out.println("initMethod() is called !");
    }

   // @Test
    @Depends(methods = {"com.tcs.bancs.testframework.example.TestExample#initMethod"})
    public void aTestMethod() {
        System.out.println(this.getClass().getCanonicalName() + ".aTestMethod() is called !");
    }
}
