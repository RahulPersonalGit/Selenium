package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRITabForm {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void formSteps() {
       try{

        navigatorUtility
        //openWindow()
                .navigate("Maintain", "ReferenceImplementation", "RI Tab Form")
        //validationTest1()
                .enterText("bui_ct_userDetailsInner_bui_wca_businessPartner","SomeText")
                .handleAlerts()
                .enterText("bui_ct_userDetailsInner_bui_wca_employeeReference","AgainSomeText")
                .handleAlerts()
        //CreateUserSuccessTest1()
                //1 formQBETester
                .clickOnButton("bui_ct_userDetailsInner_bui_wca_businessPartner_button")
                .switchQBE()
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table","23324")
                .switchToTab("RI Tab Form")
                //2 insertValueAndAssertForTextBox
//                .enterText("bui_ct_userDetailsInner_bui_wca_employeeReference","505")
                .createUser("bui_ct_userDetailsInner_bui_wca_employeeReference")
                //3  formQBETester
                .clickOnButton("bui_ct_userDetailsInner_bui_wca_processingCenter_button")
                .switchQBE()
                .clickOnButton("Search")
                .findDataInTableNDoubleClick("bui_w_SearchListQBE_Table","Lcenter")
                .switchToTab("RI Tab Form")
                //4 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_firstName","John")
                //5 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_middleName","Mark")
                //6 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_lastName","Miller")
                //7 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_email","john@yahoo.com")
                //8 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_phoneNo","9876345620")
                //9 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_salary","654854")
                //10 initiateDecoratedComboBox
                .clickOnComboBox("bui_ct_userDetailsInner_bui_wca_nationality-main","INDIA")
                //11 initiateDecoratedComboBox
                .clickOnComboBox("bui_ct_userDetailsInner_bui_wca_balanceCurrency-main","ADP")
                //12 insertValueAndAssertForTextBox
                .enterText("bui_ct_userDetailsInner_bui_wca_balanceAmount","23435")
                //13 insertValueAndAssertForTextBox
                .enterText("bui_ct_userAccessControl_bui_wca_login","kkkk")
                //14 insertValueAndAssertForTextBox
                .enterText("bui_ct_userAccessControl_bui_wca_password","xyzM")
                //15 insertValueAndAssertForTextBox
                .enterText("bui_ct_userAccessControl_bui_wca_confirmPassword","xyzM")
                //16 initiateDecoratedComboBox
                .clickOnComboBox("bui_ct_userAccessControl_bui_wca_userStatus-main","Entered")
                //17 setValueAndAssertCalender
                .enterDate("bui_ct_userAccessControl_bui_wca_passwordExpiryDate_button","01/06/2015")
                //18 setValueAndAssertCalender
                .enterDate("bui_ct_userValidity_bui_wca_userEffectiveDate_button","01/07/2013")
                //19 setValueAndAssertCalender
                .enterDate("bui_ct_userValidity_bui_wca_userValidityEndDate_button","01/12/2015")
                 .clickOnButton("bui_ct_userAccessControl_bui_wca_userAdmin")
                 .clickOnButton("Save19")
                 .handleAlerts("Transaction Successful!")
                 //Address tab switch
                 .clickOnButton("but_bui_ct_addressDetailsCustom")
                 //20 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_houseNo","452")
                 //21 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_district","Delhi")
                 //22 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_streeto","karolBag")
                 //23 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_city","Delhi")
                 //24 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_pinCode","234534")
                 //25 initiateDecoratedComboBox
                 .clickOnComboBox("bui_ct_addressDetails_bui_wca_country-main","INDIA")
                 //26 insertValueAndAssertForTextBox
                 .enterText("bui_ct_addressDetails_bui_wca_state","Delhi")
                 //27 setValueAndAssertCalender
                 .enterDate("bui_ct_addressDetails_bui_wca_addressValidFrom_button","01/06/2015")
                 //28 setValueAndAssertCalender
                 .enterDate("bui_ct_addressDetails_bui_wca_addressValidTill_button","01/12/2015")
                 //29 initiateDecoratedComboBox
                 .clickOnComboBox("bui_ct_addressDetails_bui_wca_addressType-main","Permanent")
                 .clickOnButton("Save19")
                 .handleAlerts()
        //testViewMode()
                 .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                 .clickOnButton("Search")
                 .rghtClickTblRow("bui_w_userListCADSL_Table",7,"View")
                 .switchToTab("View")
                 .handleDialogs()
                 .assertElement("bui_ct_userDetailsInner_bui_wca_employeeReference")
                 .clickOnButton("but_bui_ct_addressDetailsCustom")
        //testModifyMode()
                 .switchToTab("RI Custom Advanced Search List")
                 .clickOnButton("Search")
                 .rghtClickTblRow("bui_w_userListCADSL_Table",7,"Modify")
                 .switchToTab("Modify")
                 .handleDialogs()
                 .assertElement("bui_ct_userDetailsInner_bui_wca_employeeReference")
                 .assertElementValue("bui_ct_userDetailsInner_bui_wca_employeeReference","8")
                 .enterText("bui_ct_userDetailsInner_bui_wca_processingCenter","Abhilash")
                 .clickOnButton("Save19")
                 .handleAlerts("Transaction Successful!")
              //Address Tab
                 .clickOnButton("but_bui_ct_addressDetailsCustom")
                 .assertElement("bui_ct_addressDetails_bui_wca_city")
                 .enterText("bui_ct_addressDetails_bui_wca_city","Indore")
                 .assertElement("bui_ct_AddressDetailsTable_wca_city")
                 .enterText("bui_ct_AddressDetailsTable_wca_city","Bangalore")
                 .clickOnButton("Save19")
                 .handleAlerts("Transaction Successful!")
              //Close all tabs
                 .closeTab("View")
                 .closeTab("Modify")
                 .switchToTab("RI Custom Advanced Search List")
                 .clickOnButton("Search")
                 .rghtClickTblRow("bui_w_UserListCADSL_Table",7,"View")
                 .switchToTab("View")
                 .clickOnButton("but_bui_ct_addressDetailsCustom")
                 .assertElementValue("bui_ct_addressDetails_bui_wca_city","Indore")
                 .assertElementValue("bui_ct_AddressDetailsTable_wca_city","Bangalore")
                 .clickOnButton("but_bui_ct_accountDetails")
                 .assertElementValue("bui_ct_accountDetails_bui_wca_accountNo","11111")


        ;

       }catch(Exception e){
       }
    }



}
