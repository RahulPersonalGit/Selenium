package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRICADSL {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void formSteps() {
        navigatorUtility
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                //testForInputs
                .assertElement("propertyMap(MCB_SearchWC_wca_loginId_From)")
                .assertElement("MCB_SearchWC_wca_firstName")
                .assertElement("propertyMap(MCB_SearchWC_wca_lastName_From)")
                .assertElement("MCB_SearchWC_wca_userStatus-main")
                //testSearch
                .clickOnButton("Search")
                //testDoubleRightClickAndSorting
                .rghtClickTblRow("bui_w_userListCADSL_Table",1,"Create")
                .switchToTab("RI Custom Advanced Search List")
                .rghtClickTblRow("bui_w_userListCADSL_Table",1,"Modify")
                .switchToTab("RI Custom Advanced Search List")
                .rghtClickTblRow("bui_w_userListCADSL_Table",1,"View")
                .switchToTab("RI Custom Advanced Search List")
                .rghtClickTblRow("bui_w_userListCADSL_Table",1,"Delete")
                .switchToTab("RI Custom Advanced Search List")
                .rghtClickTblRow("bui_w_userListCADSL_Table",1,"View Account")
                .switchToTab("RI Custom Advanced Search List")
                .testTablePagination("bui_w_userListCADSL_Table")
                .tableSorting("bui_w_userListCADSL_Table","Login Id","string","A")
                //testSearchCrt
                .enterText("propertyMap(MCB_SearchWC_wca_loginId_From)","fd")
                .clickOnButton("Search")
                .handleDialogs()
                .enterText("propertyMap(MCB_SearchWC_wca_loginId_From)","ASDF")
                .clickOnButton("Search")
                .handleDialogs()

                //testTableMenuOptions
                .closeAllTabs()
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                .clickOnButton("Search")

                .executeColumnOptions("Login Id")

                .switchToTab("RI Custom Advanced Search List")
                .tableActionsContainer("Create13")
                .switchToTab("RI Custom Advanced Search List")
                .tableActionsContainer("Modify14")

                .switchToTab("RI Custom Advanced Search List")
                .buttonMenu("moreAction","View Account")
                .switchToTab("RI Custom Advanced Search List")
                .buttonMenu("moreAction","Modify Account")
                .switchToTab("RI Custom Advanced Search List")
                .buttonMenu("moreAction","Export To Excel")
                .handleDialogs()

                .closeAllTabs()

                //adv search
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                .clickOnButton("advancedSearchLink")
                .threeColumnSorting("First Name ","A","Last Name ","D","Buisness Partner ","A")

                .dblClickSrchOption("searchSelect", "Login Id")
                .enterText("propertyMap(MCB_SearchWC_wca_loginId_From)", "SOHINI")
                .clickOnButton("addLink")
                .clickOnButton("Search")
                .handleAlerts()

                .buttonMenu("moreActions", "Start new search")
                .dblClickSrchOption("searchSelect", "User Effective Date")
                .nativeSelect("operatorType", "between")
                .openCalender("MCB_SearchWC_wca_userEffectiveDate_btnFrom", "04/12/2012")
                .openCalender("MCB_SearchWC_wca_userEffectiveDate_btnTo", "05/02/2013")
                .clickOnButton("addLink")
                .clickOnButton("Search")

                .buttonMenu("moreActions", "Save as new")
                .enterText("newSaveName", "ABCDEF")
                .clickOnButton("ok")
                .handleAlerts()
                .buttonMenu("savedSearch", "ABCDEF")

                .buttonMenu("savedSearch", "ABCDEF")
                .buttonMenu("moreActions", "Delete")
                .handleDialogs("Ok")




        ;
    }




}
