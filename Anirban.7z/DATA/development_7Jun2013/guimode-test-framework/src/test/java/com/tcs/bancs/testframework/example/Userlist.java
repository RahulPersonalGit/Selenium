package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import com.tcs.bancs.testframework.util.BrowserDriverContext;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 5/6/13
 * Time: 2:33 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class Userlist {



  private NavigatorUtility navigatorUtility = new NavigatorUtility();
  private final static Logger logger = Logger.getLogger(Userlist.class.getName());

    @Before
    public void initSelenium() {

        navigatorUtility.driver=BrowserDriverContext.get();


    }






   @Test
   public void doQuickSearch() {

        navigatorUtility
                .navigate("Maintain","SecurityParameter","User List")
                .clickOnComboBox("searchSelect-main", "User Name")
                .enterData("TextBox", "propertyMap(MCB_SearchWC_wca_UserName_From)", "SYSADMIN")
                .clickOnButton("Search")
                .takeScreenShot("QuickSearch")
               .closeTab("User List");




    }


//    @Test
    public void doAdvancedSearch() {
        navigatorUtility
                .navigate("Maintain","SecurityParameter","User List")
                .clickOnButton("advancedSearchLink")
                        //NEW SEARCH
                .dblClickSrchOption("searchSelect","Login")
                .enterData("TextBox","propertyMap(MCB_SearchWC_wca_LoginId_From)","SYSADMIN")

                .clickOnButton("addLink")
                .clickOnButton("Search")
                        //UPDATE QUERY
                .updateQuery("Login")
                .enterData("TextBox","propertyMap(MCB_SearchWC_wca_LoginId_From)","SYSADMIN1")
                .clickOnButton("updateLink")
                .clickOnButton("Search")
                .takeScreenShot("AdvancedSearch")
               .closeTab("User List")
                ;


        //To change body of implemented methods use File | Settings | File Templates.
    }



}
