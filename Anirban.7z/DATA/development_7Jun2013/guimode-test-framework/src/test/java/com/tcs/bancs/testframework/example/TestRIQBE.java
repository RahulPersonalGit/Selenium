package com.tcs.bancs.testframework.example;

import com.tcs.bancs.testframework.impl.GuiModTestRunner;
import com.tcs.bancs.testframework.util.BrowserDriverContext;
import com.tcs.bancs.testframework.util.NavigatorUtility;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.logging.Logger;

/**
 * Created with IntelliJ IDEA.
 * User: 453979
 * Date: 6/4/13
 * Time: 5:39 PM
 * To change this template use File | Settings | File Templates.
 */
@RunWith(GuiModTestRunner.class)
public class TestRIQBE {
    private NavigatorUtility navigatorUtility = new NavigatorUtility();
    private final static Logger logger = Logger.getLogger(TestRIADSL.class.getName());


    @Before
    public void initSelenium() {
        navigatorUtility.driver= BrowserDriverContext.get();
    }

    @Test
    public void formSteps() {
        navigatorUtility
                //openWindow()
                .navigate("Maintain", "ReferenceImplementation", "RI Custom Advanced Search List")
                //rangeQBE1
                .clickOnButton("MCB_SearchWC_wca_businessPartner_button")
                .switchQBE()
                .clickOnButton("Search")
                .testTablePagination("bui_w_TestRangeQBE_Table")
                .enterText("MCB_SearchWC_wca_loginID","awse")
                .clickOnButton("Search")
                .verifySearchCondition("bui_w_TestRangeQBE_Table","Login Id","awse")
                .clickOnComboBox("MCB_SearchWC_wca_loginID_op-main","between")
                .clickOnButton("drill_MCB_SearchWC_wca_loginID")
                .enterText("MCB_SearchWC_wca_loginID_From","a")
                .enterText("MCB_SearchWC_wca_loginID_To","f")
                .clickOnButton("MCB_SearchWC_wca_loginID_ok")
                .clickOnButton("Search")
                //rangeQBE1
                .clickOnButton("MCB_SearchWC_wca_businessPartner_button")
                .switchQBE()
                .clickOnButton("Search")
                .dblClickTblRow("bui_ct_GL_qbeAllControlsSearchList_Table",1)
                .switchToTab("RI Custom Advanced Search List")
                .switchQBE()
                .clickOnButton("Search")
                .verifySearchCondition("bui_w_TestRangeQBE_Table","Business Partner","3435")

        ;
    }



}
